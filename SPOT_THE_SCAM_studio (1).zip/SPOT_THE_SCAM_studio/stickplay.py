#!/usr/bin/env python3
# ============================================================
#  STICKPLAY — mini "game engine" film stickman (offline, instan)
#  ============================================================
#  DUA MODE:
#  1. MANUAL  — tulis scene.txt (DSL ala game script), render persis.
#  2. AUTO    — kasih narasi.txt (paragraf dipisah '---'), engine PILIH
#               latar + karakter + aksi otomatis dari kata kunci.
#
#  Contoh scene.txt:
#     beat bg=living_room dur=4.5
#     char grandma x=650 mood=worried
#     walk grandma 650->980 t=0.0..0.5
#     pose grandma phone t=0.5..1.0
#     fx ring at=980,560 t=0.5..1.0
#
#  Pakai: python stickplay.py scene.txt outdir          (render klip/beat)
#  Import oleh episode.py untuk pipeline penuh.
# ============================================================
import os, sys, math, re
import stickgen as sg
from PIL import Image, ImageDraw

W, H, FLOOR = sg.W, sg.H, sg.FLOOR
pu_get = lambda p: (math.sin(p*2*math.pi*3 - math.pi/2)+1)/2
WHITE, AMBER, DIM, DIM2, LW = sg.WHITE, sg.AMBER, sg.DIM, sg.DIM2, sg.LW

# ---------------- KARAKTER (class look) ----------------
# look: glasses, bun, longhair, baldside, hood, hat, tie, headset, cane, dress, dark, scale
LOOKS = {
    'grandma': dict(glasses=1, bun=1,    dress=1, cane=1),
    'grandpa': dict(glasses=1, baldside=1, cane=1),
    'man':     dict(shorthair=1),
    'woman':   dict(longhair=1),
    'young':   dict(shorthair=1, scale=0.9),
    'scammer': dict(hood=1, headset=1, dark=1),
    'agent':   dict(shorthair=1, tie=1, glasses=1),
    'cop':     dict(hat=1, badge=1, shorthair=1),
}

def star(d, cx, cy, r, col=AMBER, w=5):
    import math as _m
    pts = []
    for i in range(10):
        rr = r if i % 2 == 0 else r*0.45
        a = -_m.pi/2 + i*_m.pi/5
        pts.append((cx+rr*_m.cos(a), cy+rr*_m.sin(a)))
    d.line(pts + [pts[0]], fill=col, width=w, joint='curve')

def police_car(d, x, y, ph=0.0):
    d.rounded_rectangle([x-270, y-150, x+270, y-36], radius=30, outline=DIM, width=8)
    d.rounded_rectangle([x-150, y-266, x+160, y-136], radius=44, outline=DIM, width=7)
    for wx in (x-160, x+160):
        d.ellipse([wx-54, y-72, wx+54, y+36], outline=DIM, width=8)
        d.ellipse([wx-22, y-40, wx+22, y+4], outline=DIM2, width=5)
    star(d, x-40, y-95, 26, w=6)
    on = (math.sin(ph*2*math.pi*6) > 0)
    c1 = (224, 60, 60) if on else (52, 64, 104)
    c2 = AMBER if not on else (52, 64, 104)
    d.rectangle([x-74, y-296, x-8, y-264], fill=c1)
    d.rectangle([x+8, y-296, x+74, y-264], fill=c2)

def bg_street_police(d):
    bg_street(d)
    police_car(d, 520, FLOOR, 0.0)

def _torso(d, x, y, L, col, w, k):
    hipy, necky = y-255*k, y-385*k
    if L.get('dress'):
        d.line([(x, hipy), (x-54*k, necky+6)], fill=col, width=6)
        d.line([(x, hipy), (x+54*k, necky+6)], fill=col, width=6)
    d.line([(x, hipy), (x, necky)], fill=col, width=w)
    if L.get('tie'):
        d.line([(x, necky+14*k), (x, necky+72*k)], fill=AMBER, width=6)
    if L.get('badge'):
        star(d, x+36*k, necky+44*k, 15*k)
    return hipy, necky

def draw_char(d, x, y, look='grandma', mood='neutral', pose='idle', ph=0.0, flip=1, talk=False):
    L = LOOKS.get(look, {})
    k = L.get('scale', 1.0)
    col = (120,140,180) if L.get('dark') else WHITE
    hipy, necky = _torso(d, x, y, L, col, LW, k)
    heady = y-440*k
    # ---- kaki
    sw = math.sin(ph*4*math.pi)*26*k if pose == 'walk' else 0
    limb = sg.limb
    if pose == 'sit':
        limb(d, [(x-8*k, hipy), (x+62*k, hipy+18*k), (x+58*k, y)], LW)
        limb(d, [(x+10*k, hipy), (x+78*k, hipy+26*k), (x+76*k, y)], LW)
    elif pose == 'walk':
        limb(d, [(x-10*k, hipy), (x-24*k+sw*0.6, y-120*k), (x-30*k+sw, y)], LW)
        limb(d, [(x+10*k, hipy), (x+24*k-sw*0.6, y-120*k), (x+30*k-sw, y)], LW)
    else:
        limb(d, [(x-14*k, hipy), (x-32*k, y-130*k), (x-40*k, y)], LW)
        limb(d, [(x+14*k, hipy), (x+32*k, y-130*k), (x+40*k, y)], LW)
    # ---- lengan sesuai pose
    sh = (x, necky+14*k)
    back = [(x-66*k*flip, hipy-40*k), (x-52*k*flip, hipy+40*k)]
    if pose == 'walk':
        a = math.sin(ph*4*math.pi)*34*k
        limb(d, [sh, (x-52*k*flip, hipy-70*k), (x-46*k*flip+a*flip, hipy+6)], LW)
        limb(d, [sh, (x+52*k*flip, hipy-70*k), (x+46*k*flip-a*flip, hipy+6)], LW)
    elif pose == 'phone':
        limb(d, [sh, (x-60*k*flip, hipy-56*k), (x-40*k*flip, hipy+50*k)], LW)
        limb(d, [sh, (x+62*k*flip, hipy-110*k), (x+52*k*flip, heady+8*k)], LW)
        sg.smartphone(d, (x+58*k*flip, heady+16*k), 0.9)
    elif pose == 'point':
        limb(d, [sh, (x-52*k*flip, hipy-60*k), (x-44*k*flip, hipy+44*k)], LW)
        limb(d, [sh, (x+70*k*flip, hipy-96*k), (x+130*k*flip, hipy-104*k)], LW)
    elif pose in ('give',):
        limb(d, [sh, (x-52*k*flip, hipy-60*k), (x-44*k*flip, hipy+44*k)], LW)
        limb(d, [sh, (x+64*k*flip, hipy-88*k), (x+118*k*flip, hipy-84*k)], LW)
    elif pose == 'type':
        limb(d, [sh, (x+46*k*flip, hipy-96*k), (x+96*k*flip, hipy-70*k)], LW)
        limb(d, [sh, (x+30*k*flip, hipy-90*k), (x+74*k*flip, hipy-58*k)], LW)
    elif pose == 'hug':
        limb(d, [sh, (x+70*k*flip, hipy-140*k), (x+130*k*flip, hipy-118*k)], LW)
        limb(d, [sh, (x+64*k*flip, hipy-110*k), (x+124*k*flip, hipy-88*k)], LW)
    elif pose == 'talk':
        limb(d, [sh, (x-56*k*flip, hipy-64*k), (x-46*k*flip, hipy+40*k)], LW)
        g = math.sin(ph*4*math.pi)*10*k
        limb(d, [sh, (x+58*k*flip, hipy-96*k+g), (x+84*k*flip, hipy-60*k+g)], LW)
    else:  # idle
        limb(d, [sh, (x-64*k*flip, hipy-52*k), (x-58*k*flip, hipy+52*k)], LW)
        limb(d, [sh, (x+64*k*flip, hipy-52*k), (x+58*k*flip, hipy+52*k)], LW)
    # ---- kepala
    r = 44*k
    sg.head(d, x, heady, r=r, mood=mood, flip=flip,
            glasses=bool(L.get('glasses')), bun=bool(L.get('bun')))
    if L.get('longhair'):
        d.arc([x-54*k, heady-44*k, x+54*k, heady+92*k], 55, 125, fill=col, width=10)
    if L.get('baldside'):
        d.arc([x-48*k, heady-30*k, x-10*k, heady+8*k], 90, 250, fill=col, width=7)
        d.arc([x+10*k, heady-30*k, x+48*k, heady+8*k], 290, 90, fill=col, width=7)
    if L.get('shorthair'):
        d.arc([x-r*0.9, heady-r*1.05, x+r*0.9, heady+r*0.25], 180, 360, fill=col, width=8)
    if L.get('hood'):
        d.arc([x-58*k, heady-58*k, x+58*k, heady+58*k], 120, 420, fill=col, width=8)
        d.line([(x-44*k, heady+40*k), (x+38*k, heady+40*k)], fill=col, width=6)
    if L.get('hat'):
        d.rounded_rectangle([x-34*k, heady-84*k, x+34*k, heady-36*k], radius=10, outline=col, width=7)
        d.line([(x-56*k, heady-34*k), (x+56*k, heady-34*k)], fill=col, width=9)
        d.ellipse([x-8*k, heady-70*k, x+8*k, heady-54*k], outline=AMBER, width=5)
    if L.get('headset') and not L.get('hood'):
        d.arc([x-56*k, heady-30*k, x+56*k, heady+50*k], 110, 250, fill=WHITE, width=7)
    if talk:
        d.ellipse([x-8+k*0, heady+16, x+8, heady+34], outline=col, width=5)
    # ---- tongkat
    if L.get('cane') and pose == 'idle':
        top = (x-84*k + 40*flip, heady+40)
        d.line([(x-70*k+30*flip, y), top], fill=col, width=7)
        d.arc([top[0]-20, top[1]-16, top[0]+20, top[1]+16], 180, 360, fill=col, width=7)
    return heady

# ---------------- LATAR (levels) ----------------
def bg_living_room(d):
    sg.floor_line(d); sg.rug(d, 900, rw=520)
    sg.window_moon(d, 1400, 150); sg.frame(d, 380, 170, family=True); sg.floor_lamp(d, 200)

def bg_kitchen(d):
    sg.floor_line(d)
    d.line([(120, 640), (900, 640)], fill=DIM, width=8)
    d.line([(160, 640), (160, FLOOR)], fill=DIM2, width=6)
    d.rectangle([1000, 200, 1220, 420], outline=DIM, width=6)
    d.line([(1110, 200), (1110, 420)], fill=DIM2, width=4)
    d.rectangle([1320, 200, 1560, 420], outline=DIM, width=6)
    d.line([(1320, 310), (1560, 310)], fill=DIM2, width=4)
    d.line([(1180, 90), (1420, 90)], fill=DIM, width=6)
    d.polygon([(1230, 90), (1370, 90), (1350, 160), (1250, 160)], outline=DIM, width=5)

def bg_hallway(d):
    sg.floor_line(d)
    d.line([(300, 120), (860, 620)], fill=DIM2, width=5)
    d.line([(1620, 120), (1060, 620)], fill=DIM2, width=5)
    d.line([(300, 120), (300, 900)], fill=DIM2, width=5)
    d.line([(1620, 120), (1620, 900)], fill=DIM2, width=5)
    d.rectangle([820, 330, 1100, 640], outline=DIM2, width=5)
    sg.wall_clock(d, 480, 300)

def bg_door(d):
    sg.floor_line(d)
    d.rectangle([1150, 160, 1600, FLOOR], outline=DIM, width=8)
    d.ellipse([1520, 560, 1560, 600], fill=AMBER)
    sg.wall_clock(d, 480, 280); sg.frame(d, 620, 200, w=170, h=130)

def bg_street(d):
    sg.floor_line(d)
    for bx, bw, bh in ((80, 420, 620), (1420, 420, 760)):
        d.rectangle([bx, FLOOR-bh, bx+bw, FLOOR], outline=DIM, width=7)
        for wy in range(FLOOR-bh+70, FLOOR-70, 130):
            for wx in range(bx+50, bx+bw-60, 110):
                d.rectangle([wx, wy, wx+52, wy+70], outline=DIM2, width=4)
    d.ellipse([1580, 140, 1660, 220], fill=DIM)
    sg.floor_lamp(d, 1150)

def bg_store(d):
    sg.floor_line(d)
    for rx in (140, 700):
        d.rectangle([rx, 200, rx+360, 240], outline=DIM, width=7)
        d.line([(rx+40, 240), (rx+40, 620)], fill=DIM2, width=6)
        d.line([(rx+320, 240), (rx+320, 620)], fill=DIM2, width=6)
        for i in range(4):
            hx = rx + 60 + i*80
            d.line([(hx, 240), (hx, 268)], fill=DIM2, width=4)
            d.rounded_rectangle([hx-24, 268, hx+24, 380], radius=8, outline=DIM2, width=4)
    d.line([(1240, 620), (1820, 620)], fill=DIM, width=9)
    d.line([(1300, 620), (1300, FLOOR)], fill=DIM2, width=7)
    d.line([(1760, 620), (1760, FLOOR)], fill=DIM2, width=7)

def bg_bank(d):
    sg.floor_line(d)
    d.line([(200, 640), (1720, 640)], fill=DIM, width=10)
    for cx in (300, 700, 1100, 1500):
        d.rectangle([cx-40, 240, cx+40, 640], outline=DIM, width=7)
        d.rectangle([cx-56, 200, cx+56, 240], outline=DIM, width=6)
    d.ellipse([860, 90, 1060, 260], outline=AMBER, width=8)
    d.arc([900, 130, 1020, 250], 300, 90, fill=AMBER, width=8)  # simbol koin

def bg_office(d):
    sg.floor_line(d)
    d.line([(420, 700), (1660, 700)], fill=DIM, width=9)
    d.line([(480, 700), (480, FLOOR)], fill=DIM2, width=7)
    d.line([(1600, 700), (1600, FLOOR)], fill=DIM2, width=7)
    for mx in (620, 1180):
        d.rounded_rectangle([mx, 380, mx+300, 640], radius=12, outline=(110,140,190), width=6)
        d.rounded_rectangle([mx+16, 396, mx+284, 624], radius=6, fill=(24,44,86))
        for li in range(4):
            d.line([(mx+40, 430+li*44), (mx+40+150, 430+li*44)], fill=(80,120,180), width=6)
        d.line([(mx+150, 640), (mx+150, 700)], fill=DIM, width=7)
    d.rounded_rectangle([860, 700, 1240, 736], radius=8, outline=(120,150,200), width=5)

def bg_car(d):
    sg.floor_line(d)
    d.rounded_rectangle([520, 560, 1500, 800], radius=90, outline=DIM, width=8)
    d.rounded_rectangle([760, 420, 1240, 590], radius=60, outline=DIM, width=7)
    for wx in (720, 1300):
        d.ellipse([wx-70, 760, wx+70, 900], outline=DIM, width=8)
        d.ellipse([wx-26, 814, wx+26, 866], outline=DIM2, width=5)

def bg_park(d):
    sg.floor_line(d)
    d.ellipse([1420, 130, 1520, 230], fill=DIM)
    d.line([(300, FLOOR), (300, 480)], fill=DIM, width=10)
    d.ellipse([170, 260, 470, 540], outline=DIM, width=8)
    d.line([(760, 760), (1240, 760)], fill=DIM, width=9)
    for bx in (800, 1200):
        d.line([(bx, 760), (bx, FLOOR)], fill=DIM2, width=7)
    d.line([(760, 640), (1240, 640)], fill=DIM, width=7)
    d.line([(760, 640), (760, 760)], fill=DIM2, width=6)
    d.line([(1240, 640), (1240, 760)], fill=DIM2, width=6)

def bg_tv_room(d):
    bg_living_room(d)
    d.rounded_rectangle([700, 300, 1220, 640], radius=16, fill=(14,30,62), outline=DIM, width=8)
    d.polygon([(960, 380), (1060, 550), (860, 550)], outline=AMBER, width=8)
    d.line([(960, 430), (960, 495)], fill=AMBER, width=8)
    d.ellipse([952, 505, 968, 521], fill=AMBER)

BGS = {
    'living_room': bg_living_room, 'kitchen': bg_kitchen, 'hallway': bg_hallway,
    'door': bg_door, 'street': bg_street, 'store': bg_store, 'bank': bg_bank,
    'office': bg_office, 'car': bg_car, 'park': bg_park, 'tv_room': bg_tv_room,
    'street_police': bg_street_police,
}

# ---------------- TEMA PUTIH (clean explainer) ----------------
def apply_white_theme():
    global WHITE, DIM, DIM2, NAVY_D
    sg.BG = (250, 250, 252)
    sg.WHITE = WHITE = (30, 34, 58)          # tinta gelap utk garis tokoh
    sg.DIM  = DIM  = (176, 184, 200)
    sg.DIM2 = DIM2 = (216, 221, 230)
    sg.NAVY_D = NAVY_D = (238, 240, 245)
    def canvas_w():
        img = Image.new('RGB', (sg.W, sg.H), sg.BG)
        d = ImageDraw.Draw(img)
        for x in range(50, sg.W, 46):
            for y in range(50, sg.H, 46):
                d.ellipse([x, y, x+2, y+2], fill=(234, 237, 243))
        return img
    def grain_w(img, grain_amt=13):
        import random as _r
        noise = Image.frombytes('L', (sg.W//3, sg.H//3), os.urandom((sg.W//3)*(sg.H//3)))
        noise = noise.resize((sg.W, sg.H)).point(lambda p: int(p*0.08))
        return Image.blend(img, Image.merge('RGB', [noise]*3), 0.05)
    sg.canvas = canvas_w
    sg.grain_vignette = grain_w

# ---------------- BEAT / DSL ----------------
def new_beat():
    return dict(bg='living_room', dur=4.0, chars={}, ops=[], fx=[])

def add_char(beat, look, x=900, mood='neutral', flip=1):
    beat['chars'][look] = dict(x=x, mood=mood, flip=flip, ops=[])

def beat_state(beat, p):
    """posisi & pose tiap karakter pada fase p (0..1)"""
    st = {}
    for look, c in beat['chars'].items():
        x, pose, talk = c['x'], 'idle', False
        for (t0, t1, kind, args) in sorted(c['ops'], key=lambda o: o[0]):
            if kind == 'walk':
                if p >= t1: x = args[1]
                elif p >= t0:
                    tt = (p-t0)/max(t1-t0, 1e-6)
                    x = args[0] + (args[1]-args[0])*tt
                    pose = 'walk'
            elif kind == 'pose':
                if t0 <= p < t1 or (p >= t1 and t0 <= p):
                    if p >= t0: pose, talk = args[0], (args[0] == 'talk')
        st[look] = (x, pose, talk)
    return st

def render_beat(beat, fps=12, fdir='frames'):
    os.makedirs(fdir, exist_ok=True)
    n = max(2, int(round(beat['dur'] * fps)))
    paths = []
    for i in range(n):
        p = i / n
        img = sg.canvas()
        d = ImageDraw.Draw(img)
        BGS.get(beat['bg'], bg_living_room)(d)
        if beat['bg'] == 'street_police':
            on = (math.sin(p*2*math.pi*6) > 0)
            img = sg.glow(img, (520+40 if not on else 520-40, FLOOR-280),
                          100+50*pu_get(p), color=(224,60,60) if on else AMBER, strength=150)
            d = ImageDraw.Draw(img)
        st = beat_state(beat, p)
        for look, c in beat['chars'].items():
            x, pose, talk = st[look]
            y = FLOOR + math.sin(p*2*math.pi)*2.5
            if pose == 'phone':
                pass
            draw_char(d, x, y, look, c['mood'], pose, p, c['flip'], talk)
            if pose == 'phone':
                img = sg.glow(img, (x+58*c['flip'], y-424), 90+25*math.sin(p*8*math.pi)**2,
                              strength=120)
                d = ImageDraw.Draw(img)
        for (t0, t1, kind, args) in beat['fx']:
            if t0 <= p < t1:
                pu = (math.sin((p-t0)/max(t1-t0,1e-6)*2*math.pi*3 - math.pi/2)+1)/2
                if kind == 'ring':
                    cx, cy = args['at']
                    ov = Image.new('RGBA', img.size, (0,0,0,0))
                    od = ImageDraw.Draw(ov)
                    for rr in (36+46*pu, 64+66*pu):
                        a = int(190*(1-pu))
                        od.ellipse([cx-rr, cy-rr, cx+rr, cy+rr], outline=AMBER+(a,), width=6)
                    img = Image.alpha_composite(img.convert('RGBA'), ov).convert('RGB')
                    d = ImageDraw.Draw(img)
                elif kind == 'card':
                    img = sg.glow(img, args['at'], 120+40*pu, strength=140+80*pu)
                    d = ImageDraw.Draw(img)
                    x0, y0 = args['at']
                    d.rounded_rectangle([x0-40, y0-56, x0+40, y0+56], radius=10,
                                        fill=(46,38,16), outline=AMBER, width=6)
                elif kind == 'glow':
                    col = (150,180,235) if args.get('color') == 'blue' else AMBER
                    img = sg.glow(img, args['at'], 150+60*pu, color=col, strength=100+80*pu)
                    d = ImageDraw.Draw(img)
        for (t0, t1, chunk, style) in beat.get('text_chunks', []):
            if t0 <= p < t1:
                import kinetic
                img = kinetic.draw_chunk(img, chunk, style, (p - t0) / max(t1 - t0, 1e-6))
        img = sg.grain_vignette(img)
        path = os.path.join(fdir, f'f{i:03d}.png')
        img.save(path); paths.append(path)
    return paths

# ---------------- PARSER DSL ----------------
def parse_scene(path):
    beats, cur = [], None
    for raw in open(path, encoding='utf-8'):
        line = raw.strip()
        if not line or line.startswith('#'): continue
        if line.startswith('beat '):
            cur = new_beat()
            for tok in line.split()[1:]:
                if '=' in tok:
                    kk, vv = tok.split('=', 1)
                    if kk == 'bg': cur['bg'] = vv
                    elif kk == 'dur': cur['dur'] = float(vv)
            beats.append(cur)
            continue
        if cur is None: continue
        toks = line.split()
        cmd = toks[0]
        if cmd == 'char':
            look = toks[1]
            kw = dict(x=900, mood='neutral', flip=1)
            for t in toks[2:]:
                if '=' in t:
                    kk, vv = t.split('=', 1)
                    if kk == 'x': kw['x'] = float(vv)
                    elif kk == 'mood': kw['mood'] = vv
                    elif kk == 'flip': kw['flip'] = int(vv)
            add_char(cur, look, **kw)
        elif cmd in ('walk', 'pose', 'fx') and cur['chars']:
            if cmd == 'fx':
                look = None
                kind = toks[1]
                at = (960, 560); t0, t1 = 0.0, 1.0; col = 'amber'
                for t in toks[2:]:
                    if t.startswith('at='):
                        ax, ay = t[3:].split(','); at = (float(ax), float(ay))
                    elif t.startswith('t='):
                        a, b = t[2:].split('..'); t0, t1 = float(a), float(b)
                    elif t.startswith('color='): col = t[6:]
                cur['fx'].append((t0, t1, kind, dict(at=at, color=col)))
            else:
                look, val = toks[1], toks[2]
                t0, t1 = 0.0, 1.0
                for t in toks[3:]:
                    if t.startswith('t='):
                        a, b = t[2:].split('..'); t0, t1 = float(a), float(b)
                if cmd == 'walk':
                    a, b = val.split('->')
                    cur['chars'][look]['ops'].append((t0, t1, 'walk', (float(a), float(b))))
                else:
                    cur['chars'][look]['ops'].append((t0, t1, 'pose', (val,)))
    return beats

def to_dsl(beats):
    out = ['# scene.txt — dihasilkan otomatis (boleh diedit lalu render ulang)']
    for i, b in enumerate(beats, 1):
        out.append(f'beat bg={b["bg"]} dur={b["dur"]:.1f}   # beat {i}')
        for look, c in b['chars'].items():
            out.append(f'char {look} x={c["x"]:.0f} mood={c["mood"]} flip={c["flip"]}')
        for (t0, t1, kind, args) in b['chars_ops_dsl'] if 'chars_ops_dsl' in b else []:
            pass
        for (t0, t1, kind, args) in b.get('dsl_ops', []):
            if kind == 'walk':
                out.append(f'walk {args["who"]} {args["a"]:.0f}->{args["b"]:.0f} t={t0}..{t1}')
            elif kind == 'pose':
                out.append(f'pose {args["who"]} {args["pose"]} t={t0}..{t1}')
        for (t0, t1, kind, args) in b['fx']:
            at = f'{args["at"][0]:.0f},{args["at"][1]:.0f}'
            out.append(f'fx {kind} at={at} t={t0}..{t1}')
    return '\n'.join(out) + '\n'

# ---------------- AUTO-DIRECTOR (narasi -> adegan) ----------------
AUTO_RULES = [
    (r'call center|call centre|boiler room|scammer|criminal|hacker', dict(bg='office', char='scammer', pose='type')),
    (r'agent|irs|tax|official|officer|detective|investigator', dict(bg='office', char='agent', pose='talk')),
    (r'police|cop|arrest|sheriff|badge|bail|jail|siren', dict(bg='street_police', char='cop', pose='talk')),
    (r'gift card|store|supermarket|retail|card', dict(bg='store', char=None, pose='give')),
    (r'bank|wire|transfer|account|money|dollar|bitcoin|crypto|atm|cash', dict(bg='bank', char=None, pose='idle')),
    (r'computer|email|link|website|click|software|remote|screen', dict(bg='office', char='scammer', pose='type')),
    (r'hug|family|reunion|safe|safe and sound|relief|together|love', dict(bg='living_room', char=None, pose='hug')),
    (r'tv|news|watch|television', dict(bg='tv_room', char=None, pose='idle')),
    (r'knock|door|front door', dict(bg='door', char=None, pose='idle')),
    (r'walk|street|outside|neighborhood|car|driving|road', dict(bg='street', char=None, pose='idle')),
    (r'kitchen|coffee|table|morning', dict(bg='kitchen', char=None, pose='idle')),
    (r'phone|call|ring|voice|caller|telephone|cell', dict(bg='living_room', char=None, pose='phone', ring=True)),
]

def who_in(text):
    t = text.lower()
    if re.search(r'\bgrandpa\b|\bgrandfather\b|\bold man\b', t): return 'grandpa'
    if re.search(r'\bgrandma\b|\bgrandmother\b|\bshe\b|\bher\b', t): return 'grandma'
    if re.search(r'\bdaughter\b|\bson\b|\bgrandson\b|\byoung (man|woman)\b', t): return 'young'
    return 'grandma'

def auto_beat(text, dur):
    t = text.lower()
    beat = new_beat()
    beat['dur'] = max(3.0, min(float(dur), 20.0))
    who = who_in(text)
    chosen = None
    for pat, cfg in AUTO_RULES:
        if re.search(pat, t):
            chosen = cfg; break
    if chosen is None:
        chosen = dict(bg='living_room', char=None, pose='talk')
    beat['bg'] = chosen['bg']
    x1 = 330 if chosen['bg'] == 'office' else (640 if chosen['pose'] in ('type',) else 760)
    add_char(beat, who, x=x1, mood='worried' if re.search(r'scam|fraud|lost|stole|trick|urgent', t) else 'neutral')
    flip = 1
    if chosen['char']:
        cx = 1350 if chosen['pose'] == 'type' else 1250
        cflip = -1 if chosen['pose'] == 'type' else 1
        add_char(beat, chosen['char'], x=cx, flip=cflip)
        flip = -1
    if beat['bg'] in ('door', 'street', 'street_police', 'store', 'bank') and chosen['pose'] not in ('hug', 'type'):
        c = beat['chars'][who]
        x0 = max(320, c['x'] - 300)
        c['ops'].append((0.0, 0.32, 'walk', (x0, c['x'])))
    if chosen['pose'] == 'phone':
        beat['chars'][who]['ops'].append((0.0, 0.35, 'pose', ('idle',)))
        beat['chars'][who]['ops'].append((0.35, 1.0, 'pose', ('phone',)))
        beat['fx'].append((0.35, 1.0, 'ring', dict(at=(int(x1+95), int(FLOOR-420)), color='amber')))
    elif chosen['pose'] == 'hug' and len(beat['chars']) < 2:
        add_char(beat, 'young', x=940, flip=-1)
        beat['chars'][who]['x'] = 800
        beat['chars'][who]['ops'].append((0.0, 1.0, 'pose', ('hug',)))
        beat['chars']['young']['ops'].append((0.0, 1.0, 'pose', ('hug',)))
        beat['fx'].append((0.2, 1.0, 'glow', dict(at=(1580, 350), color='amber')))
    elif chosen['pose'] == 'give':
        beat['chars'][who]['ops'].append((0.0, 1.0, 'pose', ('give',)))
        beat['fx'].append((0.2, 1.0, 'card', dict(at=(int(x1+180), int(FLOOR-330)))))
    elif chosen['pose'] == 'type':
        beat['chars'][who]['ops'].append((0.0, 1.0, 'pose', ('idle',)))
        if 'scammer' in beat['chars']:
            beat['chars']['scammer']['ops'].append((0.0, 1.0, 'pose', ('type',)))
        beat['fx'].append((0.0, 1.0, 'glow', dict(at=(1180, 480), color='blue')))
    elif chosen['pose'] == 'talk':
        beat['chars'][who]['ops'].append((0.0, 1.0, 'pose', ('talk',)))
    # simpan info DSL utk round-trip
    ops = []
    for look, c in beat['chars'].items():
        for (t0, t1, kind, args) in c['ops']:
            ops.append((t0, t1, kind, dict(who=look, **(dict(a=args[0], b=args[1]) if kind == 'walk' else dict(pose=args[0])))))
    beat['dsl_ops'] = ops
    return beat

# ---------------- CLI render scene.txt ----------------
def main():
    src = sys.argv[1] if len(sys.argv) > 1 else 'scene.txt'
    outd = sys.argv[2] if len(sys.argv) > 2 else 'output_play'
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    from stickanim import find_ffmpeg
    ff = find_ffmpeg()
    beats = parse_scene(src)
    os.makedirs(outd, exist_ok=True)
    clips = []
    for i, b in enumerate(beats, 1):
        print(f'[{i}/{len(beats)}] bg={b["bg"]} dur={b["dur"]}s chars={list(b["chars"])}')
        paths = render_beat(b, 12, os.path.join(outd, f'beat{i:02d}_f'))
        out = os.path.join(outd, f'beat{i:02d}.mp4')
        if ff:
            subprocess_ok = os.system(
                f'"{ff}" -y -loglevel error -framerate 12 -i "{os.path.join(outd, f"beat{i:02d}_f")}/f%03d.png" '
                f'-c:v libx264 -pix_fmt yuv420p -crf 20 "{out}"') == 0
            if subprocess_ok:
                for p in paths: os.remove(p)
                os.rmdir(os.path.join(outd, f'beat{i:02d}_f'))
                clips.append(out); print('   OK ->', out); continue
        from stickanim import make_webp, make_gif
        make_webp(paths, out.replace('.mp4', '.webp'), 12)
        make_gif(paths, out.replace('.mp4', '.gif'), 12)
        print('   OK ->', out.replace('.mp4', '.webp/.gif'))
    print(f'=== {len(clips)} klip selesai di {outd} ===')

if __name__ == '__main__':
    main()
