#!/usr/bin/env python3
# ============================================================
#  OBJPACK — generator 100 file objek PNG (gaya doodle tangan)
#  Kategori: nature, street, home, office, props, extras
#  Dipakai stage.py sbg dekorasi ambien + properti tambahan,
#  supaya tiap video terasa beda (tidak template).
#  Jalankan: python objpack.py   (idempotent, seed deterministik)
# ============================================================
import os, json, math, random
from PIL import Image, ImageDraw

OUT = None
import paths
for a in paths.ASSETS:
    p = os.path.join(a, 'objpack')
    if os.path.isdir(os.path.dirname(p)):
        OUT = p; break
OUT = OUT or 'objpack'

INK = (30, 34, 58)
PASTEL = dict(red=(224, 122, 110), orange=(238, 168, 92), yellow=(240, 200, 90),
              green=(134, 186, 130), teal=(110, 170, 160), blue=(120, 150, 200),
              navy=(96, 110, 160), purple=(160, 130, 180), pink=(226, 152, 166),
              brown=(160, 122, 92), grey=(176, 182, 196), cream=(244, 238, 224))
CW, CH = 360, 300

def canvas():
    return Image.new('RGBA', (CW, CH), (0, 0, 0, 0))

def o(d, xy, r=6, fill=None, w=6):
    x0, y0, x1, y1 = xy
    d.rounded_rectangle([x0, y0, x1, y1], r, fill=fill, outline=INK, width=w)

def ell(d, xy, fill=None, w=6):
    d.ellipse(xy, fill=fill, outline=INK, width=w)

def ln(d, pts, w=6, col=INK):
    d.line(pts, fill=col, width=w)

# ---------------- drawer per objek -------------------------------
def bush(d, rng):
    col = rng.choice([PASTEL['green'], (150, 196, 140)])
    for dx, dy, r in ((-40, 40, 52), (10, 20, 62), (60, 44, 46)):
        ell(d, [140+dx-r, 190+dy-r, 140+dx+r, 190+dy+r], fill=col, w=5)

def flowers(d, rng):
    for i in range(rng.randint(3, 4)):
        x = 80 + i*70 + rng.randint(-8, 8)
        col = rng.choice([PASTEL['red'], PASTEL['yellow'], PASTEL['purple'], PASTEL['pink']])
        ln(d, [x, 260, x, 190], 6)
        for a in range(0, 360, 72):
            x2 = x + 16*math.cos(math.radians(a)); y2 = 178 + 16*math.sin(math.radians(a))
            ell(d, [x2-11, y2-11, x2+11, y2+11], fill=col, w=4)
        ell(d, [x-8, 170, x+8, 186], fill=PASTEL['yellow'], w=4)

def tree_small(d, rng):
    col = rng.choice([PASTEL['green'], (140, 188, 128), (110, 168, 130)])
    h = rng.randint(120, 170)
    ln(d, [180, 275, 180, 260-h], 12, (120, 90, 66))
    ell(d, [180-70, 240-h-70, 180+70, 250-h+10], fill=col, w=6)

def grass(d, rng):
    for i in range(5):
        x = 100 + i*40 + rng.randint(-6, 6)
        h = rng.randint(28, 50)
        d.arc([x-16, 262-h, x+16, 262+h-30], 200, 340, fill=(120, 172, 118), width=6)

def pine(d, rng):
    h = rng.randint(150, 200)
    ln(d, [180, 280, 180, 268], 10, (120, 90, 66))
    col = rng.choice([PASTEL['green'], (100, 156, 118)])
    for k, w in ((0, 96), (46, 74), (92, 52)):
        d.polygon([(180, 250-h+k), (180-w, 268-k+18), (180+w, 268-k+18)],
                  fill=col, outline=INK)

def rock(d, rng):
    col = PASTEL['grey']
    ell(d, [110, 200, 250, 275], fill=col, w=6)
    ell(d, [150, 175, 235, 235], fill=(196, 202, 214), w=5)

def mushroom(d, rng):
    col = rng.choice([PASTEL['red'], PASTEL['orange']])
    o(d, [150, 200, 210, 272], 14, fill=PASTEL['cream'], w=5)
    d.pieslice([110, 150, 250, 250], 180, 360, fill=col, outline=INK, width=6)
    for dx, dy in ((160, 190), (196, 178), (176, 210)):
        ell(d, [dx-7, dy-7, dx+7, dy+7], fill=(255, 255, 255), w=3)

def cone(d, rng):
    d.polygon([(180, 90), (130, 262), (230, 262)], fill=(238, 130, 80), outline=INK)
    ln(d, [152, 200, 208, 200], 8, (255, 255, 255))
    o(d, [108, 252, 252, 278], 10, fill=PASTEL['orange'], w=6)

def lamppost(d, rng):
    col = rng.choice([PASTEL['navy'], (70, 78, 100)])
    ln(d, [180, 280, 180, 90], 12, col)
    d.polygon([(180, 40), (150, 92), (210, 92)], fill=col, outline=INK)
    ell(d, [164, 66, 196, 96], fill=PASTEL['yellow'], w=4)
    ln(d, [160, 278, 200, 278], 8)

def hydrant(d, rng):
    col = rng.choice([PASTEL['red'], (214, 100, 90)])
    o(d, [150, 150, 210, 262], 16, fill=col, w=6)
    ell(d, [150, 122, 210, 168], fill=col, w=6)
    ln(d, [120, 192, 240, 192], 10, col)
    ell(d, [168, 96, 192, 122], fill=col, w=5)

def mailbox(d, rng):
    col = rng.choice([PASTEL['blue'], PASTEL['red'], PASTEL['teal']])
    ln(d, [180, 262, 180, 150], 10, (120, 90, 66))
    d.rounded_rectangle([120, 84, 240, 156], 36, fill=col, outline=INK, width=6)
    ln(d, [210, 108, 210, 132], 6, (255, 255, 255))
    d.rectangle([172, 156, 188, 176], fill=INK)

def bench(d, rng):
    col = rng.choice([PASTEL['brown'], (150, 116, 88)])
    o(d, [70, 150, 290, 176], 8, fill=col, w=6)
    o(d, [70, 190, 290, 212], 8, fill=col, w=6)
    ln(d, [92, 176, 92, 262], 9); ln(d, [268, 176, 268, 262], 9)
    ln(d, [92, 150, 92, 118], 9); ln(d, [268, 150, 268, 118], 9)
    o(d, [70, 108, 290, 126], 8, fill=col, w=6)

def fence(d, rng):
    col = rng.choice([PASTEL['cream'], (214, 200, 176)])
    for x in range(90, 271, 45):
        o(d, [x, 130, x+18, 262], 8, fill=col, w=5)
    ln(d, [70, 160, 290, 160], 9, col); ln(d, [70, 210, 290, 210], 9, col)

def sign(d, rng):
    col = rng.choice([PASTEL['yellow'], PASTEL['teal'], PASTEL['blue']])
    ln(d, [180, 262, 180, 130], 9)
    if rng.random() < 0.5:
        d.polygon([(180, 60), (262, 128), (180, 196), (98, 128)], fill=col,
                  outline=INK)
    else:
        o(d, [104, 66, 256, 190], 12, fill=col, w=6)
    ln(d, [140, 112, 220, 112], 7, (255, 255, 255))
    ln(d, [140, 140, 200, 140], 7, (255, 255, 255))

def trashbin(d, rng):
    col = rng.choice([PASTEL['green'], PASTEL['grey']])
    d.polygon([(126, 110), (234, 110), (222, 262), (138, 262)], fill=col,
              outline=INK)
    o(d, [114, 88, 246, 116], 10, fill=(140, 148, 162), w=6)
    for x in (160, 180, 200):
        ln(d, [x, 130, x, 245], 5, (255, 255, 255))

def wallclock(d, rng):
    ell(d, [100, 60, 260, 220], fill=(255, 255, 255), w=7)
    cx, cy = 180, 140
    for a in range(0, 360, 90):
        x2 = cx + 62*math.cos(math.radians(a)); y2 = cy + 62*math.sin(math.radians(a))
        ln(d, [cx+52*math.cos(math.radians(a)), cy+52*math.sin(math.radians(a)), x2, y2], 5,
           (150, 156, 172))
    ln(d, [cx, cy, cx, cy-48], 8); ln(d, [cx, cy, cx+34, cy+18], 8)
    ell(d, [cx-7, cy-7, cx+7, cy+7], fill=(224, 80, 80), w=3)

def photoframe(d, rng):
    n = rng.randint(1, 2)
    for i in range(n):
        x = 90 + i*110; y = 70 + rng.randint(0, 40)
        w_, h_ = rng.randint(70, 96), rng.randint(56, 78)
        o(d, [x, y, x+w_, y+h_], 6, fill=PASTEL['cream'], w=6)
        o(d, [x+12, y+12, x+w_-12, y+h_-12], 3, fill=rng.choice(
            [PASTEL['blue'], PASTEL['green'], PASTEL['purple']]), w=3)

def lamp(d, rng):
    col = rng.choice([PASTEL['yellow'], PASTEL['cream']])
    d.polygon([(180, 60), (120, 140), (240, 140)], fill=col, outline=INK)
    ln(d, [180, 140, 180, 230], 9)
    o(d, [150, 230, 210, 252], 8, fill=(120, 90, 66), w=5)

def bookshelf(d, rng):
    o(d, [90, 70, 270, 262], 6, fill=PASTEL['brown'], w=6)
    cols = list(PASTEL.values())
    for shelf_y in (150, 216):
        ln(d, [96, shelf_y, 264, shelf_y], 6)
        x = 104
        while x < 250:
            w_ = rng.randint(14, 22); h_ = rng.randint(46, 62)
            o(d, [x, shelf_y-h_, x+w_, shelf_y-4], 2,
              fill=rng.choice(cols), w=3)
            x += w_ + 3

def tv(d, rng):
    o(d, [70, 80, 290, 210], 10, fill=(255, 255, 255), w=7)
    o(d, [86, 96, 274, 194], 4, fill=(30, 34, 58), w=3)
    ln(d, [100, 120, 170, 120], 6, (120, 200, 140))
    ln(d, [100, 148, 150, 148], 6, (120, 128, 146))
    ln(d, [180, 210, 180, 240], 7); o(d, [130, 238, 230, 256], 6, fill=INK, w=3)

def potted_plant(d, rng):
    col = rng.choice([PASTEL['brown'], (150, 116, 88), PASTEL['teal']])
    d.polygon([(146, 190), (214, 190), (202, 262), (158, 262)], fill=col, outline=INK)
    g = rng.choice([PASTEL['green'], (120, 176, 120)])
    for dx, dy, r in ((180, 130, 46), (140, 156, 34), (220, 156, 34)):
        ell(d, [dx-r, dy-r, dx+r, dy+r], fill=g, w=5)

def sofa(d, rng):
    col = rng.choice([PASTEL['teal'], PASTEL['blue'], PASTEL['purple']])
    o(d, [60, 150, 300, 250], 20, fill=col, w=6)
    o(d, [60, 96, 110, 232], 14, fill=col, w=6)
    o(d, [250, 96, 300, 232], 14, fill=col, w=6)
    o(d, [118, 120, 242, 176], 10, fill=(255, 255, 255), w=4)
    ell(d, [86, 244, 116, 264], fill=INK, w=2)
    ell(d, [244, 244, 274, 264], fill=INK, w=2)

def kettle(d, rng):
    col = rng.choice([PASTEL['red'], PASTEL['teal'], PASTEL['navy']])
    ell(d, [124, 130, 236, 250], fill=col, w=6)
    d.arc([214, 140, 262, 200], 270, 90, fill=INK, width=8)
    d.arc([98, 140, 146, 200], 90, 180, fill=INK, width=8)
    o(d, [148, 104, 212, 134], 10, fill=col, w=5)
    ell(d, [168, 88, 192, 110], fill=INK, w=2)

def cup(d, rng):
    col = rng.choice([PASTEL['yellow'], PASTEL['pink'], PASTEL['cream']])
    o(d, [130, 130, 220, 240], 14, fill=col, w=6)
    d.arc([210, 150, 258, 210], 270, 90, fill=INK, width=8)
    for a in (200, 240, 280):
        x2 = 175 + 26*math.cos(math.radians(a)); y2 = 108 + 16*math.sin(math.radians(a))
        d.arc([x2-14, y2-10, x2+14, y2+14], 200, 340, fill=(150, 156, 172), width=5)

def whiteboard(d, rng):
    o(d, [60, 70, 300, 220], 8, fill=(255, 255, 255), w=7)
    ln(d, [84, 110, 200, 110], 7, (226, 90, 90))
    ln(d, [84, 146, 240, 146], 7, (90, 140, 200))
    ln(d, [84, 182, 170, 182], 7, (120, 172, 118))
    ln(d, [180, 220, 180, 250], 7); ln(d, [150, 250, 210, 250], 7)

def watercooler(d, rng):
    o(d, [150, 150, 230, 262], 10, fill=(214, 222, 238), w=6)
    o(d, [140, 60, 240, 150], 20, fill=(160, 200, 230), w=5)
    o(d, [164, 180, 216, 210], 6, fill=(120, 90, 66), w=4)
    ell(d, [230, 236, 262, 262], fill=(226, 90, 90), w=4)

def printer(d, rng):
    col = PASTEL['grey']
    o(d, [90, 150, 270, 250], 12, fill=col, w=6)
    o(d, [120, 96, 240, 152], 8, fill=(140, 148, 162), w=6)
    o(d, [140, 60, 220, 100], 4, fill=(255, 255, 255), w=4)
    ell(d, [240, 220, 258, 238], fill=(120, 200, 140), w=3)

def papers(d, rng):
    for i in range(3):
        x = 110 + i*18; y = 80 + i*22
        o(d, [x, y, x+150, y+190], 4, fill=(252, 250, 244), w=5)
        for k in range(3):
            ln(d, [x+18, y+36+k*30, x+128-k*14, y+36+k*30], 5, (150, 156, 172))

def mug(d, rng):
    col = rng.choice([PASTEL['red'], PASTEL['blue'], PASTEL['green']])
    o(d, [120, 120, 230, 240], 16, fill=col, w=6)
    d.arc([222, 146, 272, 210], 270, 90, fill=INK, width=9)
    ell(d, [128, 128, 222, 142], fill=(255, 255, 255), w=3)

def cubicle(d, rng):
    o(d, [60, 90, 120, 260], 4, fill=PASTEL['grey'], w=6)
    o(d, [240, 90, 300, 260], 4, fill=PASTEL['grey'], w=6)
    o(d, [110, 170, 250, 200], 6, fill=PASTEL['brown'], w=5)
    ln(d, [140, 170, 140, 200], 5); ln(d, [220, 170, 220, 200], 5)

def newspaper(d, rng):
    o(d, [80, 70, 280, 250], 4, fill=(252, 250, 244), w=6)
    ln(d, [100, 104, 260, 104], 9)
    for r_ in range(3):
        for c_ in range(2):
            x0 = 100 + c_*82
            o(d, [x0, 130+r_*38, x0+66, 156+r_*38], 2, fill=(196, 202, 214), w=2)

def book(d, rng):
    col = rng.choice([PASTEL['red'], PASTEL['blue'], PASTEL['green'], PASTEL['purple']])
    o(d, [90, 80, 260, 250], 6, fill=col, w=7)
    o(d, [110, 92, 268, 244], 3, fill=(255, 255, 255), w=3)
    ln(d, [96, 164, 96, 168], 6)
    ln(d, [140, 120, 230, 120], 6, (255, 255, 255))
    ln(d, [140, 150, 214, 150], 5, (255, 255, 255))

def pill(d, rng):
    col = rng.choice([PASTEL['orange'], PASTEL['yellow']])
    o(d, [130, 150, 230, 262], 10, fill=(255, 255, 255), w=6)
    o(d, [130, 150, 230, 190], 0, fill=col, w=0)
    d.rectangle([130, 150, 230, 192], fill=col)
    d.rounded_rectangle([130, 150, 230, 262], 10, outline=INK, width=6)
    ln(d, [150, 216, 210, 216], 6, (150, 156, 172))
    ell(d, [164, 96, 196, 128], fill=col, w=5)

def radio(d, rng):
    col = rng.choice([PASTEL['brown'], PASTEL['navy']])
    o(d, [80, 110, 280, 250], 12, fill=col, w=6)
    ell(d, [110, 150, 190, 230], fill=(240, 234, 220), w=5)
    ell(d, [148, 188, 152, 192], fill=INK, w=1)
    o(d, [210, 150, 258, 176], 6, fill=(240, 234, 220), w=4)
    ln(d, [222, 150, 222, 110], 5); ell(d, [214, 96, 230, 112], fill=INK, w=2)

def dog(d, rng):
    col = rng.choice([PASTEL['brown'], (196, 160, 120)])
    ell(d, [110, 150, 230, 235], fill=col, w=6)
    ell(d, [196, 100, 276, 168], fill=col, w=6)
    d.polygon([(206, 104), (216, 70), (240, 100)], fill=col, outline=INK)
    ell(d, [252, 122, 268, 138], fill=INK, w=2)
    ln(d, [86, 168, 112, 160], 9)
    for x in (136, 200):
        ln(d, [x, 230, x, 262], 8)

def cat(d, rng):
    col = rng.choice([PASTEL['grey'], (180, 150, 120)])
    ell(d, [120, 160, 240, 246], fill=col, w=6)
    ell(d, [180, 104, 262, 176], fill=col, w=6)
    d.polygon([(190, 112), (182, 76), (214, 98)], fill=col, outline=INK)
    d.polygon([(236, 106), (248, 74), (262, 106)], fill=col, outline=INK)
    ln(d, [262, 140, 286, 128], 5); ln(d, [262, 148, 288, 148], 5)
    for x in (152, 208):
        ln(d, [x, 240, x, 268], 8)

def bird(d, rng):
    col = rng.choice([PASTEL['teal'], PASTEL['blue'], PASTEL['yellow']])
    ell(d, [120, 140, 230, 230], fill=col, w=6)
    ell(d, [196, 108, 262, 164], fill=col, w=6)
    d.polygon([(252, 128), (286, 136), (252, 148)], fill=PASTEL['orange'], outline=INK)
    ell(d, [232, 122, 244, 134], fill=INK, w=2)
    d.arc([110, 120, 170, 190], 90, 250, fill=col, width=8)
    ln(d, [160, 226, 160, 258], 6, PASTEL['orange'])
    ln(d, [190, 226, 190, 258], 6, PASTEL['orange'])

def star(d, rng):
    col = rng.choice([PASTEL['yellow'], PASTEL['orange']])
    cx, cy, R, r_ = 180, 150, 92, 38
    pts = []
    for i in range(10):
        rad = R if i % 2 == 0 else r_
        a = -90 + i*36
        pts.append((cx + rad*math.cos(math.radians(a)), cy + rad*math.sin(math.radians(a))))
    d.polygon(pts, fill=col, outline=INK)

def heart(d, rng):
    col = rng.choice([PASTEL['red'], PASTEL['pink']])
    d.ellipse([104, 90, 190, 176], fill=col)
    d.ellipse([170, 90, 256, 176], fill=col)
    d.polygon([(112, 150), (248, 150), (180, 240)], fill=col)

def arrow(d, rng):
    col = rng.choice([PASTEL['green'], PASTEL['blue']])
    if rng.random() < 0.5:
        d.polygon([(60, 150), (200, 150), (200, 110), (290, 170), (200, 230),
                   (200, 190), (60, 190)], fill=col, outline=INK)
    else:
        d.polygon([(290, 150), (150, 150), (150, 110), (60, 170), (150, 230),
                   (150, 190), (290, 190)], fill=col, outline=INK)

def giftcard(d, rng):
    col = rng.choice(list(PASTEL.values()))
    x = rng.randint(20, 60); y = rng.randint(70, 110)
    o(d, [x, y, x+250, y+110], 14, fill=col, w=6)
    ln(d, [x+26, y+55, x+224, y+55], 7, (255, 255, 255))
    ell(d, [x+206, y+74, x+230, y+98], fill=PASTEL['yellow'], w=3)

def signpost(d, rng):
    col = rng.choice([(226, 90, 90), (238, 150, 80)])
    ln(d, [180, 262, 180, 100], 9)
    ell(d, [100, 40, 260, 176], fill=col, w=6)
    ln(d, [138, 88, 222, 88], 9, (255, 255, 255))
    ln(d, [138, 120, 202, 120], 9, (255, 255, 255))

def cloud_doodle(d, rng):
    col = (255, 255, 255)
    for dx, dy, r in ((130, 160, 52), (190, 130, 62), (244, 164, 46)):
        ell(d, [dx-r, dy-r, dx+r, dy+r], fill=col, w=5)
    o(d, [78, 158, 282, 208], 24, fill=col, w=5)

def sun(d, rng):
    ell(d, [110, 80, 250, 220], fill=(248, 208, 110), w=6)
    for a in range(0, 360, 45):
        x1 = 180 + 86*math.cos(math.radians(a)); y1 = 150 + 86*math.sin(math.radians(a))
        x2 = 180 + 116*math.cos(math.radians(a)); y2 = 150 + 116*math.sin(math.radians(a))
        ln(d, [x1, y1, x2, y2], 7, (238, 168, 92))

# ---------------- daftar 100 objek -------------------------------

# ============ v4.0: objek cerita baru (RS, hukum, bandara, romance, urgensi) ============
def _doc(d, x, y, w, h, col=(255, 255, 255)):
    o(d, [x, y, x+w, y+h], 8, fill=col, w=5)
    for i in range(3):
        ln(d, [x+16, y+24+i*20, x+w-16, y+24+i*20], 4, (168, 176, 194))

def passport(d, rng):
    o(d, [92, 46, 268, 262], 14, fill=PASTEL['navy'], w=6)
    o(d, [104, 58, 256, 250], 10, w=3)
    ell(d, [152, 92, 208, 148], fill=(240, 200, 90), w=5)
    ln(d, [140, 176, 220, 176], 6, (255, 255, 255))
    ln(d, [152, 200, 208, 200], 5, (200, 208, 224))

def bigcheck(d, rng):
    o(d, [40, 90, 320, 230], 10, fill=(252, 250, 242), w=6)
    ln(d, [64, 140, 210, 140], 5, INK)
    ln(d, [230, 140, 300, 140], 5, (214, 84, 78))
    ln(d, [64, 188, 180, 188], 4, (150, 156, 172))
    for i in range(5):
        ln(d, [200+i*14, 186, 214+i*14, 178+ (i % 2)*14], 4, (90, 98, 130))

def gavel(d, rng):
    o(d, [150, 60, 232, 116], 14, fill=PASTEL['brown'], w=6)
    ln(d, [176, 112, 168, 176], 9)
    ln(d, [206, 112, 214, 176], 9)
    o(d, [128, 224, 256, 254], 8, fill=(196, 178, 150), w=6)
    ln(d, [120, 176, 130, 224], 4, (150, 156, 172))

def handcuffs(d, rng):
    ell(d, [76, 110, 168, 202], fill=(178, 186, 202), w=7)
    ell(d, [192, 110, 284, 202], fill=(178, 186, 202), w=7)
    ell(d, [100, 134, 144, 178], fill=(240, 244, 250), w=5)
    ell(d, [216, 134, 260, 178], fill=(240, 244, 250), w=5)
    for i in range(3):
        ell(d, [160+i*18, 146, 176+i*18, 162], fill=None, w=5)

def suitcase(d, rng):
    o(d, [66, 92, 294, 262], 16, fill=PASTEL['brown'], w=6)
    o(d, [150, 62, 210, 94], 12, fill=None, w=7)
    ln(d, [120, 92, 120, 262], 4, (120, 90, 66))
    ln(d, [240, 92, 240, 262], 4, (120, 90, 66))
    o(d, [92, 150, 132, 184], 6, fill=PASTEL['red'], w=4)
    o(d, [228, 200, 268, 234], 6, fill=(240, 200, 90), w=4)

def roses(d, rng):
    for i, (x, c) in enumerate(((120, PASTEL['red']), (180, PASTEL['pink']), (240, PASTEL['red']))):
        ln(d, [x, 262, x, 170], 5)
        ell(d, [x-24, 120, x+24, 172], fill=c, w=5)
        ln(d, [x-6, 210, x+18, 196], 4, PASTEL['green'])
    ell(d, [148, 84, 212, 140], fill=None, w=5)

def ringbox(d, rng):
    o(d, [110, 150, 250, 258], 10, fill=PASTEL['red'], w=6)
    o(d, [110, 74, 250, 150], 10, fill=(238, 200, 190), w=6)
    ell(d, [160, 100, 200, 140], fill=(240, 200, 90), w=5)
    ell(d, [168, 84, 192, 106], fill=(210, 232, 250), w=4)
    ln(d, [150, 60, 160, 70], 4, (240, 200, 90))
    ln(d, [210, 62, 202, 72], 4, (240, 200, 90))

def trophy(d, rng):
    ell(d, [140, 56, 220, 136], fill=PASTEL['yellow'], w=6)
    ln(d, [140, 66, 112, 96], 8, PASTEL['yellow'])
    ln(d, [220, 66, 248, 96], 8, PASTEL['yellow'])
    ln(d, [172, 136, 172, 176], 10)
    ln(d, [188, 136, 188, 176], 10)
    o(d, [140, 176, 220, 200], 6, fill=PASTEL['brown'], w=5)
    o(d, [126, 200, 234, 240], 8, fill=PASTEL['brown'], w=5)
    star = [(180, 74), (188, 92), (206, 92), (192, 104), (198, 122), (180, 110), (162, 122), (168, 104), (154, 92), (172, 92)]
    d.polygon(star, fill=(255, 252, 240))

def confetti(d, rng):
    cols = [PASTEL[k] for k in ('red', 'yellow', 'blue', 'green', 'pink', 'purple')]
    for i in range(16):
        x, y = 50+(i*67) % 260, 44+(i*97) % 210
        c = cols[i % len(cols)]
        if i % 3 == 0:
            d.rectangle([x, y, x+16, y+7], fill=c)
        elif i % 3 == 1:
            ell(d, [x, y, x+13, y+13], fill=c, w=0)
        else:
            d.polygon([(x, y), (x+12, y+4), (x+5, y+15)], fill=c)

def ssncard(d, rng):
    o(d, [44, 96, 316, 224], 12, fill=(240, 244, 250), w=6)
    ln(d, [66, 126, 200, 126], 6, (90, 98, 130))
    ln(d, [66, 152, 240, 152], 4, (150, 156, 172))
    o(d, [252, 116, 298, 160], 6, fill=PASTEL['grey'], w=4)
    ln(d, [66, 186, 298, 186], 5, (96, 110, 160))
    ln(d, [66, 206, 220, 206], 4, (150, 156, 172))

def creditcard(d, rng):
    o(d, [40, 92, 320, 226], 14, fill=PASTEL['navy'], w=6)
    d.rectangle([40, 122, 320, 152], fill=(52, 62, 96))
    o(d, [64, 166, 100, 196], 5, fill=(240, 200, 90), w=4)
    ln(d, [118, 181, 296, 181], 6, (222, 228, 244))
    ln(d, [64, 212, 140, 212], 4, (160, 170, 200))

def usbdrive(d, rng):
    o(d, [96, 120, 226, 200], 12, fill=PASTEL['grey'], w=6)
    d.rectangle([226, 140, 282, 180], fill=(214, 220, 232))
    d.rectangle([244, 148, 254, 158], fill=(90, 98, 122))
    d.rectangle([244, 162, 254, 172], fill=(90, 98, 122))
    ell(d, [116, 140, 148, 180], fill=PASTEL['teal'], w=4)

def donationbox(d, rng):
    o(d, [92, 130, 268, 254], 8, fill=(240, 226, 200), w=6)
    ln(d, [180, 130, 180, 90], 5, INK)
    ell(d, [158, 62, 202, 98], fill=PASTEL['yellow'], w=5)
    ln(d, [180, 70, 180, 90], 4, (150, 110, 40))
    ell(d, [132, 108, 158, 128], fill=PASTEL['red'], w=3)
    d.text((124, 180), "DONATE", fill=(150, 110, 60))
    ell(d, [216, 96, 244, 118], fill=PASTEL['pink'], w=4)

def timer(d, rng):
    ell(d, [108, 88, 252, 232], fill=(252, 244, 244), w=7)
    ell(d, [124, 104, 236, 216], fill=(255, 255, 255), w=5)
    ln(d, [180, 160, 180, 118], 7, (214, 84, 78))
    ln(d, [180, 160, 210, 176], 5, (150, 156, 172))
    d.rectangle([166, 58, 194, 88], fill=(214, 84, 78))
    ln(d, [232, 70, 252, 50], 6, (214, 84, 78))
    ell(d, [172, 152, 188, 168], fill=(214, 84, 78), w=0)

def goldbar(d, rng):
    d.polygon([(60, 240), (110, 170), (250, 170), (300, 240)], fill=(240, 200, 90), outline=INK)
    d.polygon([(96, 240), (136, 186), (224, 186), (264, 240)], fill=(248, 216, 120), outline=INK)
    ln(d, [150, 206, 210, 206], 5, (190, 150, 50))
    d.polygon([(120, 170), (170, 100), (310, 100), (360-60, 170)], fill=(240, 200, 90), outline=INK)

def stamp(d, rng):
    o(d, [120, 70, 240, 150], 10, fill=(60, 50, 70), w=6)
    d.rectangle([146, 150, 214, 196], fill=(80, 70, 90))
    o(d, [108, 196, 252, 236], 6, fill=(214, 84, 78), w=5)
    d.text((126, 206), "URGENT", fill=(255, 255, 255))

def popalert(d, rng):
    o(d, [50, 70, 310, 210], 12, fill=(255, 255, 255), w=6)
    d.rectangle([50, 70, 310, 102], fill=(214, 84, 78))
    d.text((64, 76), "VIRUS ALERT!", fill=(255, 255, 255))
    ln(d, [70, 124, 250, 124], 5, (150, 156, 172))
    ln(d, [70, 148, 210, 148], 5, (150, 156, 172))
    ell(d, [252, 130, 296, 174], fill=(214, 84, 78), w=5)
    ln(d, [264, 142, 284, 162], 6, (255, 255, 255))
    ln(d, [284, 142, 264, 162], 6, (255, 255, 255))

def papersfly(d, rng):
    _doc(d, 52, 60, 130, 160, (255, 255, 255))
    _doc(d, 150, 100, 130, 160, (246, 248, 252))
    _doc(d, 108, 150, 140, 140, (252, 250, 244))

def medkit(d, rng):
    o(d, [64, 100, 296, 246], 16, fill=(255, 255, 255), w=6)
    o(d, [150, 74, 210, 102], 10, fill=None, w=7)
    d.rectangle([164, 130, 196, 212], fill=(214, 84, 78))
    d.rectangle([124, 156, 236, 186], fill=(214, 84, 78))
    ell(d, [88, 118, 116, 146], fill=PASTEL['grey'], w=4)

def crutch(d, rng):
    for dx in (40, 130):
        ln(d, [120+dx-30, 40, 130+dx-40, 250], 8)
        ln(d, [150+dx-30, 40, 160+dx-40, 250], 8)
        o(d, [104+dx, 96, 190+dx-40, 120], 10, fill=(226, 200, 170), w=5)

def syringe(d, rng):
    d.polygon([(96, 210), (120, 234), (250, 104), (226, 80)], fill=(228, 236, 248), outline=INK)
    d.polygon([(226, 80), (250, 104), (276, 78), (252, 54)], fill=(214, 220, 232), outline=INK)
    ln(d, [258, 72, 290, 40], 5)
    d.rectangle([140, 160, 172, 192], fill=(214, 84, 78))
    ln(d, [160, 120, 210, 170], 4, (150, 156, 172))

def phonechat(d, rng):
    o(d, [128, 40, 232, 264], 20, fill=(52, 60, 88), w=6)
    o(d, [140, 62, 220, 234], 10, fill=(244, 248, 252), w=3)
    o(d, [148, 76, 204, 108], 10, fill=PASTEL['blue'], w=0)
    o(d, [156, 118, 212, 150], 10, fill=PASTEL['pink'], w=0)
    o(d, [148, 160, 196, 192], 10, fill=PASTEL['blue'], w=0)
    ell(d, [186, 196, 216, 226], fill=PASTEL['red'], w=0)

def moneyfly(d, rng):
    for x, y, tilt in ((60, 90, -14), (150, 50, 8), (110, 170, 4)):
        d.rounded_rectangle([x, y, x+120, y+64], 8, fill=(214, 232, 208), outline=INK, width=5)
        ell(d, [x+42, y+14, x+78, y+50], fill=(150, 190, 150), w=4)
        ln(d, [x+8, y+8, x+8, y+56], 4, (120, 160, 120))
    for x, y in ((230, 120), (270, 70), (250, 190)):
        ln(d, [x, y, x-16, y-14], 4, (140, 150, 180))
        ln(d, [x, y, x+16, y-14], 4, (140, 150, 180))

def walletcoins(d, rng):
    o(d, [80, 110, 280, 230], 14, fill=PASTEL['brown'], w=6)
    o(d, [216, 146, 284, 194], 10, fill=(140, 100, 70), w=5)
    ell(d, [104, 88, 140, 124], fill=PASTEL['yellow'], w=5)
    ell(d, [140, 72, 176, 108], fill=(230, 186, 70), w=5)
    ell(d, [86, 140, 110, 164], fill=(230, 186, 70), w=4)

NEWFUN = dict(passport=passport, bigcheck=bigcheck, gavel=gavel, handcuffs=handcuffs,
              suitcase=suitcase, roses=roses, ringbox=ringbox, trophy=trophy,
              confetti=confetti, ssncard=ssncard, creditcard=creditcard, usbdrive=usbdrive,
              donationbox=donationbox, timer=timer, goldbar=goldbar, stamp=stamp,
              popalert=popalert, papersfly=papersfly, medkit=medkit, crutch=crutch,
              syringe=syringe, phonechat=phonechat, moneyfly=moneyfly, walletcoins=walletcoins)


# ============ v4.5: objek dari analisis narasi asli ============
def cashenvelope(d, rng):
    o(d, [64, 96, 296, 224], 8, fill=(244, 234, 210), w=6)
    d.polygon([(64, 96), (180, 170), (296, 96)], fill=(236, 222, 190), outline=INK)
    ell(d, [156, 140, 204, 188], fill=(240, 200, 90), w=5)
    d.text((170, 152), "$", fill=(120, 90, 30))

def tollsign(d, rng):
    ln(d, [180, 260, 180, 80], 8)
    o(d, [80, 40, 280, 110], 8, fill=(120, 150, 200), w=5)
    d.text((104, 60), "TOLL", fill=(255, 255, 255))
    o(d, [96, 122, 172, 158], 6, fill=(255, 255, 255), w=4)
    d.text((110, 132), "$3.95", fill=(40, 44, 64))

def mapusa(d, rng):
    pts = [(70, 190), (90, 110), (150, 70), (240, 60), (300, 100), (310, 170),
           (270, 230), (180, 250), (110, 240)]
    d.polygon(pts, fill=(226, 234, 244), outline=INK)
    for x, y in ((120, 140), (180, 120), (230, 150), (160, 190), (250, 200)):
        ell(d, [x-7, y-7, x+7, y+7], fill=(224, 122, 110), w=3)
    d.polygon([(238, 138), (252, 146), (240, 156)], fill=(240, 200, 90), outline=INK)

def commentbubble(d, rng):
    o(d, [50, 60, 300, 190], 22, fill=(255, 255, 255), w=6)
    d.polygon([(110, 188), (150, 188), (108, 232)], fill=(255, 255, 255), outline=INK)
    ln(d, [80, 100, 220, 100], 6, (120, 150, 200))
    ln(d, [80, 132, 260, 132], 5, (176, 182, 196))
    ell(d, [232, 60, 300, 128], fill=(224, 122, 110), w=5)
    d.text((254, 78), "1", fill=(255, 255, 255))

def waveform(d, rng):
    for i in range(12):
        x = 66 + i*20
        h = (14, 34, 52, 30, 60, 44, 24, 56, 38, 20, 46, 28)[i]
        ln(d, [x, 150-h, x, 150+h], 9, (110, 170, 160) if i % 2 else (96, 110, 160))
    ln(d, [60, 150, 300, 150], 3, (176, 182, 196))

def goldbox(d, rng):
    d.polygon([(70, 150), (290, 150), (310, 250), (50, 250)], fill=(160, 122, 92), outline=INK)
    d.rectangle([60, 120, 300, 152], fill=(140, 106, 80), outline=INK)
    for i, x in enumerate((100, 160, 220)):
        d.polygon([(x, 116), (x+18, 90), (x+52, 90), (x+70, 116)], fill=(240, 200, 90), outline=INK)
    ln(d, [70, 190, 290, 190], 4, (120, 90, 66))

def stepscard(d, rng):
    o(d, [60, 50, 300, 250], 12, fill=(255, 255, 255), w=6)
    for i, y in enumerate((86, 146, 206)):
        ell(d, [78, y-18, 118, y+22], fill=[(224, 122, 110), (240, 200, 90), (110, 170, 160)][i], w=4)
        d.text((92, y-8), str(i+1), fill=(255, 255, 255))
        ln(d, [134, y, 280, y], 6, (120, 128, 146))

def pollcard(d, rng):
    o(d, [80, 44, 280, 260], 12, fill=(52, 60, 88), w=6)
    for i, n in enumerate(("5", "4", "3", "2", "1")):
        y = 64 + i*38
        ell(d, [100, y, 132, y+32], fill=(240, 200, 90) if i == 0 else (96, 110, 160), w=0)
        d.text((110, y+2), n, fill=(40, 44, 64))
        d.rectangle([146, y+8, 260, y+24], fill=(150, 200, 170) if i == 0 else (120, 130, 158))

NEWFUN.update(cashenvelope=cashenvelope, tollsign=tollsign, mapusa=mapusa,
              commentbubble=commentbubble, waveform=waveform, goldbox=goldbox,
              stepscard=stepscard, pollcard=pollcard)

def build_plan():
    plan = []
    def add(name, cat, fn, n=1):
        for i in range(n):
            plan.append((f'{name}_{i+1:02d}' if n > 1 else name, cat, fn))
    add('bush', 'nature', bush, 4)
    add('flowers', 'nature', flowers, 4)
    add('tree', 'nature', tree_small, 3)
    add('grass', 'nature', grass, 4)
    add('pine', 'nature', pine, 3)
    add('rock', 'nature', rock, 2)
    add('mushroom', 'nature', mushroom, 2)
    add('cone', 'nature', cone, 1)
    add('lamppost', 'street', lamppost, 3)
    add('hydrant', 'street', hydrant, 2)
    add('mailbox', 'street', mailbox, 2)
    add('bench', 'street', bench, 2)
    add('fence', 'street', fence, 3)
    add('sign', 'street', sign, 3)
    add('trashbin', 'street', trashbin, 2)
    add('wallclock', 'home', wallclock, 2)
    add('photoframe', 'home', photoframe, 3)
    add('lamp', 'home', lamp, 2)
    add('bookshelf', 'home', bookshelf, 2)
    add('tv', 'home', tv, 2)
    add('plant', 'home', potted_plant, 3)
    add('sofa', 'home', sofa, 2)
    add('kettle', 'home', kettle, 2)
    add('cup', 'home', cup, 2)
    add('whiteboard', 'office', whiteboard, 2)
    add('cooler', 'office', watercooler, 2)
    add('printer', 'office', printer, 2)
    add('papers', 'office', papers, 2)
    add('mug', 'office', mug, 2)
    add('cubicle', 'office', cubicle, 2)
    add('newspaper', 'props', newspaper, 2)
    add('book', 'props', book, 2)
    add('pill', 'props', pill, 2)
    add('radio', 'props', radio, 2)
    add('dog', 'props', dog, 2)
    add('cat', 'props', cat, 2)
    add('bird', 'props', bird, 2)
    add('star', 'extras', star, 3)
    add('heart', 'extras', heart, 2)
    add('arrow', 'extras', arrow, 2)
    add('giftcard', 'extras', giftcard, 4)
    add('signpost', 'extras', signpost, 3)
    add('cloud', 'extras', cloud_doodle, 2)
    add('sun', 'extras', sun, 1)
    # ---- v4.0: +60 objek cerita ----
    add('passport', 'travel', passport, 3)
    add('suitcase', 'travel', suitcase, 3)
    add('bigcheck', 'money', bigcheck, 3)
    add('gavel', 'legal', gavel, 3)
    add('handcuffs', 'legal', handcuffs, 2)
    add('roses', 'romance', roses, 3)
    add('ringbox', 'romance', ringbox, 2)
    add('phonechat', 'romance', phonechat, 3)
    add('trophy', 'extras', trophy, 2)
    add('confetti', 'extras', confetti, 3)
    add('ssncard', 'money', ssncard, 3)
    add('creditcard', 'money', creditcard, 3)
    add('usbdrive', 'office', usbdrive, 2)
    add('donationbox', 'extras', donationbox, 2)
    add('timer', 'urgency', timer, 3)
    add('goldbar', 'money', goldbar, 2)
    add('stamp', 'urgency', stamp, 2)
    add('popalert', 'office', popalert, 3)
    add('papersfly', 'office', papersfly, 2)
    add('medkit', 'medical', medkit, 3)
    add('crutch', 'medical', crutch, 2)
    add('syringe', 'medical', syringe, 2)
    add('moneyfly', 'money', moneyfly, 3)
    add('walletcoins', 'money', walletcoins, 2)
    # ---- v4.5: dari analisis narasi asli ----
    add('cashenvelope', 'money', cashenvelope, 2)
    add('tollsign', 'travel', tollsign, 2)
    add('mapusa', 'extras', mapusa, 2)
    add('commentbubble', 'extras', commentbubble, 2)
    add('waveform', 'extras', waveform, 2)
    add('goldbox', 'money', goldbox, 2)
    add('stepscard', 'extras', stepscard, 2)
    add('pollcard', 'extras', pollcard, 2)
    return plan

def main():
    os.makedirs(OUT, exist_ok=True)
    plan = build_plan()
    assert len(plan) >= 176, f'plan hanya {len(plan)}'
    plan = plan[:180]
    manifest = {}
    for i, (name, cat, fn) in enumerate(plan, 1):
        rng = random.Random(i*7 + 3)
        img = canvas()
        d = ImageDraw.Draw(img)
        fn(d, rng)
        fname = f'obj_{i:03d}.png'
        img.save(os.path.join(OUT, fname))
        manifest[fname] = dict(name=name, cat=cat)
    with open(os.path.join(OUT, 'manifest.json'), 'w') as f:
        json.dump(manifest, f, indent=1)
    from collections import Counter
    print('objpack:', len(plan), 'file ->', OUT)
    print(Counter(c for _, c, _ in plan))

if __name__ == '__main__':
    main()
