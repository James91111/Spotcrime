#!/usr/bin/env python3
# ============================================================
#  A2VIDEO — pipeline AUDIO-FIRST (master timing = folder wav)
#  Alur sesuai keinginan user:
#   1) baca folder audio pecahan (mis. _tmp_tts_edge/edge_tmp_00001.wav ...)
#   2) pecahan < 5 dtk DIGABUNG dgn pecahan berikutnya (kumulatif)
#      → visual tidak melompat; durasi audio = durasi klip
#   3) semua klip video dibuat (compose aset CC0), lalu dipasangkan
#      dgn pecahan audio sesuai URUTAN → concat → final.mp4
#
#  Pakai:
#    python a2video.py --scan  _tmp_tts_edge           # lihat rencana
#    python a2video.py --merge _tmp_tts_edge -o out_k  # gabung audio
#    python a2video.py --build out_k                   # render + gabung
#    python a2video.py --all   _tmp_tts_edge -o out_k  # merge + build
#  Opsi build: --fps 12 --srt subtitle.srt (teks kinetik per segmen)
# ============================================================
import os, sys, glob, json, re, subprocess, shutil
from stickanim import find_ffmpeg
import kenney, stage, smartsub, paths

MERGE_MIN = 5.0

def voice_env(wav, fps, dur):
    """Envelope suara per-frame (0..1) utk animasi mulut sinkron audio."""
    try:
        import numpy as np, soundfile as sf
        data, sr = sf.read(wav, dtype='float32')
        if data.ndim > 1: data = data.mean(axis=1)
        n = max(2, int(round(dur*fps)))
        L = len(data); win = max(1, L//n)
        env = []
        for k in range(n):
            a = k*win; b = min(L, a+win)
            env.append(float(np.sqrt(np.mean(data[a:b]**2))) if b > a else 0.0)
        m = max(env) or 1.0
        env = [min(1.0, (e/m)**0.6*1.15) for e in env]
        for k in range(1, n):
            env[k] = 0.55*env[k] + 0.45*env[k-1]
        env = [0.0 if e < 0.08 else e for e in env]   # jeda = mulut rapat
        return env
    except Exception:
        return None   # pecahan di bawah ini digabung dgn berikutnya

def ffprobe_len(ff, path):
    # binari imageio/Termux tidak selalu punya -show_entries → parse stderr
    r = subprocess.run([ff, '-i', path], capture_output=True, text=True)
    m = re.search(r'Duration: (\d+):(\d+):(\d+\.\d+)', r.stderr)
    if not m: return 0.0
    h, mi, s = m.groups()
    return int(h)*3600 + int(mi)*60 + float(s)

# ---------------- STAGE A: scan + merge --------------------------
def scan(ff, folder):
    """kembalikan rencana segmen: list dict(audio(list raw), dur, merged_path?)"""
    files = sorted(glob.glob(os.path.join(folder, '*.wav')))
    if not files:
        print(f'tidak ada .wav di {folder}'); sys.exit(1)
    durs = [ffprobe_len(ff, f) for f in files]
    segs, cur, curd = [], [], 0.0
    for f, d in zip(files, durs):
        cur.append(f); curd += d
        if curd >= MERGE_MIN:
            segs.append(dict(src=cur, dur=round(curd, 3))); cur, curd = [], 0.0
    if cur:  # sisa terakhir: gabung ke segmen terakhir bila masih < 5 dtk
        if segs and curd < MERGE_MIN:
            segs[-1]['src'] += cur; segs[-1]['dur'] = round(segs[-1]['dur'] + curd, 3)
        else:
            segs.append(dict(src=cur, dur=round(curd, 3)))
    return segs

def scan_srt(ff, srt_path, audio_dir):
    """SRT = master durasi klip (permintaan user):
    cue >= 5 dtk  → 1 klip tunggal, dipasangkan dgn audio pecahannya
    cue <  5 dtk  → digabung dgn cue berikutnya (kumulatif) = 1 klip
    Audio pecahan (urut nama) dipasangkan 1:1 dgn urutan cue;
    audio digabung dulu per segmen, lalu ditempel ke klipnya."""
    from srt2video import parse_srt
    cues = parse_srt(srt_path)
    wavs = sorted(glob.glob(os.path.join(audio_dir, '*.wav')))
    if not cues:
        print('srt kosong'); sys.exit(1)
    if not wavs:
        print(f'tidak ada .wav di {audio_dir}'); sys.exit(1)
    n = min(len(cues), len(wavs))
    if len(cues) != len(wavs):
        print(f'!! jumlah cue srt ({len(cues)}) != jumlah wav ({len(wavs)}) '
              f'→ pakai {n} pertama')
    cues, wavs = cues[:n], wavs[:n]
    segs, cur, curd = [], [], 0.0
    for (t0, t1, text), w in zip(cues, wavs):
        cur.append((w, text)); curd += (t1 - t0)
        if curd >= MERGE_MIN:
            segs.append(dict(src=[w for w, _ in cur],
                             text=' '.join(t for _, t in cur),
                             dur=round(curd, 3), srt_dur=round(curd, 3)))
            cur, curd = [], 0.0
    if cur:
        if segs and curd < MERGE_MIN:      # sisa <5 dtk → gabung ke terakhir
            w0, _ = zip(*cur)
            segs[-1]['src'] += list(w0)
            segs[-1]['text'] += ' ' + ' '.join(t for _, t in cur)
            segs[-1]['dur'] = round(segs[-1]['dur'] + curd, 3)
            segs[-1]['srt_dur'] = segs[-1]['dur']
        else:
            segs.append(dict(src=[w for w, _ in cur],
                             text=' '.join(t for _, t in cur),
                             dur=round(curd, 3), srt_dur=round(curd, 3)))
    return segs

def print_plan(segs):
    print(f'--- rencana {len(segs)} segmen ---')
    for i, s in enumerate(segs, 1):
        print(f'  #{i:02d} {s["dur"]:5.1f}dtk  <- {len(s["src"])} pecahan: '
              + ' + '.join(os.path.basename(x) for x in s['src'][:3])
              + (' ...' if len(s['src']) > 3 else ''))

def merge(ff, segs, outdir):
    os.makedirs(outdir, exist_ok=True)
    meta = []
    for i, s in enumerate(segs, 1):
        dst = os.path.join(outdir, f'aud_{i:03d}.wav')
        if len(s['src']) == 1:
            subprocess.run([ff, '-y', '-loglevel', 'error', '-i', s['src'][0],
                            '-ar', '24000', '-ac', '1', '-c:a', 'pcm_s16le', dst],
                           capture_output=True)
        else:
            # filter_complex concat: tahan input beda-beda format
            cmd = [ff, '-y', '-loglevel', 'error']
            for p in s['src']: cmd += ['-i', p]
            n = len(s['src'])
            cmd += ['-filter_complex', f'concat=n={n}:v=0:a=1',
                    '-ar', '24000', '-ac', '1', '-c:a', 'pcm_s16le', dst]
            subprocess.run(cmd, capture_output=True)
        # bila ada durasi srt → audio dipadukan silense persis sepanjang itu
        # supaya klip dan audio tetap sinkron saat di-concat
        if s.get('srt_dur'):
            pad = dst + '.pad.wav'
            subprocess.run([ff, '-y', '-loglevel', 'error', '-i', dst, '-af',
                            f'apad=whole_dur={float(s["srt_dur"]):.3f}',
                            '-ar', '24000', '-ac', '1', '-c:a', 'pcm_s16le', pad],
                           capture_output=True)
            if os.path.exists(pad) and os.path.getsize(pad) > 44:
                os.replace(pad, dst)
        d = ffprobe_len(ff, dst)
        meta.append(dict(audio=os.path.abspath(dst), dur=round(d, 3),
                         text=s.get('text', ''),
                         src=[os.path.basename(w) for w in s.get('src', [])]))
        print(f'  merged #{i:02d} {d:.1f}dtk')
    with open(os.path.join(outdir, 'segments.json'), 'w') as f:
        json.dump(meta, f, indent=1)
    print(f'>>> {len(meta)} audio gabungan -> {outdir}/segments.json')
    return meta

# ---------------- STAGE B: build video ---------------------------
MOTIF_HIST = []
_WB = None
def _wordbounds():
    global _WB
    if _WB is None:
        cands = [os.path.join(paths.BASE, 'wordbounds.json'),
                 os.path.join(os.path.dirname(paths.BASE), 'wordbounds.json')]
        _env = os.environ.get('A2_BASE')
        if _env: cands.insert(0, os.path.join(_env, 'wordbounds.json'))
        for c in cands:
            try:
                _WB = json.load(open(c)); break
            except Exception:
                _WB = []
    return _WB or []

def _seg_bounds(m, dur):
    """bounds kata milik segmen INI: petakan pecahan (src) -> urutan chunk.
    Klip gabungan: waktu digeser kumulatif sepanjang pecahan sebelumnya.
    Tanpa peta -> None (fallback proporsional; TIDAK PERNAH menebak teks)."""
    wb = _wordbounds()
    if not wb: return None
    import re as _re
    src = m.get('src') or []
    if not src: return None
    idxs = []
    for s in src:
        mm = _re.search(r'(\d+)', os.path.basename(s))
        if not mm: return None
        idxs.append(int(mm.group(1)) - 1)
    out, off = [], 0.0
    for ix in idxs:
        if not (0 <= ix < len(wb)): return None
        bnd = wb[ix].get('bounds') or []
        if not bnd: return None
        for a, b, w in bnd:
            out.append((a + off, b + off, w))
        off += float(wb[ix].get('dur') or 0.0)
    return out or None

def spec_for(i, m):
    """adegan utk segmen ke-i (dipakai build & preview GUI)
    Visual = stage (motif sesuai narasi, VARIATIF: hindari 3 motif terakhir)
    Teks   = smartsub.full_captions (SUBTITLE PENUH, semua kata, pita atas)"""
    dur = max(1.0, m['dur'])
    text = m.get('text', '') or ''
    spec = stage.auto_scene(text, dur, i, avoid=list(MOTIF_HIST[-3:]))
    MOTIF_HIST.append(spec.get('motif', 'neutral'))
    if len(MOTIF_HIST) > 6: del MOTIF_HIST[:-6]
    caps = _seg_bounds(m, dur)                    # v4.2: peta benar per segmen
    spec['captions'] = (smartsub.word_captions(caps, dur)
                        if caps else smartsub.full_captions(text, dur))
    return spec

def _split_shots(text, dur):
    """Pecah teks klip panjang jadi sub-adegan per kalimat (min 2.2 dtk)."""
    import re as _re
    sents = [x.strip() for x in _re.split(r'(?<=[.!?])\s+', (text or '').strip()) if x.strip()]
    if len(sents) < 2 or dur < 6.0:
        return [(text or '', dur)]
    tot = sum(len(x) for x in sents) or 1
    shots = [[x, dur * len(x) / tot] for x in sents]
    merged = []
    for x, d in shots:
        if d < 2.2 and merged:
            merged[-1][0] += ' ' + x; merged[-1][1] += d
        else:
            merged.append([x, d])
    return [(x, d) for x, d in merged]

def _render_multi(shots, caps, env, fps, fdir, seg_idx):
    """Render sub-shot berurutan dalam SATU klip; subtitle pakai waktu GLOBAL
    (jadi teks tetap sinkron audio walau visualnya cut-per-kalimat)."""
    import kinetic
    os.makedirs(fdir, exist_ok=True)
    fpaths, idx, start = [], 0, 0.0
    for si, (stext, sdur) in enumerate(shots):
        sp = stage.auto_scene(stext, sdur, seg_idx * 10 + si,
                              avoid=list(MOTIF_HIST[-3:]))
        if si > 0:
            sp['flash'] = True                # v4.3: kilat cut ala film
        MOTIF_HIST.append(sp.get('motif', 'neutral'))
        if len(MOTIF_HIST) > 6: del MOTIF_HIST[:-6]
        if env:
            sp['plus'] = True
            sp['env'], sp['env_fps'] = env, fps
            sp['env_off'] = start
        n = max(2, int(round(sdur * fps)))
        for f in range(n):
            g = start + f / fps
            img = stage.render_spec_frame(sp, f / fps)
            for (c0, c1, txt) in caps:
                if c0 <= g < c1 and txt:
                    prog = (g - c0) / max(0.01, c1 - c0)
                    style = kinetic.pick_style(txt, int(c0 * 10) + seg_idx)
                    img = kinetic.draw_chunk(img, txt, style, prog)
                    break
            p = os.path.join(fdir, 'f%03d.png' % idx)
            img.save(p); fpaths.append(p); idx += 1
        start += sdur
    return fpaths

def _silence_wav(dur):
    """v4.6: track senyap agar SEMUA klip punya audio (amannya concat + mux)"""
    import wave as _wave, tempfile
    fd, path = tempfile.mkstemp(suffix='.wav'); os.close(fd)
    w = _wave.open(path, 'wb'); w.setnchannels(1); w.setsampwidth(2); w.setframerate(22050)
    w.writeframes(b'\x00\x00\x00\x00' * int(dur*22050)); w.close()
    return path

def build(ff, outdir, fps=12, srt_path=None, voice='en-US-AndrewNeural', plus=True,
          sfx=True, music=True, musik_vol=1.0, sfx_vol=0.7, vo_vol=1.0):
    mfile = os.path.join(outdir, 'segments.json')
    if not os.path.exists(mfile):
        print('segments.json tidak ada — jalankan --merge dulu'); sys.exit(1)
    meta = json.load(open(mfile))
    durs_all, moods_all = [], []
    try:
        import musik as _musik
    except Exception:
        _musik = None

    # teks kinetik: dari srt (cue ke-i utk segmen ke-i) kalau ada
    if srt_path and not os.path.isabs(srt_path):
        cand = os.path.join(paths.BASE, srt_path)
        srt_path = cand if os.path.exists(cand) else srt_path
    if srt_path and os.path.exists(srt_path):
        sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
        from srt2video import parse_srt
        cues = parse_srt(srt_path)
        for i, m in enumerate(meta):
            if not m.get('text'):
                m['text'] = cues[i][2] if i < len(cues) else ''
        json.dump(meta, open(mfile, 'w'), indent=1)

    clips = []
    total = sum(m['dur'] for m in meta)
    print(f'=== BUILD: {len(meta)} klip | total audio {total/60:.1f} mnt ===')
    for i, m in enumerate(meta, 1):
        dur = max(1.0, m['dur'])
        print(f'[{i}/{len(meta)}] {dur:.1f}dtk ...', flush=True)
        spec = spec_for(i, m)
        env = voice_env(m['audio'], fps, dur) if plus else None
        if plus:
            spec['plus'] = True
            if env: spec['env'], spec['env_fps'] = env, fps
        durs_all.append(dur)
        moods_all.append(_musik.MOOD_BY_MOTIF.get(str(spec.get('motif', '')).split('-')[0],
                                                  'neutral') if _musik else 'neutral')
        shots = _split_shots(m.get('text', '') or '', dur)
        fdir = os.path.join(outdir, f'k{i:03d}_f')
        if len(shots) <= 1:
            fpaths = stage.render_scene(spec, fps, fdir)
        else:
            print(f'   {len(shots)} sub-adegan: {[s[:28] for s, _ in shots]}')
            fpaths = _render_multi(shots, spec.get('captions') or [], env,
                                   fps, fdir, i)
        clip = os.path.join(outdir, f'k{i:03d}.mp4')
        bed = None
        if plus and sfx:
            try:
                import sfx as _sfx
                bed = _sfx.build_bed(dur, spec.get('motif', ''), m.get('text', ''), True, spec=spec)
            except Exception:
                bed = None
        if bed is None:                # v4.6: klip tanpa SFX tetap dapat track senyap
            bed = _silence_wav(dur)
        enc = [ff, '-y', '-loglevel', 'error', '-framerate', str(fps),
               '-i', os.path.join(fdir, 'f%03d.png'),
               '-i', bed, '-c:a', 'aac', '-b:a', '128k', '-shortest']
        enc += ['-c:v', 'libx264', '-pix_fmt', 'yuv420p', '-crf', '20', clip]
        ok = subprocess.run(enc, capture_output=True).returncode == 0
        if bed:
            try: os.remove(bed)
            except Exception: pass
        if not ok:
            print('   GAGAL render klip', i); sys.exit(1)
        for p in fpaths: os.remove(p)
        os.rmdir(fdir)
        clips.append(clip)

    # concat video
    lv = os.path.join(outdir, 'v.txt')
    with open(lv, 'w') as f:
        for c in clips: f.write(f"file '{os.path.abspath(c)}'\n")
    video = os.path.join(outdir, 'video.mp4')
    subprocess.run([ff, '-y', '-loglevel', 'error', '-f', 'concat', '-safe', '0',
                    '-i', lv, '-c', 'copy', video], capture_output=True)
    os.remove(lv)
    # concat audio (sudah urut) + mux
    la = os.path.join(outdir, 'a.txt')
    with open(la, 'w') as f:
        for m in meta: f.write(f"file '{m['audio']}'\n")
    audio = os.path.join(outdir, 'audio.wav')
    subprocess.run([ff, '-y', '-loglevel', 'error', '-f', 'concat', '-safe', '0',
                    '-i', la, '-ar', '44100', '-ac', '2',
                    '-c:a', 'pcm_s16le', audio], capture_output=True)
    os.remove(la)
    music_wav = None
    if music and _musik is not None and durs_all:
        try:
            music_wav = os.path.join(outdir, 'musik.wav')
            _musik.build_episode(durs_all, moods_all, music_wav)
        except Exception:
            music_wav = None
    final = os.path.join(outdir, 'final.mp4')
    mux = [ff, '-y', '-loglevel', 'error', '-i', video, '-i', audio]
    # v4.6: SFX dari track klip ikut dicampur (dulu terbuang); volume semua bisa diatur UI
    sfx_on = bool(plus and sfx)
    if music_wav and os.path.exists(music_wav):
        fc = ('[1:a]volume=%.2f[vo];[2:a]volume=%.2f[bg];' % (vo_vol, 0.55*musik_vol) +
              ('[0:a]volume=%.2f[sfx];' % sfx_vol if sfx_on else '') +
              ('[vo][bg][sfx]amix=inputs=3' if sfx_on else '[vo][bg]amix=inputs=2') +
              ':duration=first:dropout_transition=0:normalize=0[aout]')
        mux += ['-i', music_wav, '-filter_complex', fc, '-map', '0:v', '-map', '[aout]']
    elif sfx_on:
        mux += ['-filter_complex',
                '[1:a]volume=%.2f[vo];[0:a]volume=%.2f[sfx];'
                '[vo][sfx]amix=inputs=2:duration=first:dropout_transition=0:normalize=0[aout]'
                % (vo_vol, sfx_vol), '-map', '0:v', '-map', '[aout]']
    else:
        mux += ['-map', '0:v', '-map', '1:a']
    mux += ['-c:v', 'copy', '-c:a', 'aac', '-b:a', '160k', '-shortest', final]
    r = subprocess.run(mux, capture_output=True)
    if r.returncode == 0:
        for c in clips: os.remove(c)
        os.remove(video)
        try:    # salin hasil ke folder out/ (jalur utama)
            shutil.copy2(final, os.path.join(paths.OUT, 'final.mp4'))
            print(f'>>> salinan: {os.path.join(paths.OUT, "final.mp4")}')
        except Exception:
            pass
        print(f'=== SELESAI: {final} ({len(meta)} klip, {total/60:.1f} mnt) ===')
    else:
        print('mux gagal, video.mp4 dipertahankan')

# ---------------- CLI --------------------------------------------
def main():
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument('--scan', nargs='?', const=paths.AUDIO_IN, metavar='FOLDER',
                    default=None, help=f'default: {paths.AUDIO_IN}')
    ap.add_argument('--merge', nargs='?', const=paths.AUDIO_IN, metavar='FOLDER')
    ap.add_argument('--build', nargs='?', const=paths.WORK, metavar='OUTDIR')
    ap.add_argument('--all', nargs='?', const=paths.AUDIO_IN, metavar='FOLDER',
                    help='merge + build sekaligus')
    ap.add_argument('-o', '--out', default=paths.WORK)
    ap.add_argument('--fps', type=int, default=12)
    ap.add_argument('--srt', default=None, help='srt opsional: teks kinetik per segmen')
    ap.add_argument('--no-music', action='store_true',
                    help='matikan musik latar halus')
    ap.add_argument('--musik-vol', type=float, default=1.0,
                    help='pengali volume musik (0-1+)')
    ap.add_argument('--sfx-vol', type=float, default=0.7,
                    help='pengali volume efek suara (0-1+)')
    ap.add_argument('--vo-vol', type=float, default=1.0,
                    help='pengali volume narator (0-1+)')
    ap.add_argument('--no-sfx', action='store_true',
                    help='matikan efek suara halus (knock, koin, whoosh)')
    ap.add_argument('--no-plus', action='store_true',
                    help='matikan Animasi Plus (mulut sinkron, kedip, kamera, fade)')
    args = ap.parse_args()
    ff = find_ffmpeg()
    if not ff:
        print('ffmpeg tidak ada'); sys.exit(1)

    def _segs(folder):
        if args.srt:
            srt = args.srt
            if not os.path.isabs(srt):
                cand = os.path.join(paths.BASE, srt)
                srt = cand if os.path.exists(cand) else srt
            print(f'>>> mode SRT-MASTER: durasi klip dari {srt}')
            return scan_srt(ff, srt, folder)
        return scan(ff, folder)

    if args.scan:
        segs = _segs(args.scan); print_plan(segs)
    elif args.merge:
        segs = _segs(args.merge); print_plan(segs)
        merge(ff, segs, args.out)
    elif args.build:
        build(ff, args.build, args.fps, args.srt, plus=not args.no_plus, sfx=not args.no_sfx, music=not args.no_music, musik_vol=args.musik_vol, sfx_vol=args.sfx_vol, vo_vol=args.vo_vol)
    elif args.all:
        segs = _segs(args.all); print_plan(segs)
        merge(ff, segs, args.out)
        build(ff, args.out, args.fps, args.srt, plus=not args.no_plus, sfx=not args.no_sfx, music=not args.no_music, musik_vol=args.musik_vol, sfx_vol=args.sfx_vol, vo_vol=args.vo_vol)
    else:
        ap.print_help()

if __name__ == '__main__':
    main()
