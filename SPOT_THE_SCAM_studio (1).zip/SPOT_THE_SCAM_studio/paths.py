#!/usr/bin/env python3
# ============================================================
#  PATHS — satu sumber untuk semua lokasi input/output
#  Di HP (proot): semua menunjuk ke /root/storage/Aspotcrime
#  Struktur:
#    Aspotcrime/
#      audio_in/   ← user narok pecahan edge-tts (edge_tmp_XXXX.wav)
#      srt/        ← file .srt (teks kinetik)
#      work/       ← audio gabungan + segments.json (otomatis)
#      out/        ← final.mp4 per project (otomatis)
#      assets/     ← fonts + kenney (opsional, ada fallback)
#  Fallback otomatis ke ./Aspotcrime kalau /root tidak bisa ditulis.
# ============================================================
import os

PREFERRED = '/root/storage/Aspotcrime'

def _pick_base():
    env = os.environ.get('A2_BASE')
    if env:
        try:
            os.makedirs(env, exist_ok=True)
            if os.access(env, os.W_OK):
                return env
        except Exception:
            pass
    here = os.path.dirname(os.path.abspath(__file__))
    for b in (PREFERRED,
              os.path.join(os.path.dirname(here), 'Aspotcrime'),   # /home/user/Aspotcrime
              os.path.join(here, 'Aspotcrime'),
              os.getcwd()):
        try:
            os.makedirs(b, exist_ok=True)
            if os.access(b, os.W_OK):
                return b
        except Exception:
            pass
    return os.getcwd()

BASE = _pick_base()
AUDIO_IN = os.path.join(BASE, 'audio_in')
SRT      = os.path.join(BASE, 'srt')
WORK     = os.path.join(BASE, 'work')
OUT      = os.path.join(BASE, 'hasil')   # 'out' dihindari: di-exclude snapshot
ASSETS   = [os.path.join(BASE, 'assets'),
            os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'assets'),
            os.path.join(os.path.dirname(os.path.abspath(__file__)), 'assets')]

for d in (AUDIO_IN, SRT, WORK, OUT):
    try: os.makedirs(d, exist_ok=True)
    except Exception: pass

def font(weight, size='900'):
    """cari font Montserrat di semua lokasi aset"""
    for a in ASSETS:
        p = os.path.join(a, 'fonts', f'Montserrat-{weight}.ttf')
        if os.path.exists(p): return p
    return None

def kenney(rel):
    """path sprite kenney (rel, tanpa .png)"""
    for a in ASSETS:
        p = os.path.join(a, 'kenney', rel + '.png')
        if os.path.exists(p): return p
    return None

if __name__ == '__main__':
    print('BASE     :', BASE)
    print('AUDIO_IN :', AUDIO_IN)
    print('SRT      :', SRT)
    print('WORK     :', WORK)
    print('OUT      :', OUT)
    print('font     :', font('900'))
