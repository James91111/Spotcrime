#!/usr/bin/env python3
# ============================================================
#  SFX — v4.0: efek suara prosedural ringan (numpy, tanpa file)
#  Dibangun per-klip sbg "pond" audio: SELALU jauh lebih pelan
#  dr narator (peak 0.03-0.11), dicampur ffmpeg saat render klip.
#  Narator tetap dominan -> aman utk pemirsa 55+ & tablet adem.
# ============================================================
import math
import numpy as np

SR = 22050

def _env(n, a=0.008, r=0.06):
    e = np.ones(n, np.float32)
    na, nr = int(a*SR), int(r*SR)
    if na > 0: e[:na] = np.linspace(0, 1, na, dtype=np.float32)
    if nr > 0: e[-nr:] *= np.linspace(1, 0, nr, dtype=np.float32)
    return e

def _tone(f, dur, vol=0.5, decay=6.0):
    n = int(dur*SR)
    t = np.arange(n)/SR
    w = np.sin(2*np.pi*f*t) * np.exp(-decay*t)
    return (w*_env(n)*vol).astype(np.float32)

def _noise(dur, vol=0.4, decay=7.0):
    n = int(dur*SR)
    x = np.random.default_rng(7).uniform(-1, 1, n).astype(np.float32)
    y = np.zeros(n, np.float32)
    for i in range(2, n):
        y[i] = 0.62*x[i] + 0.26*y[i-1] + 0.12*y[i-2]
    t = np.arange(n)/SR
    return (y*np.exp(-decay*t)*_env(n)*vol).astype(np.float32)

def whoosh():   return _noise(0.30, 0.6, 9.0)

def knock():
    a = _tone(175, 0.09, 0.9, 38)
    b = _tone(92, 0.12, 0.7, 26)
    n = max(len(a), len(b))
    hit = np.zeros(n, np.float32)
    hit[:len(a)] += a
    hit[:len(b)] += b
    out = np.zeros(int(0.34*SR), np.float32)
    out[:n] += hit
    i = int(0.17*SR)
    out[i:i+n] += hit*0.75
    return out

def coin():
    return np.concatenate([_tone(1245, 0.09, 0.55, 8), _tone(1865, 0.22, 0.42, 5)])

def sad():
    return np.concatenate([_tone(392, 0.26, 0.4, 3), _tone(311, 0.26, 0.4, 3),
                           _tone(233, 0.6, 0.4, 1.8)])

def alert():
    return np.concatenate([_tone(880, 0.10, 0.45, 4), np.zeros(int(0.05*SR), np.float32),
                           _tone(880, 0.10, 0.45, 4)])

def ring():
    t = np.arange(int(0.5*SR))/SR
    w = (np.sin(2*np.pi*480*t) + np.sin(2*np.pi*425*t))*0.5
    w *= (0.6 + 0.4*np.sign(np.sin(2*np.pi*25*t)))       # trill
    e = _env(len(t), 0.01, 0.05)
    return (w*e*0.8).astype(np.float32)

def step(alt=0):
    n = int(0.09*SR)
    t = np.arange(n)/SR
    f = 95 + alt*14
    w = np.sin(2*np.pi*f*t)*np.exp(-30*t)*0.7
    x = np.random.default_rng(5+alt).uniform(-1, 1, n).astype(np.float32)
    w += x*np.exp(-45*t)*0.30
    return (w*_env(n, 0.004, 0.03)).astype(np.float32)

def success():
    return np.concatenate([_tone(523, 0.12, 0.4, 3), _tone(659, 0.12, 0.4, 3),
                           _tone(784, 0.32, 0.4, 2.5)])

GEN = dict(whoosh=whoosh, knock=knock, coin=coin, sad=sad, alert=alert, success=success,
          ring=ring, step=step)
_cache = {}
def get(name):
    if name == 'step2':
        return step(alt=1)
    if name not in _cache:
        _cache[name] = GEN[name]()
    return _cache[name]

# (vol, batas-peak) — semua KECIL, narator harus paling keras
PLACE = dict(whoosh=(1.20, 0.24), knock=(1.00, 0.18), coin=(0.80, 0.14),   # v4.6: diperkuat (dulu terlalu pelan)
             sad=(0.90, 0.20), alert=(0.85, 0.16), success=(0.90, 0.18),
             ring=(0.80, 0.13), step=(0.70, 0.07))

def events_for(motif, low, spec=None):
    """daftar (waktu 't<detik>', nama) per motif adegan (+aksi aktor bila ada)"""
    low = (low or '').lower()
    ev = []
    if spec:
        acts = []
        for a in (spec.get('actors') or []):
            acts.append(a.get('action') or '')
            for p0, p1, act in (a.get('phases') or []):
                acts.append(act)
        if any('phone' in x for x in acts) and motif in ('phone', 'callcenter'):
            ev += [('t0.05', 'ring'), ('t0.75', 'ring')]
        if any(x == 'walk' for x in acts):
            for k in range(7):
                ev.append((f't{1.0 + k*0.36:.2f}', 'step' + ('2' if k % 2 else '')))
    ev += list(_EV_MOTIF.get(motif, []))
    return ev

_EV_MOTIF = {
    'doorvisit': [('t0.1', 'knock'), ('t0.5', 'knock')],
    'sad': [('t0.2', 'sad')],
    'money': [('t0.2', 'coin'), ('t2.4', 'coin')],
    'danger': [('t0.1', 'alert'), ('t2.6', 'alert')],
    'urgency': [('t0.1', 'alert'), ('t2.6', 'alert')],
    'virus': [('t0.1', 'alert'), ('t2.6', 'alert')],
    'protect': [('t0.2', 'success'), ('t2.8', 'coin')],
    'recovery': [('t0.2', 'success'), ('t2.8', 'coin')],
    'family': [('t0.2', 'success'), ('t2.8', 'coin')],
    'family-call': [('t0.2', 'success'), ('t2.8', 'coin')],
    'prize': [('t0.2', 'success'), ('t2.8', 'coin')],
    'lottery': [('t0.2', 'success'), ('t2.8', 'coin')],
    'giftcards': [('t1.2', 'coin')],
    'wire': [('t1.2', 'coin')],
    'identity': [('t1.2', 'coin')],
    'charity': [('t1.2', 'coin')],
    'smstext': [('t0.2', 'ring')],
    'tollroad': [('t0.1', 'whoosh')],
    'voiceclone': [('t0.15', 'ring')],
    'stats': [('t0.1', 'whoosh')],
    'callerid': [('t0.5', 'alert')],
    'courierdoor': [('t0.1', 'knock'), ('t0.5', 'knock')],
    'goldcourier': [('t0.1', 'knock'), ('t1.5', 'coin')],
    'arrest': [('t0.2', 'alert')],
    'steps': [('t0.1', 'whoosh')],
    'comments': [('t0.2', 'success')],
    'phone': [('t0.05', 'whoosh')],
    'callcenter': [('t0.05', 'whoosh')],
}

def build_bed(dur, motif, low, enabled=True, spec=None):
    """bangun audio pond 1 klip -> path wav sementara (atau None)"""
    if not enabled:
        return None
    ev = events_for(motif, low, spec=spec)
    if not ev:
        return None
    n = int(dur*SR)
    mix = np.zeros(n, np.float32)
    for at, name in ev:
        try:
            t0 = float(at[1:])
        except Exception:
            t0 = 0.5
        w = get(name)
        g, cap = PLACE[name]
        i = int(min(max(t0, 0.0), max(0.0, dur-0.45))*SR)
        j = min(n, i+len(w))
        if j <= i:
            continue
        mix[i:j] += w[:j-i]*g
    peak = float(np.abs(mix).max()) if n else 0.0
    if peak > cap:
        mix *= cap/peak
    if float(np.abs(mix).max()) < 0.005:
        return None
    import os as _os, wave as _wave, tempfile
    pcm = (np.clip(mix, -1, 1)*32000).astype('<i2').tobytes()
    fd, path = tempfile.mkstemp(suffix='.wav')
    _os.close(fd)
    with _wave.open(path, 'wb') as f:
        f.setnchannels(1)
        f.setsampwidth(2)
        f.setframerate(SR)
        f.writeframes(pcm)
    return path

if __name__ == '__main__':
    for k in GEN:
        w = get(k)
        print(f'{k:8s} {len(w)/SR:.2f}s peak={float(np.abs(w).max()):.2f}')
