#!/usr/bin/env python3
# bikin subtitle_ep01.srt dari daftar kalimat (1 baris = 1 cue)
lines = [l.strip() for l in open('ep01_lines.txt', encoding='utf-8') if l.strip() and not l.startswith('#')]
WPM = 145.0
def ts(t):
    h = int(t // 3600); m = int(t % 3600 // 60); s = t % 60
    return f'{h:02d}:{m:02d}:{s:06.3f}'.replace('.', ',')
out, t = [], 0.0
for i, line in enumerate(lines, 1):
    dur = max(3.0, len(line.split()) / WPM * 60)
    out.append(f'{i}\n{ts(t)} --> {ts(t + dur - 0.2)}\n{line}\n')
    t += dur
open('subtitle_ep01.srt', 'w', encoding='utf-8').write('\n'.join(out))
print(f'{len(lines)} cue, estimasi {t/60:.1f} menit -> subtitle_ep01.srt')
