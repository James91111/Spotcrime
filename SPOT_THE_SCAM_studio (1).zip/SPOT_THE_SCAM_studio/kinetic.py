#!/usr/bin/env python3
# ============================================================
#  KINETIC — teks sinematik di atas animasi stickman
#  Aturan: teks SELALU di pita atas layar (tidak menutupi karakter)
#  Gaya: big / box / quote / warn / num  (bergilir otomatis)
# ============================================================
import os
from PIL import Image, ImageDraw, ImageFont

CANDIDATES = [
    os.path.join(os.path.dirname(os.path.abspath(__file__)), 'assets', 'fonts'),   # layout ZIP
    os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'assets', 'fonts'),
    os.path.join(os.path.dirname(os.path.abspath(__file__)), 'fonts'),
    '/home/user/assets/fonts',
]
if os.environ.get('A2_BASE'):
    CANDIDATES.insert(0, os.path.join(os.environ['A2_BASE'], 'assets', 'fonts'))
FONTS = {}
_FONT_WARN = False
def _font(weight, size):
    global _FONT_WARN
    key = (weight, size)
    if key not in FONTS:
        path = None
        for c in CANDIDATES:
            p = os.path.join(c, f'Montserrat-{weight}.ttf')
            if os.path.exists(p): path = p; break
        if path is None:
            # v4.3: font darurat TETAP UKURAN BESAR (dulu: kecil -> subtitle mungil)
            try:
                FONTS[key] = ImageFont.load_default(size)
            except TypeError:
                FONTS[key] = ImageFont.load_default()
            if not _FONT_WARN:
                _FONT_WARN = True
                print('KINETIC: Montserrat tidak ketemu — pakai font darurat ukuran penuh')
            return FONTS[key]
        FONTS[key] = ImageFont.truetype(path, size)
    return FONTS[key]

INK   = (30, 34, 58)
AMBER = (255, 184, 28)
RED   = (226, 54, 54)
GRAY  = (120, 128, 146)
BAND  = (255, 255, 255)

def wrap(d, text, font, maxw):
    words, lines, cur = text.split(), [], ''
    for w_ in words:
        t = (cur + ' ' + w_).strip()
        if d.textlength(t, font=font) <= maxw: cur = t
        else: lines.append(cur); cur = w_
    if cur: lines.append(cur)
    return lines

WARN_WORDS = ('scam', 'fake', 'never', 'warning', 'stop', 'danger', 'police', 'illegal')

def pick_style(chunk, cycle):
    low = chunk.lower()
    if any(w in low for w in WARN_WORDS): return 'warn'
    if low.startswith(('number ', 'step ')): return 'num'      # v4.5: countdown
    if any(ch.isdigit() or ch == '$' for ch in chunk): return 'num'
    return ('big', 'box')[cycle % 2]   # quote dihapus (bug tanda petik melayang)

def draw_chunk(img, text, style, prog):
    """prog 0..1 durasi chunk; muncul pop + naik, fade di akhir"""
    d = ImageDraw.Draw(img, 'RGBA')
    appear = min(1.0, prog * 5.0)              # pop-in cepat
    fade   = min(1.0, (1.0 - prog) * 6.0)      # fade-out di ujung
    alpha  = int(255 * appear * fade)
    if alpha <= 3: return img
    y_off = int((1 - appear) * 36)
    cx = 960
    size = 118
    f = _font(900, size)
    lines = wrap(d, text, f, 1700)
    lh = int(size * 1.16)
    total_h = len(lines) * lh
    y0 = 96 + y_off
    ov = Image.new('RGBA', img.size, (0, 0, 0, 0))
    od = ImageDraw.Draw(ov)

    if style == 'box' or style == 'num' or style == 'warn':
        fill = {'box': AMBER, 'num': AMBER, 'warn': RED}[style] + (alpha,)
        tw = max(od.textlength(t, font=f) for t in lines)
        pad_x, pad_y = 46, 26
        bw = tw + pad_x * 2
        od.rounded_rectangle([cx - bw/2, y0 - pad_y, cx + bw/2, y0 + total_h + pad_y],
                             radius=22, fill=fill)
        tcol = (255, 255, 255, alpha) if style in ('warn', 'num') else INK + (alpha,)
        for i, t in enumerate(lines):
            w_ = od.textlength(t, font=f)
            od.text((cx - w_/2, y0 + i*lh), t, font=f, fill=tcol)
    elif style == 'quote':
        qf = _font(900, 96)
        od.text((cx - 660, y0 - 18), '"', font=qf, fill=AMBER + (alpha,))
        for i, t in enumerate(lines):
            w_ = od.textlength(t, font=f)
            od.text((cx - w_/2 + 40, y0 + i*lh), t, font=f, fill=INK + (alpha,))
        for i, t in enumerate(lines):
            pass
    else:  # big
        for i, t in enumerate(lines):
            w_ = od.textlength(t, font=f)
            od.text((cx - w_/2, y0 + i*lh), t, font=f, fill=INK + (alpha,))
            # underline amber di baris terakhir
            if i == len(lines) - 1:
                od.rounded_rectangle([cx - w_/2, y0 + i*lh + lh - 14, cx + w_/2, y0 + i*lh + lh - 2],
                                     radius=6, fill=AMBER + (alpha,))
    return Image.alpha_composite(img.convert('RGBA'), ov).convert('RGB')

def chunk_text(text, max_words=5):
    """potong kalimat jadi potongan kinetik"""
    words = text.replace('"', '').split()
    chunks, cur = [], []
    for w_ in words:
        cur.append(w_)
        if len(cur) >= max_words or w_.endswith((',', '.', '!', '?', ':', ';')):
            chunks.append(' '.join(cur)); cur = []
    if cur: chunks.append(' '.join(cur))
    return chunks
