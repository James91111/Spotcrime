#!/usr/bin/env python3
# ============================================================
#  KENNEY ENGINE — adegan dari aset CC0 (Kenney, bebas hak cipta)
#  Prinsip: TIDAK menggambar karakter; hanya MENYUSUN (paste) sprite
#  → sangat ringan untuk HP/tablet (Mi Pad 6 / Termux / proot).
#
#  Adegan = {
#    "dur": 7.0, "bg": "plain|clouds|trees",
#    "actors":[{"sprite":"chars/p1","hat":None,"tint":None,"x":620,
#               "action":"talk|enter|exit|jump|hurt|duck","flip":False}],
#    "props":[{"sprite":"items/coinGold","x":1400,"y":640,"scale":2.6,
#              "anim":"pop|spin|float|pulse|drop","t0":0.5,"behind":False}],
#    "captions":[[0.3,6.5,"teks kinetik ..."]]
#  }
# ============================================================
import os, math, glob, random
from PIL import Image, ImageDraw, ImageFilter
import kinetic

ROOTS = [
    os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'assets', 'kenney'),
    '/home/user/assets/kenney',
    os.path.join(os.path.dirname(os.path.abspath(__file__)), 'assets', 'kenney'),
]
W, H = 1920, 1080
GROUND   = 860          # garis kaki karakter
FPS      = 12
CHAR_H   = 340          # tinggi karakter di layar (px)
BG_C   = (250, 250, 252)
INK    = (30, 34, 58)
DIM    = (176, 184, 200)
AMBER  = (255, 184, 28)
RED    = (226, 54, 54)
NAVY   = (18, 39, 90)

# ---- casting resmi (sprite CC0) --------------------------------
CAST = {
    'victim':  dict(sprite='chars/p1'),                                # mint
    'scammer': dict(sprite='chars/p3'),                                # pink
    'cop':     dict(sprite='chars/p2', tint=NAVY, hat='bg/item_hatTop', badge=True),
    'agent':   dict(sprite='chars/p2', tint=(30, 60, 130)),            # biru tua
    'bot':     dict(sprite='enemies/slimeWalk1'),
    'thief':   dict(sprite='enemies/pokerMad'),
}
PROPS = {
    'money': 'items/coinGold', 'card': 'items/coinSilver',
    'crypto': 'items/gemYellow', 'gems': 'items/gemRed',
    'danger': 'items/bomb', 'loss': 'items/weightChained',
    'win': 'items/flagRed', 'star': 'items/star',
    'key': 'items/keyYellow', 'lock': 'items/weightChained',
}

_cache = {}
def sprite(rel):
    """muat sprite CC0 (cache)"""
    if rel in _cache: return _cache[rel]
    p = None
    for r in ROOTS:
        c = os.path.join(r, rel + '.png')
        if os.path.exists(c): p = c; break
    if p is None: return None
    im = Image.open(p).convert('RGBA')
    _cache[rel] = im
    return im

def walk_frames(pref):
    """frame walk cycle cc0, urut"""
    out = None
    for r in ROOTS:
        fs = sorted(glob.glob(os.path.join(r, pref, '*.png')))
        if fs:
            out = [Image.open(f).convert('RGBA') for f in fs]; break
    return out

def tinted(im, color, k=0.55):
    a = im.getchannel('A')
    solid = Image.new('RGBA', im.size, color + (255,))
    out = Image.blend(im, solid, k)
    out.putalpha(a)
    return out

# ---- latar ------------------------------------------------------
_bg_cache = {}
def _bg_base(variant, seed=1):
    key = (variant, seed)
    if key in _bg_cache: return _bg_cache[key]
    img = Image.new('RGB', (W, H), BG_C)
    d = ImageDraw.Draw(img)
    # dot grid khas tema putih
    for gy in range(60, H, 46):
        for gx in range(40, W, 46):
            d.ellipse([gx-1.5, gy-1.5, gx+1.5, gy+1.5], fill=(225, 230, 240))
    # garis tanah
    d.rectangle([0, GROUND+8, W, GROUND+16], fill=(228, 232, 242))
    rng = random.Random(seed)
    if variant == 'clouds':
        for i, (c, x, y, s) in enumerate([
                ('bg/background_cloudA', 100, 470, 3.4),
                ('bg/background_cloudB', 860, 520, 2.8),
                ('bg/background_cloudA', 1520, 490, 3.0)]):
            im = sprite(c)
            if im is None: continue
            im = im.resize((int(im.width*s), int(im.height*s)))
            al = im.getchannel('A').point(lambda v: int(v*0.35))
            im.putalpha(al)
            img.paste(im, (x, y), im)
    elif variant == 'trees':
        for i in range(5):
            im = sprite('bg/background_treeLarge' if i % 2 else 'bg/background_tree')
            if im is None: continue
            s = 3.4 + rng.random()*1.6
            im = im.resize((int(im.width*s), int(im.height*s)))
            al = im.getchannel('A').point(lambda v: int(v*0.22))
            im.putalpha(al)
            x = int(i*(W-400)/4) + rng.randint(-40, 40)
            img.paste(im, (x, GROUND+8-im.height), im)
    _bg_cache[key] = img
    return img

def _shadow(img, cx, cy, w):
    d = ImageDraw.Draw(img, 'RGBA')
    d.ellipse([cx-w/2, cy-10, cx+w/2, cy+10], fill=(210, 214, 226, 120))

# ---- aktor ------------------------------------------------------
def _pose(actor, name):
    base = actor['sprite']
    if name == 'walk':
        fr = actor.get('_walk')
        if fr: return fr[actor.get('_wi', 0) % len(fr)]
        name = 'stand'
    im = sprite(f'{base}_{name}')
    if im is None: im = sprite(f'{base}_stand')
    return im

def _actor_frame(img, a, now, dur, i, rng):
    act = a.get('action', 'talk')
    h   = a.get('height', CHAR_H)
    ground = GROUND
    x   = a.get('x', 640)
    pose, yoff, xoff, rot = 'stand', 0.0, 0.0, 0.0

    if act == 'enter':
        span = min(1.6, dur*0.35)
        if now < span:
            t = now / span
            side = -1 if a.get('side', 'left') == 'left' else 1
            xoff = side * (1-t) * (W/2 + 300)
            pose, a['_wi'] = 'walk', int(now*FPS/2.6)
        else:
            pose = 'stand'
    elif act == 'exit':
        span = min(1.6, dur*0.3)
        if now > dur - span:
            t = (now - (dur-span)) / span
            side = 1 if a.get('side', 'left') == 'left' else -1
            xoff = side * t * (W/2 + 300)
            pose, a['_wi'] = 'walk', int(now*FPS/2.6)
        else: pose = 'stand'
    elif act == 'jump':
        pose = 'stand'
        for k in range(2):
            t0 = 0.28 + k*0.34
            if t0 <= now/dur <= t0+0.18:
                f = (now/dur - t0) / 0.18
                yoff = -math.sin(math.pi*f) * 190
                pose = 'jump'
    elif act == 'hurt':
        pose = 'stand'
        t0 = dur*0.55
        if now > t0:
            pose = 'hurt'
            ph = int((now-t0)*FPS)
            xoff = (6 if ph % 2 else -6) * max(0.2, 1-(now-t0)/max(0.1, dur-t0))
    elif act == 'duck':
        pose = 'duck' if now > dur*0.45 else 'stand'
    else:  # talk — bobbing halus + ganti pose stand/front
        pose = 'front' if int(now*2.2) % 3 == 0 else 'stand'
        yoff = -abs(math.sin(now*2.6)) * 9

    im = _pose(a, pose)
    if im is None: return
    s = h / im.height
    im = im.resize((max(1,int(im.width*s)), max(1,int(im.height*s))), Image.LANCZOS)
    if a.get('tint'): im = tinted(im, a['tint'])
    if a.get('flip'):
        im = im.transpose(Image.FLIP_LEFT_RIGHT)
    if rot: im = im.rotate(rot, expand=True, resample=Image.BICUBIC)
    px = int(x + xoff - im.width/2)
    py = int(ground + yoff - im.height)
    _shadow(img, x + xoff, ground + 6, im.width*0.8)
    img.paste(im, (px, py), im)
    # topi (mis. polisi)
    if a.get('hat'):
        hm = sprite(a['hat'])
        if hm is not None:
            hs = (im.width*0.62) / hm.width
            hm = hm.resize((int(hm.width*hs), int(hm.height*hs)), Image.LANCZOS)
            hm = hm.rotate(-7, expand=True, resample=Image.BICUBIC)
            if a.get('flip'): hm = hm.transpose(Image.FLIP_LEFT_RIGHT)
            img.paste(hm, (px + (im.width-hm.width)//2, py - int(hm.height*0.62)), hm)
    if a.get('badge'):  # lencana polisi
        d = ImageDraw.Draw(img, 'RGBA')
        bx, by = px + im.width//2, py + int(im.height*0.56)
        d.polygon([(bx, by-16), (bx+13, by-5), (bx+8, by+13), (bx-8, by+13), (bx-13, by-5)],
                  fill=AMBER)
        d.ellipse([bx-5, by-3, bx+5, by+7], fill=(255,255,255))

# ---- prop -------------------------------------------------------
def _prop_frame(img, p, now, dur, rng):
    im = sprite(p.get('sprite', 'items/coinGold'))
    if im is None: return
    t0 = float(p.get('t0', 0.4))
    anim = p.get('anim', 'pop')
    s = float(p.get('scale', 2.6))
    x, y = p.get('x', 1400), p.get('y', 660)
    base = im.resize((int(im.width*s), int(im.height*s)), Image.LANCZOS)

    if now < t0: return
    tt = now - t0
    if anim == 'pop':
        k = min(1.0, tt/0.28)
        k = 1 + (1-k) * math.cos(min(1.0, k)*math.pi) * -0.0  # diperlambat di bawah
        cur = base
        if tt < 0.34:
            e = tt/0.34
            sc = 0.35 + 0.65*e + math.sin(e*math.pi)*0.12
            cur = base.resize((max(1,int(base.width*sc)), max(1,int(base.height*sc))), Image.LANCZOS)
    elif anim == 'spin':
        cur = base.rotate(-(tt*260) % 360, expand=True, resample=Image.BICUBIC)
    elif anim == 'pulse':
        sc = 1 + math.sin(tt*4.2)*0.06
        cur = base.resize((int(base.width*sc), int(base.height*sc)), Image.LANCZOS)
    elif anim == 'float':
        cur = base
        y += math.sin(tt*2.1) * 16
    elif anim == 'drop':
        fall = min(1.0, tt/0.5)
        yy = y - (1-fall)*(y-40)
        bounce = math.sin(fall*math.pi)*0
        cur = base
        _shadow(img, x, GROUND+6, base.width*0.7)
        img.paste(cur, (int(x-cur.width/2), int(yy-cur.height/2)), cur)
        return
    else:
        cur = base
    _shadow(img, x, min(y+cur.height/2, GROUND+6), base.width*0.7)
    img.paste(cur, (int(x-cur.width/2), int(y-cur.height/2)), cur)

# ---- render -----------------------------------------------------
def render_spec_frame(spec, now):
    """satu frame pada detik `now` — dipakai renderer & preview GUI"""
    rng = random.Random(int(spec.get('seed', 7)) + int(now*100))
    img = _bg_base(spec.get('bg', 'plain'), spec.get('seed', 7)).copy()
    for p in spec.get('props', []):
        if p.get('behind'): _prop_frame(img, p, now, spec['dur'], rng)
    for a in spec.get('actors', []):
        _actor_frame(img, a, now, spec['dur'], 0, rng)
    for p in spec.get('props', []):
        if not p.get('behind'): _prop_frame(img, p, now, spec['dur'], rng)
    # getar utk aksi hurt
    if any(a.get('action') == 'hurt' and now > spec['dur']*0.55 for a in spec.get('actors', [])):
        dx, dy = rng.choice([-6, 6]), rng.choice([-3, 3])
        img = img.transform((W, H), Image.AFFINE, (1, 0, dx, 0, 1, dy),
                            resample=Image.BILINEAR, fillcolor=BG_C)
    for (c0, c1, text) in spec.get('captions', []):
        if c0 <= now < c1 and text:
            prog = (now - c0) / max(0.01, c1 - c0)
            style = kinetic.pick_style(text, int(c0*10) + spec.get('seed', 7))
            img = kinetic.draw_chunk(img, text, style, prog)
    return img

def render_scene(spec, fps=FPS, fdir='frames_k'):
    """render 1 adegan → path frame png (list)"""
    os.makedirs(fdir, exist_ok=True)
    n = max(2, int(round(spec['dur'] * fps)))
    paths = []
    for i in range(n):
        fr = render_spec_frame(spec, i / fps)
        p = os.path.join(fdir, f'f{i:03d}.png')
        fr.save(p)
        paths.append(p)
    return paths

# ---- auto-scene drpd kata kunci ---------------------------------
def auto_scene(text, dur, idx, two_actors=None):
    """bangun adegan otomatis dr isi kalimat (deterministik per idx)"""
    low = (text or '').lower()
    rng = random.Random(idx*13 + 5)
    spec = {'dur': dur, 'seed': idx*13 + 5, 'actors': [], 'props': [], 'captions': []}
    spec['bg'] = ['plain', 'clouds', 'trees'][idx % 3]

    def A(role, action='talk', side='left'):
        c = dict(CAST[role]); c['action'] = action; c['side'] = side
        c['x'] = 640 if side == 'left' else 1290
        c['flip'] = (side == 'right')
        spec['actors'].append(c); return c

    def P(prop, anim='pop', x=1420, y=640, scale=3.0, t0=0.5, behind=False):
        spec['props'].append(dict(sprite=PROPS[prop], anim=anim, x=x, y=y,
                                  scale=scale, t0=t0, behind=behind))

    drama = any(k in low for k in ('scam', 'never', 'warning', 'stop', 'danger',
                                   'stole', 'lost', 'illegal', 'fake'))
    if any(k in low for k in ('police', 'fbi', 'agent', 'investigat', 'report to')):
        A('victim', 'talk', 'left'); A('cop', 'enter', 'right')
        P('win', 'pulse', x=1560, y=560, scale=2.6, t0=dur*0.5)
    elif any(k in low for k in ('gift card', 'card', 'wire', 'crypto', 'bitcoin', 'transfer')):
        A('scammer', 'talk', 'left'); A('victim', 'hurt', 'right')
        P('card' if 'crypto' not in low else 'crypto', 'drop', x=960, y=430, scale=2.8, t0=0.6)
    elif any(k in low for k in ('$', 'dollar', 'thousand', 'million', 'billion', 'money', 'cost', 'paid')):
        A('victim', 'talk', 'left')
        P('money', 'spin', x=1380, y=600, scale=3.4, t0=0.4)
        P('money', 'pop',  x=1600, y=480, scale=2.2, t0=dur*0.45)
    elif any(k in low for k in ('password', 'account', 'bank', 'freeze', 'lock')):
        A('victim', 'talk', 'left'); P('key', 'pop', x=1420, y=620, t0=0.5)
    elif any(k in low for k in ('recover', 'protect', 'safe', 'smart', 'hang up', 'defense', 'defend')):
        A('victim', 'jump', 'left'); P('star', 'pulse', x=1400, y=520, scale=3.0, t0=0.4)
    elif drama:
        A('scammer', 'talk', 'left'); A('victim', 'hurt', 'right')
        P('danger', 'pulse', x=960, y=520, scale=2.8, t0=dur*0.35)
    elif any(k in low for k in ('robot', 'ai', 'bot', 'computer', 'voice')):
        A('bot', 'talk', 'left'); P('gems', 'float', x=1400, y=560, scale=2.6, t0=0.5)
    else:
        # rotasi netral biar variatif
        r = idx % 3
        if r == 0:   A('victim', 'talk', 'left')
        elif r == 1: A('victim', 'talk', 'left'); P('star', 'float', x=1420, y=540, t0=0.6)
        else:        A('scammer', 'talk', 'left'); A('victim', 'talk', 'right')
    return spec

if __name__ == '__main__':
    import sys
    s = auto_scene('Never send gift cards to a stranger.', 6.0, 1)
    print('contoh adegan:', s['actors'][0]['sprite'], 'bg =', s['bg'])
    fr = render_spec_frame(s, 2.0)
    fr.save('kenney_preview.jpg', quality=90)
    print('preview -> kenney_preview.jpg')
