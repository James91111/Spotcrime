#!/usr/bin/env python3
# ============================================================
#  MUSIK — v4.2: musik latar prosedural (numpy, tanpa file)
#  Satu jalur musik per episode: ganti MOOD mengikuti motif
#  tiap klip (netral/tense/warm/uplift), DIPASTIKAN jauh lebih
#  pelan dr narator (peak ~0.085 vs narasi ~0.89) + volume
#  turun lg saat mux (0.55). Bisa dimatikan via checkbox.
# ============================================================
import math
import numpy as np

SR = 22050

# progresi akor per mood (frekuensi Hz, akor dasar oktaf rendah)
NOTE = dict(A1=55.0, C2=65.4, D2=73.4, E2=82.4, F2=87.3, G2=98.0, A2=110.0,
            B2=123.5, Eb3=155.6, C3=130.8, D3=146.8, E3=164.8, F3=174.6, G3=196.0,
            A3=220.0, Bb3=233.1, B3=246.9, C4=261.6, D4=293.7, E4=329.6,
            F4=349.2, G4=392.0, A4=440.0, B4=493.9, C5=523.3, E5=659.3)
CHORDS = {
    'neutral': [[NOTE['A2'], NOTE['E3'], NOTE['C4'], NOTE['G4']],      # Am7
                [NOTE['F2'], NOTE['C3'], NOTE['A3'], NOTE['E4']],      # Fmaj7
                [NOTE['C3'], NOTE['G3'], NOTE['E4'], NOTE['B4']],      # Cmaj7
                [NOTE['G2'], NOTE['D3'], NOTE['B3'], NOTE['F4']]],     # G7-ish
    'tense':   [[NOTE['A2'], NOTE['Eb3'], NOTE['A3'], NOTE['D4']],     # tritone mm
                [NOTE['D2'], NOTE['A2'], NOTE['F3'], NOTE['Bb3']]],
    'warm':    [[NOTE['C3'], NOTE['G3'], NOTE['E4']],                  # C
                [NOTE['F2'], NOTE['C3'], NOTE['A3']],                  # F
                [NOTE['A2'], NOTE['E3'], NOTE['C4']],                  # Am
                [NOTE['G2'], NOTE['D3'], NOTE['B3']]],                 # G
    'uplift':  [[NOTE['C3'], NOTE['G3'], NOTE['E4'], NOTE['C5']],
                [NOTE['G2'], NOTE['D3'], NOTE['B3'], NOTE['G4']],
                [NOTE['A2'], NOTE['E3'], NOTE['C4'], NOTE['E5']],
                [NOTE['F2'], NOTE['C3'], NOTE['A3'], NOTE['F4']]],
}
CHORD_SEC = 7.0
XFADE = 1.4

def _pad(freqs, n, rng, bright=1.0):
    t = np.arange(n) / SR
    out = np.zeros(n, np.float32)
    for k, f in enumerate(freqs):
        vib = 1.0 + 0.0016 * np.sin(2*np.pi*(0.13 + 0.03*k)*t + rng.uniform(0, 6))
        w = np.sin(2*np.pi*f*t*vib)
        w += 0.34*bright*np.sin(2*np.pi*f*2*t*vib)
        w += 0.16*np.sin(2*np.pi*f*0.5*t)
        out += w * (1.0 if k < 2 else 0.72*bright)
    out /= (len(freqs)*1.6)
    # napas lambat biar hidup
    out *= (0.82 + 0.18*np.sin(2*np.pi*t/9.0 + rng.uniform(0, 6))).astype(np.float32)
    return out.astype(np.float32)

def _fade_edges(x, fin=1.2, fout=1.2):
    n = len(x); na, nb = int(fin*SR), int(fout*SR)
    if na > 0 and n > na: x[:na] *= np.linspace(0, 1, na, dtype=np.float32)
    if nb > 0 and n > nb: x[-nb:] *= np.linspace(1, 0, nb, dtype=np.float32)
    return x

def _pluck(f, dur=1.6, vol=0.5):
    n = int(dur*SR)
    t = np.arange(n)/SR
    w = (np.sin(2*np.pi*f*t) + 0.4*np.sin(2*np.pi*f*2*t)) * np.exp(-3.4*t)
    return (w*vol).astype(np.float32)

def mood_music(mood, dur, seed=3):
    """musik 1 mood sepanjang dur detik"""
    rng = np.random.default_rng(seed)
    chords = CHORDS.get(mood, CHORDS['neutral'])
    n = int(dur*SR)
    out = np.zeros(n, np.float32)
    pos = 0.0
    ci = 0
    while pos < dur - 0.4:
        w = min(CHORD_SEC, dur - pos)
        nw = int(w*SR)
        if nw < int(1.0*SR):
            break
        chunk = _pad(chords[ci % len(chords)], nw, rng,
                     bright=1.0 if mood in ('uplift', 'warm') else 0.8)
        # pluck lembut utk uplift
        if mood == 'uplift':
            for pt in np.arange(1.0, w-1.8, 2.0):
                f = chords[ci % len(chords)][2 + (int(pt) % 2)] * 2
                pl = _pluck(f)
                i = int(pt*SR)
                j = min(nw, i+len(pl))
                chunk[i:j] += pl[:j-i]*0.12
        chunk = _fade_edges(chunk, XFADE, XFADE)
        i0 = int(pos*SR)
        j0 = min(n, i0+nw)
        out[i0:j0] += chunk[:j0-i0]
        pos += w - XFADE*0.5
        ci += 1
    if mood == 'tense':                       # tensi: napas LEMBUT tanpa klik (v4.6)
        t = np.arange(n)/SR
        out *= (0.90 + 0.10*np.sin(2*np.pi*t/6.0)).astype(np.float32)
    return out

def build_episode(durs, moods, out_path):
    """gabung musik per klip (mood berganti mengikuti adegan) -> wav mono"""
    parts = []
    for k, (d, mo) in enumerate(zip(durs, moods)):
        parts.append(mood_music(mo or 'neutral', max(1.2, float(d)), seed=3+k*7))
    if not parts:
        return None
    total = np.concatenate(parts)
    total = _fade_edges(total, 0.8, 1.6)
    peak = float(np.abs(total).max()) or 1.0
    total *= 0.085/peak
    import wave as _wave
    pcm = (np.clip(total, -1, 1)*32000).astype('<i2').tobytes()
    with _wave.open(out_path, 'wb') as f:
        f.setnchannels(1); f.setsampwidth(2); f.setframerate(SR)
        f.writeframes(pcm)
    return out_path

MOOD_BY_MOTIF = dict(money='tense', danger='tense', urgency='tense', virus='tense',
                     smstext='tense', tollroad='tense', voiceclone='tense', stats='tense',
                     callerid='tense', courierdoor='tense', goldcourier='tense',
                     arrest='tense', steps='neutral', comments='warm',
                     doorvisit='tense', police='tense', fbi='tense', irs='tense',
                     court='tense', giftcards='tense', wire='tense', identity='tense',
                     callcenter='tense', scam='tense', hospital='warm', sad='warm',
                     family='warm', protect='warm', recovery='uplift', prize='uplift',
                     lottery='uplift')

if __name__ == '__main__':
    import os, tempfile
    d = mood_music('neutral', 12.0)
    print('neutral 12s peak', round(float(np.abs(d).max()), 3))
    x = build_episode([6.0, 5.0, 7.0], ['neutral', 'tense', 'uplift'],
                      os.path.join(tempfile.gettempdir(), 'musik_test.wav'))
    print('episode ->', x, os.path.getsize(x) if x else 0, 'bytes')
