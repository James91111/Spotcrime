#!/usr/bin/env python3
# ============================================================
#  CAST — pabrik karakter gambar-tangan (bukan sprite pabrikan)
#  Gaya: kepala penuh ekspresi (rambut, kacamata, topi, emosi)
#        + badan stick murni (tanpa kotak badan — aturan channel)
#  Semua digambar parametrik → ringan di HP, mudah dibuat banyak.
# ============================================================
import math
from PIL import Image, ImageDraw

W, H = 460, 640
GROUND = 604
INK = (30, 34, 58)

SKIN = dict(light=(241, 215, 190), tan=(219, 175, 142), brown=(152, 108, 76))
HAIR = dict(gray=(163, 167, 178), white=(224, 226, 230), brown=(94, 66, 52),
            dark=(54, 50, 58), red=(150, 88, 58))
C = dict(mauve=(150, 112, 142), slate=(110, 126, 154), navy=(30, 46, 92),
         hoodie=(64, 68, 84), darkred=(138, 70, 64), teal=(88, 134, 126),
         olive=(122, 128, 84), vest=(96, 112, 92), gold=(240, 190, 70),
         maroon=(120, 52, 60))

# ---------------- preset karakter (banyak, untuk 55+ AS) ---------
PRESET = {
    'grandma':  dict(skin='light', hair='bun',    hcol='white', glasses=True,
                     accent=C['mauve'], cane=True, emo='neutral'),
    'grandpa':  dict(skin='light', hair='sides',  hcol='white', mustache=True,
                     accent=C['slate'], emo='neutral'),
    'scammer':  dict(skin='tan',   hair='hood',   hcol='hoodie', headset=True,
                     shades=True, emo='sly'),
    'scammer2': dict(skin='light', hair='beanie', hcol='darkred', headset=True,
                     shades=True, emo='sly'),
    'cop':      dict(skin='tan',   hair='short',  hcol='dark', hat='police',
                     accent=C['navy'], belt=True, emo='stern'),
    'agent':    dict(skin='light', hair='short',  hcol='dark', suit=True,
                     emo='stern'),
    'banker':   dict(skin='brown', hair='short',  hcol='dark', vest=True,
                     emo='neutral'),
    'daughter': dict(skin='light', hair='long',   hcol='brown', accent=C['teal'],
                     emo='happy'),
    'son':      dict(skin='tan',   hair='short',  hcol='dark', accent=C['olive'],
                     emo='neutral'),
    'neighbor': dict(skin='light', hair='curls',  hcol='gray', glasses=True,
                     accent=C['maroon'], emo='neutral'),
    # ---- perluasan cast: beragam (audiens 55+ AS) ----------------
    'grandma2': dict(skin='brown', hair='curls',  hcol='gray', glasses=True,
                     accent=C['gold'], cane=True, emo='neutral'),
    'grandma3': dict(skin='tan',   hair='bun',    hcol='dark', glasses=False,
                     accent=C['teal'], emo='neutral'),
    'grandpa2': dict(skin='brown', hair='sides',  hcol='dark', mustache=True,
                     accent=C['olive'], emo='neutral'),
    'sheriff':  dict(skin='light', hair='short',  hcol='brown', hat='police',
                     accent=C['olive'], belt=True, emo='stern'),
    'irs':      dict(skin='light', hair='bun',    hcol='gray', glasses=True,
                     suit=True, emo='stern'),
    'tech':     dict(skin='tan',   hair='beanie', hcol=(40, 44, 64), shades=True,
                     headset=True, emo='sly'),
    # ---- v4.0: profesi (RS, pengadilan, bandara) ----------------
    'doctor':   dict(skin='light', hair='short',  hcol='gray', coat=True, steth=True,
                     glasses=True, emo='neutral'),
    'nurse':    dict(skin='brown', hair='bun',    hcol='dark', coat=True, steth=True,
                     accent=C['teal'], emo='happy'),
    'judge':    dict(skin='light', hair='sides',  hcol='gray', robe=True, glasses=True,
                     emo='stern'),
    'officer':  dict(skin='tan',   hair='short',  hcol='dark', hat='police', uniform=True,
                     accent=(40, 58, 104), belt=True, emo='stern'),
    # ---- v4.4: tambahan tokoh (variasi penipu & profesi) --------
    'bankmanager': dict(skin='light', hair='sides', hcol='dark', suit=True,
                        glasses=True, emo='neutral'),
    'techgirl':    dict(skin='brown', hair='long',  hcol='dark', headset=True,
                        shades=True, emo='sly'),
    'courier':     dict(skin='tan',   hair='short', hcol='dark', hat='police',
                        accent=C['olive'], belt=True, emo='neutral'),
}

# ---------------- primitif --------------------------------------
def _limb(d, p1, p2, w, col=INK):
    d.line([p1, p2], fill=col, width=w)
    r = w / 2
    for p in (p1, p2):
        d.ellipse([p[0]-r, p[1]-r, p[0]+r, p[1]+r], fill=col)

def _bend(p1, p2, off):
    mx, my = (p1[0]+p2[0])/2, (p1[1]+p2[1])/2
    dx, dy = p2[0]-p1[0], p2[1]-p1[1]
    L = math.hypot(dx, dy) or 1
    return (mx - dy/L*off, my + dx/L*off)

def _arm(d, s, hand, off, w=11):
    e = _bend(s, hand, off)
    _limb(d, s, e, w)
    _limb(d, e, hand, w)
    d.ellipse([hand[0]-9, hand[1]-9, hand[0]+9, hand[1]+9], fill=INK)

def _leg(d, hip, foot, off, w=13):
    k = _bend(hip, foot, off)
    _limb(d, hip, k, w)
    _limb(d, k, foot, w)
    d.line([foot[0]-16, foot[1]+6, foot[0]+18, foot[1]+6], fill=INK, width=9)

# ---------------- kepala ----------------------------------------
def _face(d, cx, cy, r, emo, look=0):
    ex = cx + look*9
    ey = cy - 4
    d.ellipse([ex-8, ey-8, ex+8, ey+8], fill=INK)                    # mata kiri
    d.ellipse([ex+26, ey-8, ex+42, ey+8], fill=INK)                  # mata kanan
    bw = 3
    if emo == 'shock':
        for x0 in (ex, ex+34):
            d.ellipse([x0-11, ey-11, x0+11, ey+11], outline=INK, width=3)
        d.ellipse([ex+12, cy+14, ex+30, cy+36], fill=INK)            # mulut O
        for x0 in (ex, ex+34):  # alis tinggi
            d.line([x0-9, ey-22, x0+9, ey-24], fill=INK, width=bw)
    elif emo == 'happy':
        d.arc([ex-10, ey-8, ex+10, ey+8], 20, 160, fill=INK, width=bw)
        d.arc([ex+24, ey-8, ex+44, ey+8], 20, 160, fill=INK, width=bw)
        d.arc([ex+2, cy+8, ex+34, cy+30], 10, 170, fill=INK, width=4)
        for x0 in (ex, ex+34):
            d.line([x0-8, ey-20, x0+8, ey-22], fill=INK, width=bw)
    elif emo == 'worried':
        d.line([ex-9, ey-18, ex+9, ey-24], fill=INK, width=bw)       # alis naik dalam
        d.line([ex+25, ey-24, ex+43, ey-18], fill=INK, width=bw)
        d.arc([ex+4, cy+16, ex+32, cy+34], 190, 350, fill=INK, width=4)
    elif emo == 'stern':
        d.line([ex-9, ey-24, ex+9, ey-18], fill=INK, width=bw)       # alis turun
        d.line([ex+25, ey-18, ex+43, ey-24], fill=INK, width=bw)
        d.line([ex+6, cy+24, ex+30, cy+24], fill=INK, width=4)
    elif emo == 'sad':
        d.line([ex-9, ey-16, ex+9, ey-25], fill=INK, width=bw)      # alis miring
        d.line([ex+25, ey-25, ex+43, ey-16], fill=INK, width=bw)
        d.arc([ex+4, cy+14, ex+32, cy+32], 195, 345, fill=INK, width=4)  # mulut sedih
        d.line([ex-6, ey+14, ex-6, ey+34], fill=(90, 140, 220), width=4) # air mata
        d.line([ex+40, ey+14, ex+40, ey+38], fill=(90, 140, 220), width=4)
    elif emo == 'sly':
        d.line([ex-9, ey-20, ex+9, ey-16], fill=INK, width=bw)
        d.line([ex+25, ey-26, ex+43, ey-20], fill=INK, width=bw)
        d.arc([ex+6, cy+10, ex+36, cy+30], 200, 320, fill=INK, width=4)
    else:  # neutral
        for x0 in (ex, ex+34):
            d.line([x0-8, ey-21, x0+8, ey-21], fill=INK, width=bw)
        d.line([ex+8, cy+24, ex+28, cy+24], fill=INK, width=4)
    if True:  # hidung kecil
        d.line([ex+16, ey+2, ex+19, ey+12], fill=INK, width=3)

def _glasses(d, cx, cy, r):
    ex, ey = cx+9, cy-4
    for x0 in (ex+8, ex+34):
        d.ellipse([x0-16, ey-16, x0+16, ey+16], outline=INK, width=4)
    d.arc([ex+8, ey-10, ex+34, ey+10], 250, 290, fill=INK, width=4)
    d.line([ex-8, ey, cx+r-2, ey-2], fill=INK, width=4)

def _head(d, cx, cy, r, p, emo, look):
    skin = SKIN[p['skin']]
    hair = HAIR[p['hcol']] if p.get('hcol') in HAIR else C.get(p.get('hcol'), INK)
    # rambut belakang (long) dulu
    if p['hair'] == 'long':
        d.pieslice([cx-r-14, cy-r-8, cx+r+14, cy+r+40], 140, 400, fill=hair)
    d.ellipse([cx-r, cy-r, cx+r, cy+r], fill=skin, outline=INK, width=5)
    hc = hair
    if p['hair'] == 'bun':
        d.pieslice([cx-r, cy-r, cx+r, cy+r], 180, 360, fill=hc)
        d.ellipse([cx-26, cy-r-30, cx+26, cy-r+22], fill=hc, outline=INK, width=4)
        d.ellipse([cx-r+2, cy-8, cx+r-2, cy+r], fill=skin)           # buka wajah
        d.arc([cx-r, cy-r, cx+r, cy+r], 200, 340, fill=INK, width=5)
    elif p['hair'] == 'sides':
        d.pieslice([cx-r-4, cy-r-4, cx+r+4, cy+r+4], 150, 210, fill=hc)
        d.pieslice([cx-r-6, cy-24, cx-r+26, cy+30], 60, 300, fill=hc)
        d.pieslice([cx+r-26, cy-24, cx+r+6, cy+30], 240, 120, fill=hc)
        d.ellipse([cx-r+4, cy-r+6, cx+r-4, cy+r-2], fill=skin)
        d.arc([cx-r, cy-r, cx+r, cy+r], 200, 340, fill=INK, width=5)
    elif p['hair'] == 'short':
        d.pieslice([cx-r, cy-r-2, cx+r, cy+r], 180, 360, fill=hc)
        d.ellipse([cx-r+4, cy-10, cx+r-4, cy+r], fill=skin)
        d.arc([cx-r, cy-r, cx+r, cy+r], 190, 350, fill=INK, width=5)
    elif p['hair'] == 'curls':
        for i, dx in enumerate((-40, 0, 40)):
            d.ellipse([cx+dx-26, cy-r-16, cx+dx+26, cy-r+30], fill=hc, outline=INK, width=3)
        d.ellipse([cx-r+4, cy-r+10, cx+r-4, cy+r-2], fill=skin)
        d.arc([cx-r, cy-r, cx+r, cy+r], 200, 340, fill=INK, width=5)
    elif p['hair'] == 'beanie':
        d.pieslice([cx-r-6, cy-r-10, cx+r+6, cy+r], 175, 368, fill=hc)
        d.rounded_rectangle([cx-r-8, cy-r+14, cx+r+8, cy-r+38], 8, fill=C['darkred'])
        d.ellipse([cx-r+6, cy-r+34, cx+r-6, cy+r], fill=skin)
        d.arc([cx-r, cy-r, cx+r, cy+r], 200, 340, fill=INK, width=5)
    elif p['hair'] == 'hood':
        # hood = bentuk besar di belakang kepala, wajah tetap terbuka
        d.pieslice([cx-r-24, cy-r-16, cx+r+24, cy+r+34], 95, 265, fill=C['hoodie'],
                   outline=INK, width=4)
        d.ellipse([cx-r+6, cy-r+8, cx+r-6, cy+r], fill=skin)
        d.arc([cx-r, cy-r, cx+r, cy+r], 200, 340, fill=INK, width=5)
    elif p['hair'] == 'long':
        d.pieslice([cx-r, cy-r-2, cx+r, cy+r], 180, 360, fill=hc)
        d.ellipse([cx-r+6, cy-14, cx+r-6, cy+r], fill=skin)
        d.arc([cx-r, cy-r, cx+r, cy+r], 200, 340, fill=INK, width=5)
    _face(d, cx, cy, r, emo, look)
    if p.get('mustache'):
        d.arc([cx-6, cy+22, cx+40, cy+40], 200, 340, fill=HC_MUST, width=7)
    if p.get('glasses'):
        _glasses(d, cx, cy, r)
    if p.get('shades'):                      # kacamata hitam: tanda 'penjahat'
        d.rounded_rectangle([cx-26, cy-20, cx+50, cy+6], 10, fill=(20, 22, 30))
        d.line([cx-26, cy-12, cx-40, cy-16], fill=(20, 22, 30), width=5)
        d.line([cx+50, cy-12, cx+58, cy-18], fill=(20, 22, 30), width=5)
        d.line([cx+12, cy-16, cx+16, cy-16], fill=(70, 74, 88), width=4)
    if p.get('headset'):
        d.arc([cx-r+2, cy-r-6, cx+r-2, cy+r+6], 205, 335, fill=INK, width=8)
        d.ellipse([cx-r-10, cy-16, cx-r+12, cy+12], fill=INK)         # earcup
        d.arc([cx-r-2, cy+2, cx-r+34, cy+46], 40, 150, fill=INK, width=5)  # mic melengkung ke dagu
        d.ellipse([cx-r+20, cy+36, cx-r+34, cy+50], fill=INK)
    if p.get('hat') == 'police':
        d.rounded_rectangle([cx-r+6, cy-r-26, cx+r-6, cy-r+18], 10, fill=C['navy'])
        d.ellipse([cx-r+6, cy-r+2, cx+r-6, cy-r+30], fill=C['navy'])
        d.rounded_rectangle([cx-r-10, cy-r+18, cx+r+10, cy-r+34], 6, fill=(22, 34, 66))
        d.ellipse([cx-12, cy-r-14, cx+12, cy-r+8], fill=C['gold'])    # lencana topi
        d.ellipse([cx-5, cy-r-7, cx+5, cy-r+3], fill=(255, 255, 255))
    if p['hair'] == 'hood':
        # tali hood di dagu (bukan cincin menutupi wajah)
        d.line([cx-16, cy+r-6, cx-10, cy+r+16], fill=C['hoodie'], width=6)
        d.line([cx+16, cy+r-6, cx+10, cy+r+16], fill=C['hoodie'], width=6)

HC_MUST = (200, 202, 208)

# ---------------- frame utama -----------------------------------
_cache = {}
def frame(who='grandma', pose='stand', emo=None, step=0, flip=False, look=1):
    key = (who, pose, emo, step % 2, flip, look)
    if key in _cache: return _cache[key]
    p = PRESET.get(who, PRESET['grandma'])
    emo = emo or p.get('emo', 'neutral')
    img = Image.new('RGBA', (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    cx = 230
    r = 74
    hcy = 190
    sh = (cx, 292)
    hip = (cx, 452)

    # ---- kaki
    if pose == 'walk':
        # LANGKAH NYATA: satu kaki maju TERANGKAT, satu mendorong ke belakang
        if step % 2 == 0:
            _leg(d, hip, (cx+118, GROUND-30), 36)   # kaki depan terangkat
            _leg(d, hip, (cx-98, GROUND-6), -28)    # kaki belakang mendorong
        else:
            _leg(d, hip, (cx-118, GROUND-30), -36)
            _leg(d, hip, (cx+98, GROUND-6), 28)
    elif pose == 'run':                       # v4.4: langkah lari lebar
        if step % 2 == 0:
            _leg(d, hip, (cx+152, GROUND-36), 44)
            _leg(d, hip, (cx-128, GROUND-6), -36)
        else:
            _leg(d, hip, (cx-152, GROUND-36), -44)
            _leg(d, hip, (cx+128, GROUND-6), 36)
    else:
        _leg(d, hip, (cx-30, GROUND-4), 10)
        _leg(d, hip, (cx+32, GROUND-4), -10)

    # ---- badan (stick murni: satu garis, TANPA kotak)
    _limb(d, (cx, 268), hip, 12)
    if p.get('belt'):
        d.line([cx-20, 442, cx+20, 442], fill=(20, 26, 46), width=10)
        d.ellipse([cx-5, 436, cx+5, 448], fill=C['gold'])
    # torso stick MURNI: tanpa garis dada/apapun yang menyilang badan
    _limb(d, (cx, 268), (cx, 246), 9)                                  # leher

    # ---- seragam profesi (v4.0)
    if p.get('coat'):          # jas putih dokter/perawat
        d.rounded_rectangle([cx-34, 282, cx-6, 442], 8, fill=(250, 252, 252), outline=INK, width=5)
        d.rounded_rectangle([cx+6, 282, cx+34, 442], 8, fill=(250, 252, 252), outline=INK, width=5)
        d.line([cx-20, 292, cx-14, 316], fill=INK, width=4)
        d.line([cx+20, 292, cx+14, 316], fill=INK, width=4)
        if p.get('steth'):
            d.arc([cx-24, 262, cx+34, 336], 20, 165, fill=(70, 78, 100), width=7)
            d.ellipse([cx+20, 322, cx+40, 342], fill=(150, 156, 172), outline=INK, width=4)
    if p.get('robe'):          # jubah hakim + kerah putih
        d.polygon([(cx-42, 268), (cx+42, 268), (cx+60, 470), (cx-60, 470)],
                  fill=(36, 40, 58), outline=INK, width=5)
        d.polygon([(cx-16, 258), (cx+16, 258), (cx, 280)], fill=(248, 250, 252))
    if p.get('uniform'):       # epaulet + lencana dada petugas bandara
        d.rectangle([cx-48, 280, cx-16, 294], fill=C['gold'])
        d.rectangle([cx+16, 280, cx+48, 294], fill=C['gold'])
        d.ellipse([cx+16, 304, cx+38, 326], fill=C['gold'], outline=INK, width=4)

    # ---- tangan sesuai pose
    dn = (cx-38, sh[1]+150)
    dn2 = (cx+38, sh[1]+150)
    if pose == 'talk':
        _arm(d, sh, (cx+100, sh[1]+58), -30)
        _arm(d, sh, dn, -8)
    elif pose == 'phone':
        _arm(d, sh, (cx+74, hcy+26), -46)
        _arm(d, sh, dn, -8)
        d.rounded_rectangle([cx+52, hcy-22, cx+100, hcy+56], 10,   # HP jelas besar
                            fill=(40, 44, 64), outline=(255, 255, 255), width=3)
        d.rounded_rectangle([cx+60, hcy-12, cx+92, hcy+22], 4, fill=(150, 200, 170))
        for i in range(3):                                             # gelombang dering
            rr = 20 + i*17
            d.arc([cx+104-rr, hcy+2-rr, cx+104+rr, hcy+2+rr], -55, 55,
                  fill=INK if i else (150, 156, 172), width=5)
    elif pose == 'phonecheck':
        _arm(d, sh, (cx+86, sh[1]+64), -40)                        # HP di depan dada
        _arm(d, sh, dn, -8)
        d.rounded_rectangle([cx+66, sh[1]+28, cx+114, sh[1]+104], 10,
                            fill=(40, 44, 64), outline=(255, 255, 255), width=3)
        d.rounded_rectangle([cx+74, sh[1]+38, cx+106, sh[1]+72], 4, fill=(150, 200, 170))
        for i in range(2):                                             # getar kecil
            rr = 14 + i*11
            d.arc([cx+120-rr, sh[1]+62-rr, cx+120+rr, sh[1]+62+rr], -55, 55,
                  fill=INK, width=4)
    elif pose == 'point':
        _arm(d, sh, (cx+186, sh[1]+6), 10)
        _arm(d, sh, (cx-40, sh[1]+148), -10)
    elif pose == 'shock':
        _arm(d, sh, (cx-108, sh[1]-92), 26)
        _arm(d, sh, (cx+108, sh[1]-92), -26)
    elif pose == 'happy':
        _arm(d, sh, (cx-146, sh[1]-30), 22)
        _arm(d, sh, (cx+146, sh[1]-30), -22)
    elif pose == 'walk':
        if step % 2 == 0:
            _arm(d, sh, (cx-90, sh[1]+92), 24)
            _arm(d, sh, (cx+92, sh[1]+70), -24)
        else:
            _arm(d, sh, (cx+90, sh[1]+92), -24)
            _arm(d, sh, (cx-92, sh[1]+70), 24)
    elif pose == 'gesture':                   # v4.4: dua tangan bergerak luas
        _arm(d, sh, (cx+152, sh[1]-38), -38)
        _arm(d, sh, (cx-142, sh[1]+46), 26)
    elif pose == 'think':                     # v4.4: mikir, tangan di dagu
        _arm(d, sh, (cx+44, hcy+34), -64)
        _arm(d, sh, dn, -6)
    elif pose == 'run':                       # v4.4: tangan lari mengepal
        _arm(d, sh, (cx+118, sh[1]+30), -46)
        _arm(d, sh, (cx-112, sh[1]+88), 40)
    else:  # stand
        _arm(d, sh, dn, -10)
        _arm(d, sh, dn2, 10)

    # ---- kepala
    _head(d, cx, hcy, r, p, emo, look)

    # ---- tongkat (idolanya oma)
    if p.get('cane') and pose in ('stand', 'talk'):
        gx = cx + 62
        d.arc([gx-14, 336, gx+14, 364], 180, 340, fill=(96, 70, 50), width=9)
        d.line([gx, 350, gx+6, GROUND], fill=(96, 70, 50), width=9)

    if flip:
        img = img.transpose(Image.FLIP_LEFT_RIGHT)
    _cache[key] = img
    return img

# ---------------- properti gambar-tangan ------------------------
def prop(name):
    """properti yang digambar sendiri (bukan sprite): phone/giftcards/monitor/shield/sign/counter"""
    key = ('prop', name)
    if key in _cache: return _cache[key]
    img = Image.new('RGBA', (360, 300), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    if name == 'phone':
        d.rounded_rectangle([120, 30, 240, 270], 26, fill=(255, 255, 255),
                            outline=INK, width=7)
        d.rounded_rectangle([138, 66, 222, 216], 8, fill=(228, 232, 240))
        d.ellipse([164, 230, 196, 258], outline=INK, width=6)
        for i in range(3):
            rr = 26 + i*22
            d.arc([240-rr+40, 150-rr, 240+rr+40, 150+rr], -55, 55, fill=INK, width=7)
    elif name == 'giftcards':
        for i, col in enumerate((C['teal'], C['mauve'], C['gold'], (198, 96, 84))):
            y = 150 - i*44
            d.rounded_rectangle([40+i*8, y, 300+i*8, y+92], 12, fill=col,
                                outline=INK, width=5)
            d.line([40+i*8+26, y+46, 300+i*8-26, y+46], fill=(255, 255, 255), width=6)
    elif name == 'monitor':
        d.rounded_rectangle([30, 20, 330, 230], 14, fill=(255, 255, 255),
                            outline=INK, width=7)
        d.rounded_rectangle([48, 38, 312, 196], 8, fill=(30, 34, 58))
        d.line([150, 230, 150, 262], fill=INK, width=8)
        d.line([100, 264, 200, 264], fill=INK, width=8)
        d.rounded_rectangle([180, 60, 300, 130], 10, fill=(226, 54, 54))
        d.text((206, 78), "!", fill=(255, 255, 255))
        d.line([64, 64, 150, 64], fill=(120, 128, 146), width=7)
        d.line([64, 92, 150, 92], fill=(120, 128, 146), width=7)
        d.line([64, 120, 128, 120], fill=(120, 128, 146), width=7)
        d.line([64, 160, 300, 160], fill=(90, 160, 110), width=7)
    elif name == 'shield':
        d.polygon([(180, 16), (316, 62), (316, 150), (180, 282), (44, 150),
                   (44, 62)], fill=(232, 238, 248), outline=INK)
        d.line([(180, 16), (316, 62)], fill=INK, width=7)
        d.line([(44, 62), (180, 16)], fill=INK, width=7)
        d.line([(44, 62), (44, 150)], fill=INK, width=7)
        d.line([(316, 62), (316, 150)], fill=INK, width=7)
        d.line([(316, 150), (180, 282)], fill=INK, width=7)
        d.line([(180, 282), (44, 150)], fill=INK, width=7)
        d.line([(110, 140), (166, 196), (256, 92)], fill=(46, 140, 90), width=18)
        joint = [(110, 140), (166, 196), (256, 92)]
        for p_ in joint:
            d.ellipse([p_[0]-9, p_[1]-9, p_[0]+9, p_[1]+9], fill=(46, 140, 90))
    elif name == 'sign':
        d.line([176, 130, 176, 296], fill=INK, width=10)
        d.ellipse([96, 10, 256, 170], fill=(226, 54, 54), outline=INK, width=7)
        d.rounded_rectangle([166, 38, 190, 100], 8, fill=(255, 255, 255))  # batang (!)
        d.ellipse([164, 112, 192, 140], fill=(255, 255, 255))              # titik bawah
    elif name == 'counter':
        d.rounded_rectangle([20, 90, 340, 130], 10, fill=(150, 112, 86), outline=INK, width=6)
        d.rounded_rectangle([44, 130, 316, 250], 10, fill=(176, 140, 110), outline=INK, width=6)
        d.ellipse([150, 46, 210, 96], fill=(210, 214, 226), outline=INK, width=5)
    elif name == 'laptop':                     # laptop terbuka
        d.polygon([(80, 40), (280, 40), (300, 190), (60, 190)], fill=(255, 255, 255),
                  outline=INK)
        d.polygon([(96, 56), (264, 56), (280, 176), (80, 176)], fill=(30, 34, 58))
        d.line([64, 160, 130, 160], fill=(120, 128, 146), width=6)
        d.line([64, 184, 118, 184], fill=(120, 128, 146), width=6)
        d.rounded_rectangle([150, 92, 262, 150], 8, fill=(226, 54, 54))
        d.line([176, 121, 236, 121], fill=(255, 255, 255), width=7)
        d.rounded_rectangle([30, 190, 330, 226], 12, fill=(214, 218, 230), outline=INK, width=6)
    elif name == 'car':                        # mobil tampak samping
        d.rounded_rectangle([20, 130, 330, 220], 26, fill=(96, 126, 176), outline=INK, width=7)
        d.polygon([(80, 134), (130, 70), (240, 70), (280, 134)], fill=(96, 126, 176),
                  outline=INK)
        d.polygon([(136, 84), (176, 84), (176, 130), (108, 130)], fill=(214, 226, 240))
        d.polygon([(190, 84), (228, 84), (258, 130), (190, 130)], fill=(214, 226, 240))
        for wx in (96, 250):
            d.ellipse([wx-34, 186, wx+34, 254], fill=(40, 44, 58), outline=INK, width=6)
            d.ellipse([wx-14, 206, wx+14, 234], fill=(180, 186, 200))
        d.line([20, 156, 8, 156], fill=INK, width=6)
        d.line([330, 156, 344, 156], fill=INK, width=6)
    elif name == 'house':                      # rumah
        d.polygon([(40, 150), (180, 40), (320, 150)], fill=(150, 112, 142), outline=INK)
        d.line([(40, 150), (180, 40)], fill=INK, width=6)
        d.line([(180, 40), (320, 150)], fill=INK, width=6)
        d.rectangle([64, 150, 296, 270], fill=(240, 234, 220), outline=INK, width=6)
        d.rectangle([140, 190, 220, 270], fill=(120, 90, 70), outline=INK, width=5)
        d.ellipse([200, 222, 212, 234], fill=C['gold'])
        d.rectangle([84, 172, 128, 210], fill=(214, 226, 240), outline=INK, width=5)
        d.rectangle([232, 172, 276, 210], fill=(214, 226, 240), outline=INK, width=5)
    elif name == 'mail':                       # amplop
        d.rounded_rectangle([30, 70, 330, 240], 12, fill=(250, 246, 236), outline=INK, width=7)
        d.line([(34, 78), (180, 176)], fill=INK, width=6)
        d.line([(326, 78), (180, 176)], fill=INK, width=6)
        d.line([(34, 232), (130, 150)], fill=INK, width=6)
        d.line([(326, 232), (230, 150)], fill=INK, width=6)
        d.ellipse([252, 84, 316, 148], fill=(226, 54, 54), outline=INK, width=5)
    elif name == 'wallet':                     # dompet + kartu menyembul
        d.rounded_rectangle([90, 60, 250, 120], 8, fill=(88, 134, 126), outline=INK, width=5)
        d.rounded_rectangle([40, 96, 320, 250], 16, fill=(120, 90, 70), outline=INK, width=7)
        d.rounded_rectangle([220, 150, 320, 208], 12, fill=(176, 140, 110), outline=INK, width=5)
        d.ellipse([262, 168, 282, 188], fill=C['gold'], outline=INK, width=4)
    elif name == 'atm':                        # mesin ATM
        d.rounded_rectangle([70, 20, 290, 280], 14, fill=(214, 222, 238), outline=INK, width=7)
        d.rounded_rectangle([96, 46, 264, 140], 8, fill=(30, 34, 58))
        d.line([112, 74, 200, 74], fill=(120, 200, 140), width=6)
        d.line([112, 100, 176, 100], fill=(120, 128, 146), width=6)
        d.rounded_rectangle([96, 168, 190, 196], 6, fill=(120, 90, 70), outline=INK, width=5)
        d.rounded_rectangle([96, 214, 190, 240], 6, fill=(150, 156, 172), outline=INK, width=5)
        for by in (176, 202, 228):
            d.ellipse([228, by-12, 256, by+12], fill=(226, 54, 54), outline=INK, width=4)
    elif name == 'card':                       # kartu bank/credit
        d.rounded_rectangle([60, 80, 320, 240], 16, fill=(70, 84, 130), outline=INK, width=7)
        d.rounded_rectangle([60, 118, 320, 150], 0, fill=(40, 48, 78))
        d.line([84, 180, 180, 180], fill=(220, 224, 236), width=8)
        d.line([84, 206, 140, 206], fill=(220, 224, 236), width=8)
        d.ellipse([262, 182, 298, 218], fill=C['gold'], outline=INK, width=4)
    elif name == 'report':                     # dokumen laporan + stempel
        d.rounded_rectangle([70, 30, 280, 270], 8, fill=(252, 250, 244), outline=INK, width=7)
        for y in (78, 112, 146, 180):
            d.line([100, y, 250 if y != 146 else 200, y], fill=(150, 156, 172), width=7)
        d.ellipse([176, 168, 268, 252], outline=(46, 140, 90), width=8)
        d.line([196, 210, 248, 210], fill=(46, 140, 90), width=7)
        d.line([222, 186, 222, 234], fill=(46, 140, 90), width=7)
    elif name == 'clock':                      # jam (slow down)
        d.ellipse([60, 30, 300, 270], fill=(255, 255, 255), outline=INK, width=8)
        d.ellipse([84, 54, 276, 246], outline=(180, 186, 200), width=5)
        d.line([(180, 150), (180, 84)], fill=INK, width=10)
        d.line([(180, 150), (232, 176)], fill=INK, width=10)
        d.ellipse([172, 142, 188, 158], fill=(226, 54, 54))
        for ang in (45, 135, 225, 315):
            import math as _m
            x1 = 180 + 96 * _m.cos(_m.radians(ang)); y1 = 150 + 96 * _m.sin(_m.radians(ang))
            x2 = 180 + 108 * _m.cos(_m.radians(ang)); y2 = 150 + 108 * _m.sin(_m.radians(ang))
            d.line([x1, y1, x2, y2], fill=(150, 156, 172), width=6)
    elif name == 'blockphone':                 # telepon dicoret (blokir)
        d.rounded_rectangle([130, 40, 230, 250], 22, fill=(255, 255, 255), outline=INK, width=7)
        d.rounded_rectangle([146, 74, 214, 198], 6, fill=(228, 232, 240))
        d.line([(240, 70), (110, 230)], fill=(226, 54, 54), width=16)
        d.line([(240, 70), (110, 230)], fill=(226, 54, 54), width=16)
    elif name == 'checklist':                  # papan langkah aman
        d.rounded_rectangle([50, 30, 290, 270], 12, fill=(255, 255, 255), outline=INK, width=7)
        for i, y in enumerate((80, 140, 200)):
            d.rounded_rectangle([76, y-16, 112, y+16], 6, outline=(46, 140, 90), width=6)
            d.line([84, y, 92, y+9], fill=(46, 140, 90), width=6)
            d.line([92, y+9, 104, y-11], fill=(46, 140, 90), width=6)
            d.line([132, y, 250, y], fill=(150, 156, 172), width=8)
    elif name == 'btc':                        # koin Bitcoin
        d.ellipse([40, 20, 320, 300], fill=(247, 178, 54), outline=INK, width=8)
        d.ellipse([70, 50, 290, 270], outline=(255, 255, 255), width=6)
        # huruf B bitcoin: batang + dua tonjolan + garis serif
        d.line([(150, 92), (150, 228)], fill=(255, 255, 255), width=13)
        d.arc([138, 100, 224, 168], 270, 90, fill=(255, 255, 255), width=13)
        d.arc([138, 152, 232, 220], 270, 90, fill=(255, 255, 255), width=13)
        d.line([(126, 92), (172, 92)], fill=(255, 255, 255), width=10)
        d.line([(126, 228), (172, 228)], fill=(255, 255, 255), width=10)
        d.line([(162, 78), (162, 96)], fill=(255, 255, 255), width=9)
        d.line([(186, 78), (186, 96)], fill=(255, 255, 255), width=9)
        d.line([(162, 224), (162, 242)], fill=(255, 255, 255), width=9)
        d.line([(186, 224), (186, 242)], fill=(255, 255, 255), width=9)
    _cache[key] = img
    return img

if __name__ == '__main__':
    import os
    rows = []
    names = list(PRESET)
    for who in names:
        im = frame(who, 'talk', look=1)
        rows.append((who, im))
    sheet = Image.new('RGB', (300*5, 360*2), (250, 250, 252))
    from PIL import ImageDraw as ID
    dd = ID.Draw(sheet)
    for i, (who, im) in enumerate(rows):
        im.thumbnail((270, 330))
        x, y = (i % 5)*300+15, (i//5)*360+15
        sheet.paste(im, (x, y), im)
        dd.text((x+8, y+332), who, fill=(30, 34, 58))
    sheet.save('cast_sheet.jpg', quality=90)
    print('OK -> cast_sheet.jpg', len(names), 'karakter')
