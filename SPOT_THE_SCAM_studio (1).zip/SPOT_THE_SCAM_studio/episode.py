#!/usr/bin/env python3
# ============================================================
#  EPISODE.PY — satu perintah, jadi video utuh
#  ============================================================
#  MODE AUTO (dari narasi):
#    python episode.py narasi_ep01.txt --out ep01
#    -> baca tiap paragraf (pisah '---') -> pilih adegan otomatis
#    -> generate VO (edge-tts) -> render klip -> gabung -> ep01/final.mp4
#    -> simpan ep01/scene.txt (hasil auto, BOLEH DIEDIT lalu render ulang)
#
#  MODE MANUAL (dari scene.txt yang sudah diedit):
#    python episode.py ep01/scene.txt --out ep01 --scene
#
#  Opsi: --no-vo (tanpa audio, durasi estimasi)  --fps 12  --target 13
# ============================================================
import os, sys, subprocess, math, argparse
import stickplay as sp
from stickanim import find_ffmpeg, render_frames as _unused  # reuse ffmpeg finder

def vo_duration(ff, path):
    r = subprocess.run([ff, '-i', path], capture_output=True, text=True)
    m = re.search(r'Duration: (\d+):(\d+):(\d+\.\d+)', r.stderr)
    if not m: return 5.0
    h, mi, s = m.groups()
    return int(h)*3600 + int(mi)*60 + float(s)

import re

def est_duration(text):
    words = len(text.split())
    return max(3.0, words / 2.5)          # ~150 kata/menit

def gen_vo(text, idx, voice='en-US-AndrewNeural'):
    out = f'vo_{idx:02d}.mp3'
    r = subprocess.run(['edge-tts', '--voice', voice, '--rate=-8%', '--pitch=-8Hz',
                        '--text', text, '--write-media', out], capture_output=True)
    return out if r.returncode == 0 and os.path.exists(out) else None

def concat(ff, files, out, is_video=True):
    lst = out + '.txt'
    with open(lst, 'w') as f:
        for p in files:
            f.write(f"file '{os.path.abspath(p)}'\n")
    if is_video:
        cmd = [ff, '-y', '-loglevel', 'error', '-f', 'concat', '-safe', '0', '-i', lst,
               '-c', 'copy', out]
    else:
        cmd = [ff, '-y', '-loglevel', 'error', '-f', 'concat', '-safe', '0', '-i', lst,
               '-c:a', 'libmp3lame', '-b:a', '160k', out]
    ok = subprocess.run(cmd, capture_output=True).returncode == 0
    os.remove(lst)
    return ok

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('src')
    ap.add_argument('--out', default='ep')
    ap.add_argument('--scene', action='store_true', help='src adalah scene.txt (manual)')
    ap.add_argument('--no-vo', action='store_true')
    ap.add_argument('--fps', type=int, default=12)
    ap.add_argument('--target', type=float, default=13.0, help='target durasi (menit)')
    ap.add_argument('--max-dur', type=float, default=0, help='batas durasi per beat (untuk tes cepat)')
    args = ap.parse_args()

    os.makedirs(args.out, exist_ok=True)
    ff = find_ffmpeg()
    if not ff:
        print('ffmpeg tidak ditemukan. Install: pkg install ffmpeg'); sys.exit(1)

    # ---------- siapkan beats ----------
    if args.scene:
        beats = sp.parse_scene(args.src)
        texts = [None]*len(beats)
        print(f'=== MANUAL: {len(beats)} beat dari {args.src} ===')
    else:
        blocks, cur = [], []
        for raw in open(args.src, encoding='utf-8'):
            if raw.strip().startswith('#'):
                continue
            if raw.strip() == '---':
                if cur: blocks.append(' '.join(cur)); cur = []
            else:
                cur.append(raw.strip())
        if cur: blocks.append(' '.join(cur))
        print(f'=== AUTO: {len(blocks)} paragraf narasi ===')
        beats, texts = [], []
        for i, text in enumerate(blocks, 1):
            vo = None if args.no_vo else gen_vo(text, i)
            dur = vo_duration(ff, vo) if vo else est_duration(text)
            if args.max_dur: dur = min(dur, args.max_dur)
            print(f'  beat {i}: {dur:.1f}s  "{text[:48]}..."')
            beats.append(sp.auto_beat(text, dur))
            texts.append((text, vo))

    total = sum(b['dur'] for b in beats)
    print(f'>>> Total durasi: {total/60:.1f} menit (target {args.target:.0f}+ menit)')

    # ---------- simpan scene.txt (editable) ----------
    scene_path = os.path.join(args.out, 'scene.txt')
    with open(scene_path, 'w', encoding='utf-8') as f:
        f.write(sp.to_dsl(beats))
    print('>>> scene.txt tersimpan (bisa diedit lalu render ulang mode --scene)')

    # ---------- render tiap beat ----------
    clips = []
    for i, b in enumerate(beats, 1):
        print(f'[{i}/{len(beats)}] render bg={b["bg"]} {b["dur"]:.1f}s ...')
        paths = sp.render_beat(b, args.fps, os.path.join(args.out, f'b{i:02d}_f'))
        clip = os.path.join(args.out, f'b{i:02d}.mp4')
        ok = subprocess.run(
            [ff, '-y', '-loglevel', 'error', '-framerate', str(args.fps),
             '-i', os.path.join(args.out, f'b{i:02d}_f', 'f%03d.png'),
             '-c:v', 'libx264', '-pix_fmt', 'yuv420p', '-crf', '20', clip],
            capture_output=True).returncode == 0
        if not ok:
            print('   GAGAL encode beat', i); sys.exit(1)
        for p in paths: os.remove(p)
        os.rmdir(os.path.join(args.out, f'b{i:02d}_f'))
        clips.append(clip)

    # ---------- gabung video ----------
    final_v = os.path.join(args.out, 'video.mp4')
    if not concat(ff, clips, final_v, is_video=True):
        print('gagal concat video'); sys.exit(1)
    print('>>> video.mp4:', f'{total/60:.1f}', 'menit')

    # ---------- audio + mux ----------
    if not args.scene and not args.no_vo:
        vos = [t[1] for t in texts if t and t[1]]
        if vos:
            audio = os.path.join(args.out, 'audio.mp3')
            concat(ff, vos, audio, is_video=False)
            final = os.path.join(args.out, 'final.mp4')
            subprocess.run([ff, '-y', '-loglevel', 'error', '-i', final_v, '-i', audio,
                            '-c:v', 'copy', '-c:a', 'aac', '-b:a', '160k',
                            '-shortest', final], capture_output=True)
            print(f'\n=== SELESAI: {final} ===')
            return
    print(f'\n=== SELESAI (tanpa audio): {final_v} ===')

if __name__ == '__main__':
    main()
