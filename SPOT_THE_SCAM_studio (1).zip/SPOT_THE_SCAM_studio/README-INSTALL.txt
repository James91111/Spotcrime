SPOT THE SCAM STUDIO — INSTALASI
================================
1) Butuh Python 3 + ffmpeg:
   Termux     : pkg install python ffmpeg -y
   Proot/Debian: apt install python3 python3-pip ffmpeg -y
2) Selesai. Lalu jalankan:
   python studio.py
   (komponen Python dipasang OTOMATIS saat pertama kali — butuh internet sekali)

Kalau auto-install gagal:
   pip install flask pillow edge-tts numpy soundfile imageio-ffmpeg

Setelah jendela studio terbuka, ikuti 3 langkah di layar.
Panduan lengkap: CARA-PAKAI.md
