#!/usr/bin/env python3
# ============================================================
#  SRT2VIDEO — subtitle.srt -> video animasi stickman + narasi
#  ============================================================
#  - Tiap baris subtitle = 1 adegan (latar/karakter dipilih dari isi kalimat)
#  - Durasi tiap adegan = durasi audio narasi baris itu (edge-tts)
#  - Teks kinetik muncul di pita atas layar (tidak menutupi karakter)
#  - Tema PUTIH bersih ala video explainer
#
#  Pakai : python srt2video.py subtitle.srt --out ep01
#  Opsi  : --voice en-US-AndrewNeural   --no-tts (pakai timing srt)
#          --fps 12   --theme white|navy
# ============================================================
import os, sys, re, argparse, subprocess
import stickplay as sp
import kinetic
from stickanim import find_ffmpeg

# ---------- SRT parser ----------
def parse_srt(path):
    lines = open(path, encoding='utf-8-sig').read().replace('\r\n', '\n').split('\n')
    cues, i = [], 0
    tc = re.compile(r'(\d+):(\d+):(\d+)[,.](\d+)\s*-->\s*(\d+):(\d+):(\d+)[,.](\d+)')
    while i < len(lines):
        m = tc.search(lines[i])
        if not m:
            i += 1; continue
        g = [int(x) for x in m.groups()]
        t0 = g[0]*3600 + g[1]*60 + g[2] + g[3]/1000
        t1 = g[4]*3600 + g[5]*60 + g[6] + g[7]/1000
        i += 1
        text = []
        while i < len(lines) and not tc.search(lines[i]):
            s = lines[i].strip()
            if s and not re.match(r'^\d+$', s) and not re.match(r'^-{2,}$', s):
                text.append(re.sub(r'<[^>]+>', '', s))
            i += 1
        if text:
            cues.append((t0, t1, ' '.join(text)))
    return cues

# ---------- VO & durasi ----------
def gen_vo(text, idx, voice):
    out = f'srt_vo_{idx:03d}.mp3'
    for coba in range(3):
        r = subprocess.run(['edge-tts', '--voice', voice, '--rate=-8%', '--pitch=-8Hz',
                            '--text', text, '--write-media', out], capture_output=True)
        if r.returncode == 0 and os.path.exists(out) and os.path.getsize(out) > 1000:
            return out
    return None

def audio_len(ff, path):
    r = subprocess.run([ff, '-i', path], capture_output=True, text=True)
    m = re.search(r'Duration: (\d+):(\d+):(\d+\.\d+)', r.stderr)
    if not m: return 5.0
    h, mi, s = m.groups()
    return int(h)*3600 + int(mi)*60 + float(s)

def concat(ff, files, out, is_video=True):
    lst = out + '.list'
    with open(lst, 'w') as f:
        for p in files: f.write(f"file '{os.path.abspath(p)}'\n")
    cmd = [ff, '-y', '-loglevel', 'error', '-f', 'concat', '-safe', '0', '-i', lst] + (
        ['-c', 'copy'] if is_video else ['-c:a', 'libmp3lame', '-b:a', '160k']) + [out]
    ok = subprocess.run(cmd, capture_output=True).returncode == 0
    os.remove(lst)
    return ok

# ---------- main ----------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('srt')
    ap.add_argument('--out', default='ep_srt')
    ap.add_argument('--voice', default='en-US-AndrewNeural')
    ap.add_argument('--no-tts', action='store_true', help='durasi ikut timing file srt')
    ap.add_argument('--fps', type=int, default=12)
    ap.add_argument('--theme', default='white', choices=['white', 'navy'])
    ap.add_argument('--limit', type=int, default=0, help='render N baris pertama saja')
    args = ap.parse_args()

    os.makedirs(args.out, exist_ok=True)
    ff = find_ffmpeg()
    if not ff:
        print('ffmpeg tidak ada. Install: pkg install ffmpeg'); sys.exit(1)
    if args.theme == 'white':
        sp.apply_white_theme()

    cues = parse_srt(args.srt)
    if args.limit: cues = cues[:args.limit]
    if not cues:
        print('tidak ada cue valid di srt'); sys.exit(1)
    print(f'=== SRT2VIDEO: {len(cues)} baris subtitle | tema {args.theme} ===')

    # ---- 1. beat + audio per baris
    beats, audios, texts = [], [], []
    for i, (t0, t1, text) in enumerate(cues, 1):
        if args.no_tts:
            dur = max(2.5, t1 - t0)
            vo = None
        else:
            vo = gen_vo(text, i, args.voice)
            dur = audio_len(ff, vo) + 0.45 if vo else max(2.5, t1 - t0)
        print(f'  [{i}/{len(cues)}] {dur:5.1f}s  "{text[:44]}"')
        beats.append(sp.auto_beat(text, dur))
        # ---- 2. teks kinetik per baris
        chunks = kinetic.chunk_text(text)
        n = len(chunks)
        span = dur - 0.5
        tcs, cycle = [], i - 1
        for j, ch in enumerate(chunks):
            ct0 = 0.25 + j * span / n
            ct1 = ct0 + span / n * 0.92
            tcs.append((ct0, ct1, ch, kinetic.pick_style(ch, cycle + j)))
        beats[-1]['text_chunks'] = tcs
        audios.append(vo); texts.append(text)

    total = sum(b['dur'] for b in beats)
    print(f'>>> total {total/60:.1f} menit')

    # ---- 3. simpan scene.txt editable
    with open(os.path.join(args.out, 'scene.txt'), 'w', encoding='utf-8') as f:
        f.write(sp.to_dsl(beats))

    # ---- 4. render
    clips = []
    for i, b in enumerate(beats, 1):
        print(f'[{i}/{len(beats)}] render bg={b["bg"]} {b["dur"]:.1f}s ...')
        paths = sp.render_beat(b, args.fps, os.path.join(args.out, f'b{i:02d}_f'))
        clip = os.path.join(args.out, f'b{i:02d}.mp4')
        ok = subprocess.run([ff, '-y', '-loglevel', 'error', '-framerate', str(args.fps),
             '-i', os.path.join(args.out, f'b{i:02d}_f', 'f%03d.png'),
             '-c:v', 'libx264', '-pix_fmt', 'yuv420p', '-crf', '20', clip],
             capture_output=True).returncode == 0
        if not ok: print('   GAGAL', i); sys.exit(1)
        for p in paths: os.remove(p)
        os.rmdir(os.path.join(args.out, f'b{i:02d}_f'))
        clips.append(clip)

    # ---- 5. concat + audio
    final_v = os.path.join(args.out, 'video.mp4')
    concat(ff, clips, final_v, True)
    if any(audios):
        good = [a for a in audios if a]
        audio = os.path.join(args.out, 'audio.mp3')
        concat(ff, good, audio, False)
        final = os.path.join(args.out, 'final.mp4')
        subprocess.run([ff, '-y', '-loglevel', 'error', '-i', final_v, '-i', audio,
                        '-c:v', 'copy', '-c:a', 'aac', '-b:a', '160k', final],
                       capture_output=True)
        for a in audios:
            if a: os.remove(a)
        print(f'\n=== SELESAI: {final} ({total/60:.1f} menit, {len(cues)} adegan) ===')
    else:
        print(f'\n=== SELESAI (tanpa audio): {final_v} ===')

if __name__ == '__main__':
    main()
