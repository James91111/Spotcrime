#!/usr/bin/env python3
# ============================================================
#  SPOT THE SCAM — STUDIO
#  Cukup SATU perintah:  python studio.py
#  → komponen kurang? dipasang OTOMATIS (sekali saja, butuh internet)
#  → lalu jendela aplikasi langsung terbuka.
# ============================================================
import os, sys, subprocess, importlib

BASE = os.path.dirname(os.path.abspath(__file__))
PY = sys.executable or 'python3'

# (nama module python, nama paket pip)
DEPS = [
    ('flask', 'flask'),
    ('PIL', 'pillow'),
    ('edge_tts', 'edge-tts'),
    ('numpy', 'numpy'),
    ('soundfile', 'soundfile'),
    ('imageio_ffmpeg', 'imageio-ffmpeg'),
]

def komponen_kurang():
    kurang = []
    for mod, paket in DEPS:
        try:
            importlib.import_module(mod)
        except Exception:
            kurang.append(paket)
    return kurang

def main():
    os.chdir(BASE)
    kurang = komponen_kurang()
    if kurang:
        print('\n  Komponen belum lengkap — dipasang OTOMATIS (sekali saja, butuh internet):')
        print('  ' + '  '.join(kurang) + '\n')
        r = subprocess.run([PY, '-m', 'pip', 'install', '-q'] + kurang)
        if r.returncode != 0:
            print('\n  !! Gagal memasang otomatis (cek internet). Pasang manual lalu ulangi:')
            print('     pip install ' + ' '.join(kurang))
            return
        print('  ✔ Komponen lengkap.\n')
    print('  Membuka jendela SPOT THE SCAM Studio... (tutup jendela = selesai)')
    try:
        subprocess.run([PY, os.path.join(BASE, 'a2studio.py'), '--port', '8808'])
    except KeyboardInterrupt:
        pass

if __name__ == '__main__':
    main()
