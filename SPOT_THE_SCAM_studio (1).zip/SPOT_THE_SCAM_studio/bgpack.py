#!/usr/bin/env python3
# ============================================================
#  BGPACK — 100 resep background (deterministik) + katalog PNG
#  Dipakai stage.py: tiap klip dapat latar berbeda dari pool 100,
#  digambar prosedural (ringan, cache) — bukan file besar per frame.
#  python bgpack.py          -> render katalog 100 PNG (640x360)
# ============================================================
import os, json, math, random, hashlib
from PIL import Image, ImageDraw
import paths

W, H = 1920, 1080
INK = (30, 34, 58)

PALETTES = {
    'ivory': dict(sky=(250, 250, 252), ground=(240, 241, 246), accent=(226, 230, 240)),
    'sky':   dict(sky=(240, 246, 252), ground=(228, 238, 248), accent=(206, 222, 240)),
    'mint':  dict(sky=(244, 250, 246), ground=(232, 244, 236), accent=(208, 232, 218)),
    'blush': dict(sky=(252, 248, 248), ground=(246, 238, 240), accent=(238, 220, 224)),
    'sand':  dict(sky=(250, 248, 242), ground=(243, 238, 226), accent=(232, 224, 204)),
    'clinical': dict(sky=(244, 250, 250), ground=(228, 240, 240), accent=(204, 228, 226)),
    'wood':     dict(sky=(250, 246, 238), ground=(240, 230, 214), accent=(228, 212, 186)),
    'terminal': dict(sky=(238, 244, 252), ground=(222, 232, 246), accent=(200, 216, 238)),
    'dusk':     dict(sky=(244, 240, 250), ground=(234, 228, 242), accent=(222, 210, 236)),
    'store':    dict(sky=(252, 250, 244), ground=(244, 238, 226), accent=(236, 226, 204)),
}
# 40 resep lokasi bernama (v4.0) — ditempel SETELAH 100 resep lama agar lama tetap identik
_NEWS = [
    ('hospital',  'tiles',   'cross',    'clinical'), ('hospital_b', 'tiles',  'none',  'clinical'),
    ('hospital_c','panels',  'cross',    'clinical'), ('hospital_d', 'tiles',  'plant', 'clinical'),
    ('hospital_e','panels',  'none',     'clinical'),
    ('court',     'panels',  'pillars',  'wood'),     ('court_b',    'panels', 'none',  'wood'),
    ('court_c',   'panels',  'scales',   'wood'),     ('court_d',    'tiles',  'pillars','wood'),
    ('court_e',   'plain',   'scales',   'wood'),
    ('airport',   'archwin', 'plane',    'terminal'), ('airport_b',  'archwin','board', 'terminal'),
    ('airport_c', 'tiles',   'board',    'terminal'), ('airport_d',  'archwin','none',  'terminal'),
    ('airport_e', 'grid',    'plane',    'terminal'), ('airport_f',  'plain',  'board', 'terminal'),
    ('mall',      'tiles',   'shelf',    'store'),    ('mall_b',     'tiles',  'none',  'store'),
    ('mall_c',    'grid',    'shelf',    'store'),    ('mall_d',     'stripes','shelf', 'store'),
    ('mall_e',    'plain',   'shelf',    'store'),    ('mall_f',     'tiles',  'cart',  'store'),
    ('dusk',      'citysky', 'lights',   'dusk'),     ('dusk_b',     'citysky','lamppost','dusk'),
    ('dusk_c',    'citysky', 'none',     'dusk'),     ('dusk_d',     'stripes','lights','dusk'),
    ('dusk_e',    'plain',   'lamppost', 'dusk'),     ('dusk_f',     'citysky','signpost','dusk'),
    ('parkdusk',  'meadow',  'tree',     'dusk'),     ('parkdusk_b', 'meadow', 'bench', 'dusk'),
    ('parkdusk_c','meadow',  'none',     'dusk'),     ('parkdusk_d', 'meadow', 'flowers','dusk'),
    ('parkdusk_e','arc',     'bench',    'dusk'),
    ('clinic',    'panels',  'plant',    'clinical'), ('clinic_b',   'grid',   'none',  'clinical'),
    ('clinic_c',  'dots',    'plant',    'clinical'), ('clinic_d',   'plain',  'cross', 'clinical'),
    ('clinic_e',  'panels',  'frame',    'clinical'),
    ('lobby',     'panels',  'frame',    'wood'),
    ('news',      'panels',  'bigscreen', 'terminal'), ('news_b',     'tiles',  'bigscreen', 'clinical'),
    ('news_c',    'stripes', 'bigscreen', 'ivory'),    ('news_d',     'plain',  'bigscreen', 'sky'),
    ('highway',   'road',    'signpost', 'sky'),      ('highway_b',  'road',   'tree',  'sand'),
    ('highway_c', 'road',    'sun',      'ivory'),     ('lobby_b',    'tiles',  'plant', 'wood'),
]
BASES = ['plain', 'dots', 'grid', 'stripes', 'arc', 'meadow']
DECOS = ['none', 'bush', 'flowers', 'tree', 'pine', 'grass', 'lamppost', 'bench',
         'fence', 'signpost', 'mailbox', 'sun', 'clouds', 'plant', 'frame',
         'book', 'star', 'mug', 'radio', 'arrow']

# ---- drawable mini (mengikuti gaya objpack) ----------------------
def _ell(d, xy, fill=None, w=5):
    d.ellipse(xy, fill=fill, outline=INK, width=w)
def _ln(d, pts, w=6, col=INK):
    d.line(pts, fill=col, width=w)
def _o(d, xy, r=6, fill=None, w=5):
    d.rounded_rectangle([xy[0], xy[1], xy[2], xy[3]], r, fill=fill, outline=INK, width=w)

def draw_deco(d, kind, cx, gy, s, rng, alpha):
    """gambar dekorasi ambien di sekitar garis tanah (gy), skala s"""
    P = PASTEL = dict(green=(150, 196, 150), brown=(160, 122, 92),
                      yellow=(240, 200, 90), red=(226, 130, 120),
                      blue=(150, 170, 210), grey=(190, 196, 208))
    lay = Image.new('RGBA', d._image.size, (0, 0, 0, 0))
    ld = ImageDraw.Draw(lay)
    def E(xy, fill=None, w=5): _ell(ld, xy, fill, w)
    def L(pts, w=6, col=INK): _ln(ld, pts, w, col)
    def O(xy, r=6, fill=None, w=5): _o(ld, xy, r, fill, w)
    if kind == 'bigscreen':
        O([cx-260*s, gy-560*s, cx+260*s, gy-260*s], 14, fill=(52, 60, 88), w=6)
        for r_ in range(2):
            L([cx-220*s, gy-500*s+r_*70*s, cx+40*s, gy-500*s+r_*70*s], 8, (150, 200, 170))
            L([cx+90*s, gy-500*s+r_*70*s, cx+220*s, gy-500*s+r_*70*s], 8, (240, 200, 90))
        E([cx+150*s, gy-330*s, cx+230*s, gy-290*s], fill=(214, 84, 78), w=4)
        L([cx-260*s, gy-260*s, cx-260*s, gy], 8)
        L([cx+260*s, gy-260*s, cx+260*s, gy], 8)
    if kind == 'cross':
        L([cx, gy, cx, gy-360*s], int(12*s), (150, 156, 172))
        E([cx-130*s, gy-580*s, cx+130*s, gy-320*s], fill=(255, 255, 255), w=8)
        ld.rounded_rectangle([cx-24*s, gy-540*s, cx+24*s, gy-390*s], 8, fill=(214, 84, 78))
        ld.rounded_rectangle([cx-75*s, gy-508*s, cx+75*s, gy-424*s], 8, fill=(214, 84, 78))
    elif kind == 'pillars':
        for dx in (-150*s, 150*s):
            O([cx+dx-46*s, gy-520*s, cx+dx+46*s, gy], 10, fill=(240, 234, 220), w=6)
            O([cx+dx-66*s, gy-566*s, cx+dx+66*s, gy-516*s], 10, fill=(240, 234, 220), w=6)
    elif kind == 'scales':
        L([cx, gy, cx, gy-230*s], int(8*s), P['brown'])
        L([cx-120*s, gy-210*s, cx+120*s, gy-210*s], 7)
        for dx in (-120*s, 120*s):
            L([cx+dx, gy-210*s, cx+dx, gy-150*s], 5)
            E([cx+dx-44*s, gy-150*s, cx+dx+44*s, gy-118*s], fill=P['yellow'], w=4)
        E([cx-26*s, gy-256*s, cx+26*s, gy-204*s], fill=P['yellow'], w=4)
    elif kind == 'plane':
        ss = max(s, 1.2)
        y = 300
        ld.polygon([(cx, y), (cx+280*ss, y+52*ss), (cx, y+104*ss), (cx-48*ss, y+52*ss)],
                   fill=(146, 160, 196), outline=INK)
        ld.polygon([(cx+70*ss, y+52*ss), (cx+200*ss, y+186*ss), (cx+252*ss, y+186*ss),
                    (cx+128*ss, y+52*ss)], fill=(178, 190, 216), outline=INK)
        L([cx-880*ss, y+112*ss, cx-70*ss, y+58*ss], 7, (196, 204, 222))
    elif kind == 'board':
        O([cx-150*s, gy-360*s, cx+150*s, gy-160*s], 12, fill=(52, 60, 88))
        for r_ in range(3):
            L([cx-118*s, gy-320*s+r_*52*s, cx+60*s, gy-320*s+r_*52*s], 6, (150, 200, 170))
            L([cx+84*s, gy-320*s+r_*52*s, cx+128*s, gy-320*s+r_*52*s], 6, (240, 200, 90))
        L([cx-90*s, gy-160*s, cx-90*s, gy], 7)
        L([cx+90*s, gy-160*s, cx+90*s, gy], 7)
    elif kind == 'shelf':
        col = P['brown']
        O([cx-210*s, gy-110*s, cx+210*s, gy-84*s], 6, fill=col)
        O([cx-210*s, gy-260*s, cx+210*s, gy-234*s], 6, fill=col)
        O([cx-210*s, gy-410*s, cx+210*s, gy-384*s], 6, fill=col)
        for xx in (-160*s, -50*s, 60*s):
            E([cx+xx, gy-166*s, cx+xx+92*s, gy-88*s], fill=P['blue'], w=5)
            E([cx+xx, gy-316*s, cx+xx+92*s, gy-238*s], fill=P['red'], w=5)
        L([cx-210*s, gy, cx-210*s, gy-410*s], 7)
        L([cx+210*s, gy, cx+210*s, gy-410*s], 7)
    elif kind == 'lights':
        for k in range(7):
            x = cx - 240*s + k*80*s
            y = gy - 300*s + (30*s if k % 2 else 0)
            L([x, y, x+80*s, y+30*s if k % 2 == 0 else y-0*s], 4, (170, 176, 192))
            E([x+58*s, y+30*s-8*s, x+74*s, y+30*s+8*s], fill=P['yellow'], w=3)
        L([cx-250*s, gy, cx-250*s, gy-310*s], 6, (120, 128, 150))
        L([cx+310*s, gy, cx+310*s, gy-270*s], 6, (120, 128, 150))
    elif kind == 'cart':
        ld.polygon([(cx-90*s, gy-150*s), (cx+90*s, gy-150*s), (cx+60*s, gy-40*s),
                    (cx-60*s, gy-40*s)], fill=(206, 214, 228), outline=INK)
        E([cx-50*s, gy-28*s, cx-10*s, gy+8*s], fill=None, w=5)
        E([cx+14*s, gy-28*s, cx+54*s, gy+8*s], fill=None, w=5)
        L([cx+80*s, gy-170*s, cx+110*s, gy-190*s], 6)
    if kind == 'bush':
        for dx, dy, r in ((-46, -10, 52), (6, -26, 62), (58, -6, 44)):
            E([cx+dx*s-r, gy+dy*s-r, cx+dx*s+r, gy+dy*s+r], fill=P['green'], w=4)
    elif kind == 'tree':
        h = 150*s
        L([cx, gy, cx, gy-h], int(11*s), P['brown'])
        E([cx-66*s, gy-h-62*s, cx+66*s, gy-h+58*s], fill=P['green'], w=5)
    elif kind == 'pine':
        h = 170*s
        L([cx, gy, cx, gy-14], int(9*s), P['brown'])
        for k, wd in ((0, 92*s), (44*s, 70*s), (88*s, 48*s)):
            ld.polygon([(cx, gy-h+k), (cx-wd, gy-k+16), (cx+wd, gy-k+16)],
                       fill=(120, 172, 130), outline=INK)
    elif kind == 'grass':
        for i in range(6):
            x = cx + (i-3)*24*s + rng.randint(-5, 5)
            h = rng.randint(24, 44)*s
            ld.arc([x-14*s, gy-h, x+14*s, gy+h], 200, 340, fill=(140, 190, 138), width=5)
    elif kind == 'flowers':
        for i in range(3):
            x = cx + (i-1)*54*s
            col = rng.choice([P['red'], P['yellow'], (190, 150, 200)])
            L([x, gy, x, gy-58*s], 5)
            for a in range(0, 360, 72):
                x2 = x + 14*s*math.cos(math.radians(a))
                y2 = gy-64*s + 14*s*math.sin(math.radians(a))
                E([x2-9, y2-9, x2+9, y2+9], fill=col, w=3)
            E([x-7*s, gy-71*s, x+7*s, gy-57*s], fill=P['yellow'], w=3)
    elif kind == 'lamppost':
        L([cx, gy, cx, gy-190*s], int(10*s), (90, 98, 122))
        ld.polygon([(cx, gy-226*s), (cx-28*s, gy-176*s), (cx+28*s, gy-176*s)],
                   fill=(90, 98, 122), outline=INK)
        E([cx-13*s, gy-210*s, cx+13*s, gy-184*s], fill=P['yellow'], w=3)
    elif kind == 'bench':
        col = P['brown']
        O([cx-96*s, gy-96*s, cx+96*s, gy-76*s], 6, fill=col)
        O([cx-96*s, gy-58*s, cx+96*s, gy-40*s], 6, fill=col)
        L([cx-74*s, gy-76*s, cx-74*s, gy], 7)
        L([cx+74*s, gy-76*s, cx+74*s, gy], 7)
        L([cx-74*s, gy-96*s, cx-74*s, gy-124*s], 7)
        L([cx+74*s, gy-96*s, cx+74*s, gy-124*s], 7)
        O([cx-96*s, gy-132*s, cx+96*s, gy-116*s], 6, fill=col)
    elif kind == 'fence':
        col = (222, 212, 190)
        for i in range(4):
            x = cx + (i-1.5)*44*s
            O([x, gy-118*s, x+15*s, gy], 6, fill=col, w=4)
        L([cx-96*s, gy-86*s, cx+96*s, gy-86*s], 6, col)
        L([cx-96*s, gy-44*s, cx+96*s, gy-44*s], 6, col)
    elif kind == 'signpost':
        L([cx, gy, cx, gy-140*s], 7)
        E([cx-66*s, gy-222*s, cx+66*s, gy-100*s], fill=(238, 150, 90), w=4)
        L([cx-34*s, gy-180*s, cx+34*s, gy-180*s], 6, (255, 255, 255))
        L([cx-34*s, gy-152*s, cx+20*s, gy-152*s], 6, (255, 255, 255))
    elif kind == 'mailbox':
        L([cx, gy, cx, gy-92*s], 8, P['brown'])
        ld.rounded_rectangle([cx-52*s, gy-156*s, cx+52*s, gy-88*s], 30*s,
                             fill=(150, 170, 210), outline=INK, width=4)
    elif kind == 'sun':
        E([cx-58*s, gy-330*s, cx+58*s, gy-214*s], fill=(248, 208, 110), w=4)
        for a in range(0, 360, 45):
            x1 = cx + 72*s*math.cos(math.radians(a)); y1 = gy-272*s + 72*s*math.sin(math.radians(a))
            x2 = cx + 96*s*math.cos(math.radians(a)); y2 = gy-272*s + 96*s*math.sin(math.radians(a))
            L([x1, y1, x2, y2], 5, (238, 168, 92))
    elif kind == 'clouds':
        for dx, dy in ((0, 0), (150*s, 40), (-170*s, 60)):
            for ddx, ddy, r in ((-40*s, 0, 36*s), (0, -18*s, 46*s), (44*s, 0, 32*s)):
                E([cx+dx+ddx-r, gy-260*s+dy+ddy-r, cx+dx+ddx+r, gy-260*s+dy+ddy+r],
                  fill=(255, 255, 255), w=4)
    elif kind == 'plant':
        col = P['brown']
        ld.polygon([(cx-32*s, gy-64*s), (cx+32*s, gy-64*s), (cx+22*s, gy), (cx-22*s, gy)],
                   fill=col, outline=INK)
        for dx, dy, r in ((0, -108*s, 40*s), (-34*s, -84*s, 28*s), (34*s, -84*s, 28*s)):
            E([cx+dx-r, gy+dy-r, cx+dx+r, gy+dy+r], fill=P['green'], w=4)
    elif kind == 'frame':
        for i in range(2):
            x = cx + (i-0.5)*180*s
            w_, h_ = 86*s, 66*s
            O([x, gy-360*s+ (i*26), x+w_, gy-360*s+h_+(i*26)], 5,
              fill=(244, 238, 224), w=4)
            O([x+12*s, gy-348*s+(i*26), x+w_-12*s, gy-360*s+h_-12*s+(i*26)], 3,
              fill=(206, 222, 240), w=2)
    elif kind == 'book':
        O([cx-70*s, gy-150*s, cx+70*s, gy], 6, fill=(150, 130, 190), w=4)
        O([cx-56*s, gy-138*s, cx+58*s, gy-12*s], 3, fill=(255, 255, 255), w=2)
    elif kind == 'star':
        cx_, cy_, R, r_ = cx, gy-240*s, 70*s, 30*s
        pts = []
        for i in range(10):
            rad = R if i % 2 == 0 else r_
            a = -90 + i*36
            pts.append((cx_ + rad*math.cos(math.radians(a)), cy_ + rad*math.sin(math.radians(a))))
        ld.polygon(pts, fill=P['yellow'], outline=INK)
    elif kind == 'mug':
        O([cx-44*s, gy-104*s, cx+44*s, gy], 12, fill=(226, 130, 120), w=4)
        ld.arc([cx+38*s, gy-84*s, cx+84*s, gy-30*s], 270, 90, fill=INK, width=6)
    elif kind == 'radio':
        O([cx-84*s, gy-120*s, cx+84*s, gy], 10, fill=(120, 110, 140), w=4)
        E([cx-58*s, gy-92*s, cx-6*s, gy-28*s], fill=(244, 238, 224), w=3)
        O([cx+8*s, gy-92*s, cx+62*s, gy-66*s], 4, fill=(244, 238, 224), w=3)
    elif kind == 'arrow':
        col = (120, 170, 200)
        ld.polygon([(cx-90*s, gy-80*s), (cx+10*s, gy-80*s), (cx+10*s, gy-110*s),
                    (cx+90*s, gy-60*s), (cx+10*s, gy-10*s), (cx+10*s, gy-40*s),
                    (cx-90*s, gy-40*s)], fill=col, outline=INK)
    if alpha < 255:
        lay = lay.point(lambda v: v)
        a = lay.getchannel('A').point(lambda v: int(v * alpha / 255))
        lay.putalpha(a)
    return lay

# ---- resep 100 bg ------------------------------------------------
def _recipes():
    out = []
    step = max(1, (len(BASES)*len(DECOS)*len(PALETTES)) // 100)
    i = 0
    while len(out) < 100:
        b = BASES[i % len(BASES)]
        dc = DECOS[(i // len(BASES)) % len(DECOS)]
        pal = list(PALETTES)[(i // (len(BASES)*len(DECOS))) % len(PALETTES)]
        name = f'{b}_{dc}_{pal}'
        if name not in [o[0] for o in out]:
            out.append((name, b, dc, pal))
        i += step if len(out) < 60 else 1
        if i > 10000: break
    return out[:100] + _NEWS

RECIPES = _recipes()
NAMES = [r[0] for r in RECIPES]
_cache = {}

def _base_image(base, pal, rng):
    p = PALETTES[pal]
    img = Image.new('RGB', (W, H), p['sky'])
    d = ImageDraw.Draw(img)
    gy = 912
    if base == 'dots':
        for y in range(70, H, 46):
            for x in range(40, W, 46):
                d.ellipse([x-2, y-2, x+2, y+2], fill=p['accent'])
    elif base == 'grid':
        for x in range(0, W, 92):
            d.line([x, 0, x, H], fill=p['accent'], width=2)
        for y in range(0, H, 92):
            d.line([0, y, W, y], fill=p['accent'], width=2)
    elif base == 'stripes':
        for i, y in enumerate(range(-100, H, 130)):
            d.rounded_rectangle([-40, y, W+40, y+52], 26, fill=p['accent'])
    elif base == 'arc':
        for r in range(560, 160, -110):
            d.arc([W//2-r, gy-r, W//2+r, gy+r], 180, 360, fill=p['accent'], width=26)
    elif base == 'meadow':
        for k in range(3):
            y = gy - 40 - k*46
            d.arc([-200, y, W+200, y+420], 180, 360, fill=p['accent'], width=18)
    elif base == 'tiles':
        for yy in range(60, gy, 190):
            for xx in range(0, W, 190):
                if (xx//190 + yy//190) % 2 == 0:
                    d.rounded_rectangle([xx+6, yy+6, xx+184, yy+184], 18, fill=p['accent'])
    elif base == 'panels':
        for xx in range(-40, W+40, 240):
            d.rounded_rectangle([xx+8, 40, xx+228, gy+4], 14, fill=p['accent'])
            d.line([xx+118, 40, xx+118, gy+4], fill=p['ground'], width=4)
    elif base == 'archwin':
        for k in range(4):
            x = 190 + k*430
            d.rounded_rectangle([x, 180, x+300, 700], 150, fill=p['ground'])
            d.rounded_rectangle([x+26, 206, x+274, 700], 124, outline=p['accent'], width=14)
    elif base == 'road':
        d.polygon([(760, gy), (1160, gy), (1560, 90), (360, 90)], fill=(206, 210, 222))
        for k in range(5):
            y0 = gy - 20 - k*150
            wq = 12 + k*10
            d.rounded_rectangle([W/2 - wq, y0 - 30 - k*8, W/2 + wq, y0], 8, fill=(250, 250, 252))
    elif base == 'citysky':
        rng2 = random.Random(7)
        for k in range(9):
            bw = rng2.randint(150, 260)
            bx = k*225 - rng2.randint(0, 60)
            bh = rng2.randint(240, 560)
            d.rounded_rectangle([bx, gy-bh, bx+bw, gy], 12, fill=p['accent'])
            for wy in range(gy-bh+50, gy-40, 110):
                for wx in range(bx+36, bx+bw-30, 84):
                    d.rounded_rectangle([wx, wy, wx+34, wy+44], 6, fill=p['sky'])
    d.rectangle([0, gy+8, W, H], fill=p['ground'])
    d.line([0, gy+8, W, gy+8], fill=(214, 220, 232), width=3)
    return img

def render(name):
    """render bg resep -> Image RGB 1920x1080 (cache)"""
    if name in _cache: return _cache[name]
    rec = next((r for r in RECIPES if r[0] == name), RECIPES[0])
    _, base, deco, pal = rec
    seed = int(hashlib.md5(name.encode()).hexdigest()[:6], 16)
    rng = random.Random(seed)
    img = _base_image(base, pal, rng)
    if deco != 'none':
        d = ImageDraw.Draw(img)
        n = 2 if deco in ('bush', 'grass', 'flowers', 'fence', 'clouds') else 1
        for k in range(n):
            cx = rng.randint(160, W-160)
            s = rng.uniform(0.85, 1.5)
            layer = draw_deco(d, deco, cx, 912, s, rng, alpha=110)
            img.paste(layer, (0, 0), layer)
    _cache[name] = img
    return img

def pick(motif, idx, avoid=None):
    """pilih bg resep dgn deterministik + hindari sama berturut"""
    h = int(hashlib.md5(f'{motif}:{idx}'.encode()).hexdigest()[:8], 16)
    name = NAMES[h % len(NAMES)]
    if name == avoid:
        name = NAMES[(h + 37) % len(NAMES)]
    return name

def main():
    # ekspor katalog 100 PNG (640x360) utk preview GUI/manual
    outdir = None
    for a in paths.ASSETS:
        p = os.path.join(a, 'bgpack')
        if os.path.isdir(os.path.dirname(p)):
            outdir = p; break
    outdir = outdir or 'bgpack'
    os.makedirs(outdir, exist_ok=True)
    manifest = {}
    for i, (name, base, deco, pal) in enumerate(RECIPES, 1):
        big = render(name)
        small = big.resize((640, 360), Image.LANCZOS)
        fn = f'bg_{i:03d}.png'
        small.save(os.path.join(outdir, fn))
        manifest[fn] = dict(name=name, base=base, deco=deco, palette=pal)
    with open(os.path.join(outdir, 'manifest.json'), 'w') as f:
        json.dump(manifest, f, indent=1)
    print('bgpack:', len(RECIPES), 'resep ->', outdir)
    from collections import Counter
    print(Counter(p for *_, p in RECIPES))

if __name__ == '__main__':
    main()
