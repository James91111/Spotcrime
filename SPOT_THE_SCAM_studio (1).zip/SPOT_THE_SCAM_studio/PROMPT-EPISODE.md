# 🎬 PROMPT GENERATOR EPISODE — PAKAI BERULANG KALI
*Isi 2 bagian [KURUNG] → kirim ke AI (Arena/ChatGPT/dll) → hasilnya langsung jadi naskah siap TTS.*
*Aturan produksi terkunci di prompt — yang Anda ganti tiap episode cuma IDE + FAKTA.*

---

## 1️⃣ PROMPT NARASI UNIVERSAL (copy semuanya, isi bagian KURUNG)

```
You are the head writer of "Spot The Scam" — a faceless YouTube channel
with stickman explainer videos, made for a US audience aged 55+.

=== MY INPUT ===
EPISODE IDEA:
[TULIS IDE ANDA — cth: "the grandson emergency phone call scam"
 / "fake bank fraud alert calls" / "check washing from mailboxes"]

FACTS & SOURCES — USE ONLY THESE. Do not invent, round up, or change any
number or case:
[TEMPEL FAKTA DARI RISET ANDA — cth:
 - FBI IC3 2025: seniors 60+ filed 201,266 reports, losses $7.7 BILLION (+59%)
 - Case: "Little Tiger" scam ring, $27M from ~2,000 victims aged 70-80,
   guilty plea April 2026 (DOJ)
 - FRONTLINE/AP "Scammed" Sep 2026: romance-scam widower lost $812,000
 - artikel/URL/berita lain...]

=== TASK ===
Write the complete narration script for this episode.

=== HARD RULES ===
1. Simple American English, second person ("you"). Sentences under 15 words.
   Warm but urgent. A 70-year-old must understand every word.
2. Length: 1,550-1,700 words (about 11-12 minutes at 145 wpm).
3. Use ONLY the facts above. Every number and case must come from my sources.
   If you do not have a number, write the sentence without one. NEVER invent.
4. ZERO quotation marks anywhere. Report speech indirectly
   (write: she said it was her grandson — not "grandma, it's me").
5. Plain narration text only: no markdown, no headings, no emojis, no stage
   directions, no scene labels.
6. Format: ONE paragraph = ONE scene. 25-32 paragraphs, 45-60 words each.
   Separate scenes with a line containing only ---
7. NO channel intro, no greeting. Start cold with the biggest number.

=== STRUCTURE ===
1. COLD OPEN (paragraph 1): the most shocking number from my sources + the
   unexpected place or moment + a promise of what this episode reveals.
2. BODY — pick the right shape for my material:
   - MANY scams in my facts  -> COUNTDOWN from lowest to #1 (most shocking last)
   - ONE story in my facts   -> STORY: tell it in order, then break it into
                                5 RED FLAGS the viewer can learn
3. EVERY scam item / red flag (1-2 paragraphs) contains:
   a. one-sentence scene of the moment it happens (The phone rings...)
   b. how the trick works, step by step
   c. the real case or number from my sources, with one human detail
   d. THE FIX: exactly ONE concrete action to stop it
4. MIDDLE CTA (one sentence, around the halfway point): if the viewer has a
   parent or friend who needs the next part, subscribe.
5. PAYOFF near the end: the ONE thing all cases have in common -> one golden
   rule (example of the idea: every scam needs the victim to make one move;
   remove the move and the scam dies).
6. ENDING CTA: ask viewers to comment which of these they have seen, using
   the item number, so it may save someone else.

=== BEFORE YOU SEND, CHECK ===
word count 1550-1700 - scene format with --- - zero quotation marks -
zero invented numbers. Print ONLY the finished script.
```

### Cara pakai (3 langkah, tiap episode)
1. **Cari bahan** (risetsendiri/berita/laporan FBI) → blok fakta & angkanya
2. **Tempel** ke bagian `[ ... ]` — isi IDEA + FAKTA — kirim ke AI
3. **Simpan jawaban AI** sebagai `.txt` → GUI: 🧹 Bersihkan → 📄 Upload Narasi → cek
   estimasi menit → 🎤 Generate Voiceover

> Kalau jawaban AI masih ada tanda petik/kurung markdown: minta sekali lagi
> "remove all quotation marks and markdown, output plain text only".

---
 RUMUS JUDUL (pilih 1, ganti [kurung])

| Rumus | Contoh jadi |
|---|---|
| **[N] + [audiens] + [kerugian $] + [tahun] : teaser #1** | 10 Scams Stealing Billions From Seniors In 2026 (#1 Is In Your Mailbox) |
| **Orang biasa + angka + aksi penipu** | She Sent $38,000 in Gift Cards. The Caller Was 400 Miles Away. |
| **Never + aksi + akibat** | Never Answer This Call. Here's What They Do To Your Savings. |
| **How scammers + aksi + dalam waktu — tandanya** | How Scammers Empty A Bank Account In 20 Minutes (The Warning Signs) |
| **Ini [objek sehari-hari] — dan itu masalahnya** | Your Mailbox Is The #1 Scam Location In America |

Aturan: angka & $ selalu ada · kata kunci di 40 karakter pertama · tahun = sinyal segar ·
1 curiosity gap saja · thumbnail TIDAK mengulang kata judul.

---

## 3️⃣ THUMBNAIL — resep + perintah jadi

Resep (dibedah dari thumbnail 38K views/2 minggu di niche ini):
**karakter shock di kanan + teks 2–4 kata (putih + 1 warna aksen) + objek bukti
dilingkari merah + latar navy gelap kontras** — teks ≤4 kata = +30% CTR.

```bash
python thumb_gen.py --motif phone        # GRANDSON? / NOT HIM. -> hasil/thumb.png
python thumb_gen.py --list               # 8 preset: phone giftcard bank medicare crypto prize check custom
python thumb_gen.py --motif giftcard --l1 "SHE PAID" --l2 "$38,000"
```
Pairing contoh: judul "The Grandparent Call Scam, Broken Down In 10 Minutes"
× thumbnail "GRANDSON? / NOT HIM." — beda kata, satu cerita yang sama.
