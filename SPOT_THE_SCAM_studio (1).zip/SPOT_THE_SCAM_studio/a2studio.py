#!/usr/bin/env python3
# ============================================================
#  A2 STUDIO v4.0 — GUI web pipeline AUDIO-FIRST (Spot the Scam)
#  Urutan kerja di UI:
#   1) Generate Voiceover (TTS)  → wav + srt klip (Andrew default)
#   2) Scan rencana klip         → lihat penggabungan <5 dtk
#   3) Render video              → final.mp4 (dengan progress + ETA)
#  Jalankan: python a2studio.py --port 8808
# ============================================================
import os, sys, re, glob, json, time, subprocess, threading
try:
    from flask import Flask, request, jsonify, send_file, Response
except ImportError:
    print('\n  Komponen GUI belum lengkap.')
    print('  Jalankan:  python studio.py   → otomatis memasang & membuka studio.')
    print('  Manual   :  pip install flask pillow edge-tts numpy soundfile imageio-ffmpeg\n')
    sys.exit(1)
from PIL import Image, ImageDraw

BASE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE)
import a2video, cast, paths
from stickanim import find_ffmpeg

FF = find_ffmpeg()
app = Flask(__name__)
os.environ['A2_BASE'] = paths.BASE   # satu sumber folder utk SEMUA child process
JOB = {'proc': None, 'running': False, 'phase': '', 'out': '', 't0': 0.0}

VOICES = [
    ('en-US-AndrewNeural',      'Andrew — hangat & percaya diri (utama)'),
    ('en-US-ChristopherNeural', 'Christopher — dalam, dokumenter'),
    ('en-US-GuyNeural',         'Guy — energik gaya berita'),
    ('en-US-BrianNeural',       'Brian — santai, deep'),
    ('en-US-AriaNeural',        'Aria — wanita hangat'),
]

def _run(cmd, outdir, phase):
    JOB.update(running=True, phase=phase, out=outdir, t0=time.time())
    os.makedirs(outdir, exist_ok=True)
    logf = os.path.join(outdir, 'job.log')
    with open(logf, 'w') as f:
        p = subprocess.Popen(cmd, cwd=BASE, stdout=f, stderr=subprocess.STDOUT)
        JOB['proc'] = p
        p.wait()
    JOB['running'] = False

def _start(cmd, outdir, phase):
    if JOB['running']:
        return False
    cmd = [sys.executable, '-u'] + cmd[1:]
    threading.Thread(target=_run, args=(cmd, outdir, phase), daemon=True).start()
    return True

def _read_log(out):
    logf = os.path.join(out, 'job.log') if out else ''
    if logf and os.path.exists(logf):
        return open(logf, errors='replace').read()[-6000:]
    return ''

def _progress(out):
    """parse log -> (phase, done, total, elapsed, eta)"""
    log = _read_log(out)
    done = total = None
    # TTS: "[1/9] Processing 253 chars..." | Build: "[3/11] 7.0dtk ..."
    ms = re.findall(r'\[(\d+)/(\d+)\]', log)
    if ms:
        done, total = int(ms[-1][0]), int(ms[-1][1])
    else:
        mm = re.findall(r'merged #(\d+)', log)
        bm = re.findall(r'BUILD: (\d+) klip', log)
        if mm and bm:
            done, total = len(mm), int(bm[0])
    elapsed = time.time() - JOB['t0'] if JOB.get('t0') else 0
    eta = None
    if done and total and done > 0 and done < total:
        eta = elapsed / done * (total - done)
    elif total and done and done >= total:
        eta = 0
    return done, total, elapsed, eta

# ---------------- API ----------------
@app.get('/api/paths')
def api_paths():
    return jsonify(base=paths.BASE, audio_in=paths.AUDIO_IN, srt=paths.SRT,
                   work=paths.WORK, out=paths.OUT)

@app.post('/api/tts')
def api_tts():
    try:
        """LANGKAH 1: naskah -> pecahan wav + srt klip"""
        d = request.get_json(force=True)
        text = (d.get('text') or '').strip()
        if len(text) < 20:
            return jsonify(error='Naskah terlalu pendek (min 20 karakter)'), 400
        os.makedirs(paths.BASE, exist_ok=True)
        with open(os.path.join(paths.BASE, 'narasi.txt'), 'w', encoding='utf-8') as f:
            f.write(text)
        cmd = [sys.executable, os.path.join(BASE, 'tts_narasi.py')]
        if d.get('clean'):
            cmd.append('--clean')
        env = dict(os.environ)
        if d.get('voice'): env['TTS_VOICE'] = d['voice']
        if d.get('rate'):  env['TTS_RATE'] = d['rate']
        ok = _start(cmd, paths.WORK, 'TTS Voiceover')
        return jsonify(started=ok)
    except Exception as e:
        return jsonify(error='api_tts gagal: ' + str(e)), 500
@app.post('/api/clean')
def api_clean():
    """Bersihkan file episode lama: narasi, audio, srt, transkrip, work, video hasil."""
    if JOB['running']:
        return jsonify(error='Ada proses berjalan — tunggu selesai dulu'), 409
    dirs = (paths.AUDIO_IN, paths.SRT, paths.WORK, paths.OUT,
            os.path.join(paths.BASE, 'transkrip'))
    files = [os.path.join(paths.BASE, 'narasi.txt'),
             os.path.join(paths.BASE, 'Final_narasi.wav')]
    n, mb = 0, 0.0
    for d in dirs:
        if os.path.isdir(d):
            for dp, _, fs in os.walk(d):
                for fn in fs:
                    p = os.path.join(dp, fn)
                    try:
                        mb += os.path.getsize(p); os.remove(p); n += 1
                    except Exception:
                        pass
    for p in files:
        if os.path.exists(p):
            try:
                mb += os.path.getsize(p); os.remove(p); n += 1
            except Exception:
                pass
    return jsonify(ok=True, files=n, mb=round(mb / 1e6, 1))

@app.post('/api/thumb')
def api_thumb():
    """KARTU 4: generate thumbnail PNG 1280x720 via thumb_gen.py."""
    d = request.get_json(force=True)
    out = os.path.join(paths.OUT, 'thumb.png')
    cmd = [sys.executable, os.path.join(BASE, 'thumb_gen.py'),
           '--motif', (d.get('motif') or 'custom'),
           '--out', out]
    if d.get('l1'):
        cmd += ['--l1', str(d['l1'])[:24]]
    if d.get('l2'):
        cmd += ['--l2', str(d['l2'])[:24]]
    if d.get('accent') in ('red', 'amber'):
        cmd += ['--accent', d['accent']]
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=90)
    except Exception as e:
        return jsonify(error='Gagal menjalankan thumb_gen: %s' % e), 500
    if r.returncode != 0 or not os.path.exists(out):
        return jsonify(error='Gagal generate: ' + ((r.stderr or r.stdout or '')[-300:])), 500
    return jsonify(ok=True, file=out)

@app.get('/api/thumbimg')
def api_thumbimg():
    p = os.path.join(paths.OUT, 'thumb.png')
    if not os.path.exists(p):
        return ('thumbnail belum ada', 404)
    return send_file(p, mimetype='image/png', conditional=True)

@app.get('/api/scan')
def api_scan():
    folder = request.args.get('folder') or paths.AUDIO_IN
    if not os.path.isdir(folder):
        return jsonify(error='folder audio tidak ada'), 400
    srt = request.args.get('srt')
    if srt:
        if not os.path.isabs(srt):
            cand = os.path.join(paths.BASE, srt)
            srt = cand if os.path.exists(cand) else srt
        if os.path.exists(srt):
            segs = a2video.scan_srt(FF, srt, folder)
        else:
            segs = a2video.scan(FF, folder)
    else:
        segs = a2video.scan(FF, folder)
    return jsonify(plan=[dict(no=i+1, dur=s['dur'],
                              text=(s.get('text','') or '')[:70],
                              parts=[os.path.basename(x) for x in s['src']])
                         for i, s in enumerate(segs)])

def _resolve_srt(d):
    """SRT dari GUI -> path absolut; None kalau file tidak ada."""
    srt = (d or {}).get('srt')
    if not srt:
        srt = os.path.join(paths.SRT, 'ep01.srt')
        return srt if os.path.exists(srt) else None
    if not os.path.isabs(srt):
        cand = os.path.join(paths.BASE, srt)
        if os.path.exists(cand):
            return cand
    return srt if os.path.exists(srt) else None

def _cek_siap(folder):
    wavs = glob.glob(os.path.join(folder, '*.wav'))
    if not wavs:
        return 'Belum ada audio \u2014 jalankan LANGKAH 1 Generate Voiceover dulu'
    srt = _resolve_srt(None)
    if not srt:
        return 'SRT belum ada \u2014 tunggu Langkah 1 selesai / ulangi Generate Voiceover'
    return None

@app.errorhandler(500)
def _e500(e):
    return jsonify(error='Server error: ' + str(e)), 500

@app.errorhandler(404)
def _e404(e):
    return jsonify(error='tidak ditemukan'), 404

@app.post('/api/merge')
def api_merge():
    try:
        d = request.get_json(force=True)
        folder = d.get('folder') or paths.AUDIO_IN
        out = d.get('out') or paths.WORK
        if not os.path.isdir(folder):
            return jsonify(error='folder audio tidak ada'), 400
        gagal = _cek_siap(folder)
        if gagal:
            return jsonify(error=gagal), 400
        cmd = [sys.executable, os.path.join(BASE, 'a2video.py'), '--merge', folder, '-o', out]
        srt = _resolve_srt(d)
        if srt:
            cmd += ['--srt', srt]
        return jsonify(started=_start(cmd, out, 'Merge audio'))
    except Exception as e:
        return jsonify(error='api_merge gagal: ' + str(e)), 500
@app.post('/api/build')
def api_build():
    try:
        d = request.get_json(force=True)
        out = d.get('out') or paths.WORK
        if not os.path.exists(os.path.join(out, 'segments.json')):
            return jsonify(error='Jalankan TTS + Merge dulu (segments.json belum ada)'), 400
        cmd = [sys.executable, os.path.join(BASE, 'a2video.py'), '--build', out,
               '--fps', str(d.get('fps', 12))]
        if not d.get('plus', True):
            cmd += ['--no-plus']
        if not d.get('sfx', True):
            cmd += ['--no-sfx']
        if not d.get('musik', True):
            cmd += ['--no-music']
        cmd += ['--musik-vol', str(d.get('musikvol', 1.0)),
                '--sfx-vol', str(d.get('sfxvol', 0.7)),
                '--vo-vol', str(d.get('vovol', 1.0))]
        srt = _resolve_srt(d)
        if srt:
            cmd += ['--srt', srt]
        return jsonify(started=_start(cmd, out, 'Render video'))
    except Exception as e:
        return jsonify(error='api_build gagal: ' + str(e)), 500
@app.post('/api/all')
def api_all():
    try:
        d = request.get_json(force=True)
        folder = d.get('folder') or paths.AUDIO_IN
        out = d.get('out') or paths.WORK
        if not os.path.isdir(folder):
            return jsonify(error='folder audio tidak ada'), 400
        gagal = _cek_siap(folder)
        if gagal:
            return jsonify(error=gagal), 400
        cmd = [sys.executable, os.path.join(BASE, 'a2video.py'), '--all', folder,
               '-o', out, '--fps', str(d.get('fps', 12))]
        if not d.get('plus', True):
            cmd += ['--no-plus']
        if not d.get('sfx', True):
            cmd += ['--no-sfx']
        if not d.get('musik', True):
            cmd += ['--no-music']
        cmd += ['--musik-vol', str(d.get('musikvol', 1.0)),
                '--sfx-vol', str(d.get('sfxvol', 0.7)),
                '--vo-vol', str(d.get('vovol', 1.0))]
        srt = _resolve_srt(d)
        if srt:
            cmd += ['--srt', srt]
        return jsonify(started=_start(cmd, out, 'Merge + Render'))
    except Exception as e:
        return jsonify(error='api_all gagal: ' + str(e)), 500
@app.get('/api/status')
def api_status():
    if JOB['running'] and JOB.get('proc') is not None and JOB['proc'].poll() is not None:
        JOB['running'] = False          # self-heal: proses sudah mati, buka kunci
    out = JOB.get('out', '')
    done, total, elapsed, eta = _progress(out)
    final = os.path.join(out, 'final.mp4') if out else ''
    if not final or not os.path.exists(final):
        final = os.path.join(paths.OUT, 'final.mp4')
    return jsonify(running=JOB['running'], phase=JOB.get('phase', ''),
                   log=_read_log(out), done=done, total=total,
                   elapsed=round(elapsed), eta=round(eta) if eta is not None else None,
                   final=os.path.exists(final),
                   final_path=final if os.path.exists(final) else '',
                   v='17',
                   wavs=len(glob.glob(os.path.join(paths.AUDIO_IN, '*.wav'))),
                   srt_ok=os.path.exists(os.path.join(paths.SRT, 'ep01.srt')))

@app.get('/api/plan')
def api_plan():
    out = request.args.get('out') or paths.WORK
    f = os.path.join(out, 'segments.json')
    if not os.path.exists(f): return jsonify(segments=[])
    meta = json.load(open(f))
    return jsonify(segments=[dict(no=i+1, dur=m['dur'], text=m.get('text',''))
                             for i, m in enumerate(meta)],
                   total=sum(m['dur'] for m in meta))

@app.get('/api/frame')
def api_frame():
    out = request.args.get('out') or paths.WORK
    t = float(request.args.get('t', '0.5'))
    f = os.path.join(out, 'segments.json')
    buf_t = io.BytesIO() if False else None
    if not os.path.exists(f):
        ph = Image.new('RGB', (960, 540), (250, 250, 252))
        _d = ImageDraw.Draw(ph)
        _d.rounded_rectangle([230, 220, 730, 320], 18, fill=(255, 244, 214),
                             outline=(255, 184, 28), width=4)
        try:
            from PIL import ImageFont
            fp = paths.font('700')
            fnt = ImageFont.truetype(fp, 30) if fp else ImageFont.load_default()
        except Exception:
            fnt = ImageFont.load_default()
        _d.text((480, 262), 'Generate TTS (langkah 1) dulu untuk pratinjau',
                font=fnt, fill=(30, 34, 58), anchor='mm')
        import io as _io
        buf = _io.BytesIO(); ph.save(buf, 'PNG')
        return Response(buf.getvalue(), mimetype='image/png')
    meta = json.load(open(f))
    acc = 0.0
    import io as _io
    for i, m in enumerate(meta, 1):
        if t < acc + m['dur'] or i == len(meta):
            spec = a2video.spec_for(i, m)
            fr = a2video.stage.render_spec_frame(spec, max(0, t - acc))
            buf = _io.BytesIO(); fr.save(buf, 'PNG')
            return Response(buf.getvalue(), mimetype='image/png')
        acc += m['dur']
    return ('?', 400)

@app.get('/api/video')
def api_video():
    p = request.args.get('p')
    if p:
        p = os.path.abspath(p)
        if not (p.startswith(os.path.abspath(paths.BASE)) or
                p.startswith(os.path.abspath(os.path.join(paths.BASE, '..', 'Aspotcrime_review')))):
            return ('path di luar area', 403)
    else:
        out = request.args.get('out') or paths.WORK
        p = os.path.join(out, 'final.mp4')
    if not os.path.exists(p): return ('final.mp4 belum ada', 404)
    return send_file(p, mimetype='video/mp4', conditional=True)

@app.get('/api/sprite')
def api_sprite():
    name = request.args.get('name', 'chars/p1_stand')
    im = a2video.kenney.sprite(name)
    if im is None: return ('?', 404)
    import io as _io
    buf = _io.BytesIO(); im.save(buf, 'PNG')
    return Response(buf.getvalue(), mimetype='image/png')

@app.get('/api/cast')
def api_cast():
    who = request.args.get('who', 'grandma')
    pose = request.args.get('pose', 'talk')
    import io as _io
    im = cast.frame(who, pose)
    buf = _io.BytesIO(); im.save(buf, 'PNG')
    return Response(buf.getvalue(), mimetype='image/png')

@app.get('/api/voices')
def api_voices():
    return jsonify(voices=[dict(id=v, label=l) for v, l in VOICES])

# ---------------- HALAMAN ----------------
PAGE = """<!doctype html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>A2 Studio — Spot the Scam</title>
<style>
:root{--navy:#12275A;--navy2:#0D1B3E;--amber:#FFC53D;--red:#E02020;
      --bg:#F5F6FA;--ink:#1B2140;--dim:#8A93AC;--card:#FFFFFF;--ok:#1B9E4B}
*{box-sizing:border-box;margin:0;padding:0;font-family:'Segoe UI',system-ui,sans-serif}
body{background:var(--bg);color:var(--ink);display:flex;min-height:100vh}
aside{width:250px;background:linear-gradient(180deg,var(--navy),var(--navy2));
      color:#fff;padding:26px 20px;flex-shrink:0}
aside h1{font-size:21px;letter-spacing:.5px}
aside h1 b{color:var(--amber)}
aside p{color:#9FB0D8;font-size:12px;margin-top:6px;line-height:1.5}
.badge{display:inline-block;background:rgba(255,197,61,.15);color:var(--amber);
       border:1px solid rgba(255,197,61,.4);border-radius:20px;
       padding:3px 12px;font-size:11px;margin-top:14px}
.cast{margin-top:22px}
.cast h3{font-size:11px;color:#8DA2D6;text-transform:uppercase;letter-spacing:1px}
.cast .row{display:flex;gap:8px;margin-top:10px;flex-wrap:wrap}
.cast img{width:50px;background:#fff;border-radius:12px;padding:3px;
          border:1px solid #2A3E74}
.legend{font-size:11px;color:#9FB0D8;line-height:1.9;margin-top:8px}
.dot{display:inline-block;width:10px;height:10px;border-radius:50%;margin-right:6px}
main{flex:1;padding:24px 30px;max-width:1080px}
h2{font-size:17px;margin-bottom:2px}
.step{display:inline-block;background:var(--navy);color:#fff;border-radius:50%;
      width:24px;height:24px;text-align:center;line-height:24px;font-size:13px;
      margin-right:8px;font-weight:700}
.sub{color:var(--dim);font-size:13px;margin-bottom:14px}
.card{background:var(--card);border:1px solid #E4E7F0;border-radius:16px;
      padding:20px;margin-bottom:16px;box-shadow:0 1px 3px rgba(18,39,90,.06)}
label{font-size:12px;color:var(--dim);font-weight:600;display:block;margin-bottom:6px}
input,select,textarea{width:100%;padding:11px 14px;border:1.5px solid #D9DEEC;
       border-radius:10px;font-size:14px;background:#FBFCFE;color:var(--ink)}
textarea{min-height:150px;resize:vertical;font-family:inherit;line-height:1.5}
input:focus,textarea:focus,select:focus{outline:none;border-color:var(--amber)}
.row{display:flex;gap:12px;flex-wrap:wrap}
.row>div{flex:1;min-width:150px}
button{border:none;border-radius:10px;padding:11px 20px;font-size:14px;font-weight:700;
       cursor:pointer;color:#fff;background:var(--navy);transition:.15s}
button:hover{transform:translateY(-1px)}
button.amber{background:var(--amber);color:var(--ink)}
button.green{background:var(--ok)}
button.red{background:var(--red)}
button:disabled{opacity:.45;cursor:not-allowed;transform:none}
table{width:100%;border-collapse:collapse;font-size:13px;margin-top:12px}
th{color:var(--dim);text-align:left;font-size:11px;text-transform:uppercase;
   letter-spacing:.5px;padding:8px;border-bottom:2px solid #EDEFF6}
td{padding:8px;border-bottom:1px solid #F0F2F8}
.pill{background:#FFF4D6;color:#8A6400;border-radius:6px;padding:2px 8px;
      font-size:11px;font-weight:700}
#log{background:#0E1630;color:#9FE8B0;font:12px/1.55 monospace;border-radius:10px;
     padding:14px;height:170px;overflow-y:auto;white-space:pre-wrap;margin-top:12px}
video{width:100%;border-radius:12px;background:#000;margin-top:10px}
#prev{width:100%;border-radius:12px;border:1px solid #E4E7F0;margin-top:10px;
      background:#fff;min-height:200px}
/* ---- loading / progress ---- */
#panel{display:none;align-items:center;gap:14px;background:#F2F6FF;
       border:1px solid #D8E2FA;border-radius:12px;padding:14px 16px;margin-top:12px}
.spin{width:26px;height:26px;border:4px solid #D8E2FA;border-top-color:var(--navy);
      border-radius:50%;animation:sp 0.9s linear infinite;flex-shrink:0}
@keyframes sp{to{transform:rotate(360deg)}}
.bar{flex:1}
.bar .track{height:12px;background:#DCE4F8;border-radius:8px;overflow:hidden}
.bar .fill{height:100%;width:0%;background:linear-gradient(90deg,var(--navy),#3B5BD6);
           border-radius:8px;transition:width .6s ease}
.bar .txt{font-size:12px;color:#44538E;margin-top:6px;display:flex;
          justify-content:space-between}
.eta{font-weight:800;color:var(--navy)}
.small{font-size:11px;color:var(--dim);margin-top:6px}
.err{color:var(--red);font-weight:700}
.okc{color:var(--ok);font-weight:700}
.done{display:none;align-items:center;gap:8px;margin-top:10px;font-weight:700}
main button:disabled{opacity:.45;cursor:not-allowed}
.uploadbtn{display:inline-flex;align-items:center;gap:8px;padding:10px 16px;border:2px dashed #E8A200;
 border-radius:10px;cursor:pointer;font-weight:800;color:var(--ink);background:#fff4d6;font-size:14px}
.uploadbtn:hover{background:#ffe8a3}
#naskahinfo{font-size:12.5px;color:#5a6b8c}
</style></head><body>
<script>
window.onerror=function(m,src,l){var b=document.getElementById('errbanner');
 if(b){b.style.display='block';b.innerHTML='<b>ADA ERROR SCRIPT:</b> '+m+' (baris '+l+')';}};
window.addEventListener('unhandledrejection',function(e){var b=document.getElementById('errbanner');
 if(b){b.style.display='block';b.innerHTML='<b>ADA ERROR (promise):</b> '+((e.reason&&e.reason.message)||e.reason);}});
</script>
<div id="errbanner" style="display:none;position:fixed;top:0;left:0;right:0;z-index:999;
 background:#C62828;color:#fff;padding:10px 14px;font:13px/1.5 monospace;white-space:pre-wrap"></div>
<aside>
 <h1>SPOT <b>THE SCAM</b></h1>
 <p>Studio Audio-First<br>Naskah &rarr; Suara &rarr; Klip &rarr; Video</p>
 <span class="badge">Suara utama: Andrew</span>
 <span class="badge">GUI v17</span>
 <div class="cast"><h3>Urutan kerja</h3>
  <div class="legend">1. Tulis naskah &rarr; Generate TTS<br>
  2. Scan rencana klip<br>3. Render video &rarr; hasil/final.mp4</div></div>
 <div class="cast"><h3>Casting</h3><div class="row">
  <img src="/api/cast?who=grandma&pose=phone" title="oma (korban)">
  <img src="/api/cast?who=scammer&pose=phone" title="penipu (kacamata hitam)">
  <img src="/api/cast?who=cop&pose=point" title="polisi">
  <img src="/api/cast?who=banker&pose=talk" title="bankir">
 </div>
 <div class="legend">
  <span class="dot" style="background:#78BE8C"></span>korban &nbsp;
  <span class="dot" style="background:#E25A5A"></span>penipu<br>
  <span class="dot" style="background:#5A78C8"></span>polisi/bank &nbsp;
  <span class="dot" style="background:#F0BE46"></span>keluarga
 </div></div>
</aside>
<main>
 <div class="card">
  <h2><span class="step">1</span>Generate Voiceover (TTS)</h2>
  <div class="sub">Tulis/tempel naskah &rarr; suara dipecah otomatis &rarr; wav + SRT klip
   dibuat langsung di folder kerja (tidak perlu pindah-pindah file).</div>
  <textarea id="text" oninput="hitungNaskah()" placeholder="Contoh: Tonight, we are taking apart the grandparent call scam, step by step...&#10;(Tempel naskah episode di sini)"></textarea>
  <div class="row" style="margin-top:10px;align-items:center">
   <label class="uploadbtn">&#128228; Upload Narasi (.txt)
    <input type="file" id="filetxt" accept=".txt,text/plain" style="display:none" onchange="loadTxt(this)">
   </label>
   <span class="small" id="naskahinfo">atau tempel di kotak atas &mdash; estimasi durasi tampil di sini</span>
  </div>
  <div class="row" style="margin-top:12px">
   <div><label>Suara</label><select id="voice">__VOICE_OPTIONS__</select></div>
   <div style="max-width:150px"><label>Tempo</label>
    <select id="rate">
     <option value="-6%">-6% (cepat)</option>
     <option value="-8%" selected>-8% (pas utk 55+)</option>
     <option value="-10%">-10% (santai)</option>
    </select></div>
   <div style="max-width:230px;display:flex;align-items:flex-end">
    <label style="display:flex;gap:8px;align-items:center;cursor:pointer">
     <input type="checkbox" id="clean" checked style="width:auto">
     <span style="color:var(--ink);font-size:13px">Episode baru (bersihkan audio lama)</span>
    </label></div>
  </div>
  <div class="row" style="margin-top:12px">
   <button onclick="doClean()" title="Hapus narasi, audio, SRT, dan video episode sebelumnya">&#129529; Bersihkan File Lama</button>
   <button class="amber" id="btnTts" onclick="doTts()">&#127908; Generate Voiceover</button>
   <span class="small" style="align-self:center" id="ttsinfo"></span>
  </div>
 </div>

 <div class="card">
  <h2><span class="step">2</span>Rencana klip</h2>
  <div class="sub">Pecahan &lt;5 dtk otomatis digabung &rarr; 1 klip. Durasi klip = durasi audio.</div>
  <div class="row">
   <button onclick="doScan()">Scan rencana</button>
  </div>
  <div id="plan"></div>
 </div>

 <div class="card">
  <h2><span class="step">3</span>Render video</h2>
  <div class="sub">Semua klip CC0/karakter digambar &rarr; dipasangkan dgn audio &rarr; concat.</div>
  <div class="row">
   <div style="max-width:130px"><label>FPS</label>
    <select id="fps"><option>10</option><option selected>12</option><option>15</option></select></div>
   <div><label>SRT klip (otomatis dari TTS)</label>
    <input id="srt" value="srt/ep01.srt"></div>
  </div>
  <div class="row" style="margin-top:10px">
   <label style="display:flex;gap:8px;align-items:center;cursor:pointer">
    <input type="checkbox" id="plus" checked style="width:auto">
    <span style="color:var(--ink);font-size:13px">✨ Animasi Plus — mulut sinkron suara,
    kedipan, napas, kamera zoom, fade antar klip (render ±20% lebih lama)</span>
    <label style="display:flex;align-items:center;gap:8px;margin-top:8px">
     <input type="checkbox" id="sfx" checked style="width:auto">
     <span style="color:var(--ink);font-size:13px">🔊 Efek suara halus (ketuk pintu, koin,
     whoosh) &mdash; volume jauh di bawah narator</span></label>
    <label style="display:flex;align-items:center;gap:8px;margin-top:8px">
     <input type="checkbox" id="musik" checked style="width:auto">
     <span style="color:var(--ink);font-size:13px">🎵 Musik latar halus (mood ikut adegan:
     tegang / hangat / lega) &mdash; selalu di bawah suara narator</span></label>
   </label>
  </div>
  <div class="row" style="margin-top:10px;gap:18px;flex-wrap:wrap">
   <div style="min-width:200px;flex:1"><label>&#128266; Volume SFX: <b id="volsfxval">70%</b></label>
    <input type="range" id="volsfx" min="0" max="100" value="70" style="width:100%"
     oninput="document.getElementById('volsfxval').textContent=this.value+'%'"></div>
   <div style="min-width:200px;flex:1"><label>&#127925; Volume Musik: <b id="volmusikval">100%</b></label>
    <input type="range" id="volmusik" min="0" max="100" value="100" style="width:100%"
     oninput="document.getElementById('volmusikval').textContent=this.value+'%'"></div>
   <div style="min-width:200px;flex:1"><label>&#127908; Volume Narator: <b id="volvval">100%</b></label>
    <input type="range" id="volv" min="0" max="100" value="100" style="width:100%"
     oninput="document.getElementById('volvval').textContent=this.value+'%'"></div>
  </div>
  <div class="row" style="margin-top:12px">
   <button class="green" onclick="doBuild()">&#127909; Render video</button>
   <button onclick="doMerge()">Merge audio saja</button>
   <button class="red" onclick="doAll()">Merge + Render (sekali jalan)</button>
  </div>
 </div>

 <div class="card">
  <h2><span class="step">4</span>Thumbnail YouTube</h2>
  <div class="sub">Langsung jadi PNG 1280&times;720 di sini &mdash; atau salin prompt-nya buat AI gambar lain.</div>
  <div class="row">
   <div><label>Motif</label>
    <select id="tmotif" onchange="isiThumb()">
     <option value="phone">phone &mdash; Grandson?</option>
     <option value="giftcard">giftcard</option>
     <option value="bank">bank</option>
     <option value="medicare">medicare</option>
     <option value="crypto">crypto</option>
     <option value="prize">prize</option>
     <option value="check">check</option>
     <option value="custom">custom</option>
    </select></div>
   <div><label>Teks baris 1</label><input id="tl1" maxlength="24"></div>
   <div><label>Teks baris 2</label><input id="tl2" maxlength="24"></div>
   <div style="max-width:130px"><label>Aksen</label>
    <select id="tacc"><option value="">default motif</option><option value="red">merah</option><option value="amber">amber</option></select></div>
  </div>
  <div class="row" style="margin-top:12px">
   <button class="amber" onclick="doThumb()">&#127912; Generate Thumbnail</button>
   <button onclick="buatPrompt()">&#128203; Buat &amp; Salin Prompt AI</button>
   <span class="small" style="align-self:center" id="thumbinfo"></span>
  </div>
  <div id="thumbbox" style="display:none;margin-top:12px">
   <img id="thumbimg" alt="thumbnail" style="width:100%;max-width:480px;border-radius:12px;border:1px solid #e3e6f0">
  </div>
  <textarea id="thumbprompt" rows="6" readonly style="display:none;margin-top:10px;width:100%;
   font:12px/1.5 monospace;border:1px solid #e3e6f0;border-radius:10px;padding:10px;color:#39456e;background:#FAFBFF"></textarea>
 </div>

 <div class="card">
  <h2>&#9203; Progres &amp; monitor</h2>
  <div id="panel">
   <div class="spin"></div>
   <div class="bar">
    <div class="track"><div class="fill" id="fill"></div></div>
    <div class="txt"><span id="plabel">menyiapkan...</span>
     <span>berjalan <b id="elapsed">0:00</b> &middot; sisa &plusmn;<b class="eta" id="eta">--</b></span></div>
   </div>
  </div>
  <div class="done" id="donebox">&#9989; <span id="donetxt">Selesai</span></div>
  <div id="log">menunggu perintah...</div>
  <video id="vid" controls></video>
 </div>

 <div class="card">
  <h2>Pratinjau adegan <span class="small">(instan, tanpa render)</span></h2>
  <img id="prev" src="/api/frame?t=1">
  <input type="range" id="slider" min="0" max="1200" value="100" step="5"
         oninput="prev(this.value/100)">
  <div class="small">t = <b id="tv">1.0</b> dtk &nbsp;|&nbsp; <span id="seginfo"></span></div>
 </div>
</main>
<script>
const $=id=>document.getElementById(id);
let DEF={}, polling=false, lastDone=0, curPhase='';

(async()=>{
  try{
    const v=await (await fetch('/api/voices')).json();
    if(v.voices&&v.voices.length)$('voice').innerHTML=v.voices.map(x=>`<option value="${x.id}">${x.label}</option>`).join('');
  }catch(e){}
  try{
    DEF=await (await fetch('/api/paths')).json();
    $('srt').value='srt/ep01.srt';
  }catch(e){}
  try{isiThumb()}catch(e){}
  prev(1.0); poll();
})();

function fmt(s){s=Math.max(0,Math.round(s));return Math.floor(s/60)+':'+String(s%60).padStart(2,'0')}

function setBusy(b,label){
  ['btnTts'].forEach(id=>$(id).disabled=b);
  document.querySelectorAll('main button').forEach(x=>{if(x.id!=='btnTts')x.disabled=b});
  $('panel').style.display=b?'flex':'none';
  $('donebox').style.display='none';
  if(b)$('plabel').textContent=label||'memproses...';
}

function hitungNaskah(){
  const t=$('text').value.trim();
  if(!t){$('naskahinfo').textContent='atau tempel di kotak atas \u2014 estimasi durasi tampil di sini';return}
  const w=t.split(/\\s+/).filter(Boolean).length;
  const par=t.split(/---|\\n\\s*\\n/).filter(x=>x.trim()).length||1;
  const men=w/145;
  let ekstra=men<10?' <span style="color:#b26a00">(kurang \u00b1'+Math.ceil((10-men)*145)+' kata utk 10 mnt)</span>'
            :men>13.5?' <span style="color:#b26a00">(agak panjang \u2014 pertimbangkan dipangkas)</span>':' \u2714';
  $('naskahinfo').innerHTML='<b>'+w+'</b> kata &middot; <b>'+par+'</b> adegan &middot; estimasi <b>\u00b1'+men.toFixed(1)+' menit</b>'+ekstra;
}
function loadTxt(inp){
  const f=inp.files&&inp.files[0];if(!f)return;
  const rd=new FileReader();
  rd.onload=e=>{$('text').value=e.target.result;hitungNaskah();$('ttsinfo').textContent='📄 '+f.name+' termuat \u2014 siap di-Generate';};
  rd.readAsText(f);inp.value='';
}
const TMOTIF={phone:['GRANDSON?','NOT HIM.'],giftcard:['GIFT CARDS','= SCAM'],bank:['THE BANK','NEVER ASKS'],
medicare:["FREE BRACE?","IT'S A TRAP"],crypto:['CRYPTO','LIE'],prize:['YOU WON!',"YOU DIDN'T"],
check:['REAL CHECK?','FAKE'],custom:['LINE 1','LINE 2']};
function isiThumb(){const m=TMOTIF[$('tmotif').value]||TMOTIF.custom;$('tl1').value=m[0];$('tl2').value=m[1];}
async function doThumb(){
  $('thumbinfo').textContent='menggambar...';
  const r=await fetch('/api/thumb',{method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({motif:$('tmotif').value,l1:$('tl1').value,l2:$('tl2').value,accent:$('tacc').value})});
  const j=await r.json();
  if(j.error){$('thumbinfo').textContent=j.error;return}
  $('thumbbox').style.display='block';
  $('thumbimg').src='/api/thumbimg?t='+Date.now();
  $('thumbinfo').textContent='Tersimpan: hasil/thumb.png';
}
function salin(el,info){
  el.removeAttribute('readonly');el.select();
  const done=()=>{el.setAttribute('readonly','');$(info).textContent='Prompt tersalin \u2014 tempel di AI gambar (Bing/ImageFX/dll)';};
  if(navigator.clipboard&&navigator.clipboard.writeText){navigator.clipboard.writeText(el.value).then(done).catch(()=>{document.execCommand('copy');done()});}
  else{document.execCommand('copy');done();}
}
function buatPrompt(){
  const m=$('tmotif').value;
  const objmap={phone:'a ringing smartphone with amber call waves',
    giftcard:'a red gift card',bank:'a red bank card',medicare:'a red Medicare card',
    crypto:'a big gold dollar coin',prize:'a big gold prize coin',
    check:'a paper cheque with an amount written on it',custom:'a ringing smartphone'};
  const acc=(($('tacc').value||'red')==='red')?'red':'yellow/amber';
  const p=['Flat vector YouTube thumbnail, 1280x720, stickman explainer style, hand-drawn cartoon look.',
   'RIGHT SIDE (40% of frame): a shocked elderly stickman woman - grey hair bun, round glasses, mouth open in an O, both hands raised - with an amber halo ring behind her head.',
   'LEFT SIDE: huge ultra-bold text "'+$('tl1').value+'" in white, and below it "'+$('tl2').value+'" in '+acc+', thick dark outline, Montserrat style letters.',
   'BOTTOM RIGHT: '+(objmap[m]||objmap.phone)+' highlighted inside a thick red circle.',
   'BACKGROUND: dark navy blue with a soft dark vignette and subtle dots, high contrast, readable on a small phone screen. No other text.'];
  const ta=$('thumbprompt');ta.style.display='block';ta.value=p.join(String.fromCharCode(10));
  salin(ta,'thumbinfo');
}
async function doClean(){
  if(!confirm('Bersihkan file episode lama?\\n\\nYang dihapus: narasi, audio, SRT, transkrip, work, video hasil. Program & aset TIDAK ikut terhapus.'))return;
  const r=await fetch('/api/clean',{method:'POST'});
  const j=await r.json().catch(()=>({error:'Server membalas aneh'}));
  if(j.error){$('ttsinfo').textContent='\u26a0\ufe0f '+j.error;return}
  $('text').value='';$('plan').innerHTML='';$('vid').removeAttribute('src');$('vid').load();
  hitungNaskah();
  $('ttsinfo').textContent='🧹 '+j.files+' file lama terhapus ('+j.mb+' MB) \u2014 siap utk episode baru';
}
async function doTts(){
  const t=$('text').value.trim();
  if(t.length<20){alert('Naskah terlalu pendek (min 20 karakter)');return}
  const r=await fetch('/api/tts',{method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({text:t,voice:$('voice').value,rate:$('rate').value,clean:$('clean').checked})});
  const j=await r.json().catch(()=>({error:'Server membalas aneh — cek LOG'}));
  if(j.error){$('ttsinfo').textContent='\u26a0\ufe0f '+j.error;return}
  if(!j.started){$('ttsinfo').textContent='Masih ada proses berjalan \u2014 tunggu selesai dulu';return}
  setBusy(true,'TTS: menukem suara (chunk 1 = klip 1)...'); curPhase='TTS';
}
async function doScan(){
  $('plan').innerHTML='<i>memindai...</i>';
  const srt=$('srt').value.trim();
  const r=await fetch(`/api/scan?srt=${encodeURIComponent(srt)}`);
  const j=await r.json();
  if(j.error){$('plan').innerHTML='<span class="err">'+j.error+'</span>';return}
  if(!j.plan||!j.plan.length){$('plan').innerHTML='<span class="err">audio_in kosong — jalankan langkah 1 dulu</span>';return}
  let h='<table><tr><th>#</th><th>Durasi</th><th>Status</th><th>Isi segmen</th></tr>';
  j.plan.forEach(s=>{h+=`<tr><td>${s.no}</td><td><b>${s.dur.toFixed(1)} dtk</b></td>
   <td>${s.parts.length>1?'<span class="pill">gabung '+s.parts.length+'</span>':'<span class="pill">tunggal</span>'}</td>
   <td>${s.parts.length} wav &middot; "${s.text||''}"</td></tr>`});
  $('plan').innerHTML=h+'</table>';
}
async function post(url,d){
  $('ttsinfo').textContent='Mengirim perintah...';
  try{
    const r=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify(d)});
    let j;
    try{ j=await r.json(); }
    catch(e){ j={error:'Server membalas aneh (HTTP '+r.status+') — cek LOG di bawah'}; }
    if(j.error)$('ttsinfo').textContent='\u26a0\ufe0f '+j.error;
    return j;
  }catch(e){
    const m='Koneksi ke studio gagal: '+e;
    $('ttsinfo').textContent='\u26a0\ufe0f '+m;
    return {error:m};
  }
}
const doBuild=()=>post('/api/build',{fps:$('fps').value,srt:$('srt').value.trim()||null,plus:(document.getElementById('plus')||{checked:true}).checked,sfx:(document.getElementById('sfx')||{checked:true}).checked,musik:(document.getElementById('musik')||{checked:true}).checked,musikvol:(+((document.getElementById('volmusik')||{value:100}).value))/100,sfxvol:(+((document.getElementById('volsfx')||{value:70}).value))/100,vovol:(+((document.getElementById('volv')||{value:100}).value))/100}).then(j=>{if(j.started){setBusy(true,'Render klip...');curPhase='Render'}else{$('ttsinfo').textContent=j.error||'Tidak bisa mulai \u2014 lengkapi Langkah 1 dulu';}});
const doMerge=()=>post('/api/merge',{srt:$('srt').value.trim()||null}).then(j=>{if(j.started){setBusy(true,'Merge audio...');curPhase='Merge'}else{$('ttsinfo').textContent=j.error||'Tidak bisa mulai \u2014 lengkapi Langkah 1 dulu';}});
const doAll  =()=>post('/api/all',{fps:$('fps').value,srt:$('srt').value.trim()||null,plus:(document.getElementById('plus')||{checked:true}).checked,sfx:(document.getElementById('sfx')||{checked:true}).checked,musik:(document.getElementById('musik')||{checked:true}).checked,musikvol:(+((document.getElementById('volmusik')||{value:100}).value))/100,sfxvol:(+((document.getElementById('volsfx')||{value:70}).value))/100,vovol:(+((document.getElementById('volv')||{value:100}).value))/100}).then(j=>{if(j.started){setBusy(true,'Merge + Render...');curPhase='Merge+Render'}else{$('ttsinfo').textContent=j.error||'Tidak bisa mulai \u2014 lengkapi Langkah 1 dulu';}});

async function poll(){
  if(polling)return; polling=true;
  try{
    const j=await (await fetch('/api/status')).json();
    if(j.log)$('log').textContent=j.log, $('log').scrollTop=1e9;
    if(j.running){
      $('panel').style.display='flex'; $('donebox').style.display='none';
      const pct=j.total?Math.round(j.done/j.total*100):0;
      $('fill').style.width=pct+'%';
      $('plabel').textContent=`${j.phase} — ${j.done||0}/${j.total||'?'} bagian (${pct}%)`;
      $('elapsed').textContent=fmt(j.elapsed||0);
      $('eta').textContent=j.eta!=null?fmt(j.eta):'menghitung...';
      document.querySelectorAll('main button').forEach(x=>x.disabled=true);
    }else{
      document.querySelectorAll('main button').forEach(x=>x.disabled=false);
      if(lastRunning){          // baru selesai
        $('panel').style.display='none';
        const gagal=/Traceback|GAGAL|error|Error|not found|No such/i.test(j.log||'');
        $('donebox').style.display='flex';
        if(!j.final && curPhase && curPhase.indexOf('TTS')<0){
          $('donetxt').textContent='\u26a0\ufe0f '+(curPhase)+' berhenti TANPA video'
            +(gagal?' — ADA ERROR: baca LOG hitam di bawah ini!':' — baca LOG di bawah');
          $('donetxt').style.color=gagal?'#C62828':'';
        }else{
          $('donetxt').style.color='';
          $('donetxt').textContent=(curPhase||'Proses')+' selesai!'+
            (j.final?' Video: hasil/final.mp4':(curPhase.indexOf('TTS')>=0?(j.srt_ok?'Audio+SRT siap — lanjut langkah 2 & 3':'TTS selesai TAPI audio/SRT kosong — CEK INTERNET (edge-tts butuh online) lalu ulangi Langkah 1'):'Selesai'));
        }
        if(curPhase==='TTS Voiceover'){doScan()}
        if(j.final)$('vid').src='/api/video?p='+encodeURIComponent(j.final_path)+'&_='+Date.now();
      }
    }
    lastRunning=j.running;
  }finally{polling=false; setTimeout(poll,1500)}
}
let lastRunning=false;

async function prev(t){
  $('tv').textContent=t.toFixed(1);
  $('prev').src=`/api/frame?t=${t}&_=${Date.now()}`;
  const p=await (await fetch('/api/plan?out='+encodeURIComponent(DEF.work||''))).json();
  if(p.segments&&p.segments.length){
    let acc=0,seg=p.segments[p.segments.length-1];
    for(const s of p.segments){if(t<acc+s.dur){seg=s;break} acc+=s.dur}
    $('seginfo').textContent=`segmen #${seg.no} (${seg.dur.toFixed(1)} dtk) — "${(seg.text||'').slice(0,60)}"`;
  } else $('seginfo').textContent='belum ada data — jalankan langkah 1 & 3';
}
</script>
</body></html>"""

@app.get('/')
def index():
    opts = ''.join(f'<option value="{v}">{l}</option>' for v, l in VOICES)
    html = PAGE.replace('__VOICE_OPTIONS__', opts)
    return Response(html, mimetype='text/html',
                    headers={'Cache-Control': 'no-store'})

def _port_bebas(port):
    import socket
    t = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    t.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    try:
        t.bind(('0.0.0.0', port)); t.close(); return True
    except OSError:
        return False

def _bunuh_studio_lama():
    """Matikan SEMUA proses a2studio.py lain (kecuali diri sendiri).
    Penyebab 'Address already in use': server lama masih hidup di background
    walau jendela/tab sudah ditutup."""
    saya = os.getpid()
    korban = []
    try:
        for d in os.listdir('/proc'):
            if not d.isdigit():
                continue
            pid = int(d)
            if pid == saya:
                continue
            try:
                argv = [x for x in open('/proc/%d/cmdline' % pid, 'rb')
                        .read().decode('utf-8', 'replace').split('\0') if x]
            except Exception:
                continue
            # HANYA proses server asli: python .../a2studio.py (bukan shell/editor
            # yang kebetulan mengetik kata a2studio.py di argumennya)
            if len(argv) >= 2 and argv[1].split('/')[-1] == 'a2studio.py':
                korban.append(pid)
    except Exception:
        pass
    for pid in korban:
        try:
            os.kill(pid, 15)
        except Exception:
            pass
    return len(korban)

if __name__ == '__main__':
    import argparse, threading, shutil, time
    ap = argparse.ArgumentParser()
    ap.add_argument('--port', type=int, default=8808)
    ap.add_argument('--host', default='0.0.0.0')
    a = ap.parse_args()

    if not _port_bebas(a.port):
        n = _bunuh_studio_lama()
        time.sleep(1.5)
        if not _port_bebas(a.port):
            for p in range(a.port + 1, a.port + 11):
                if _port_bebas(p):
                    print('  !! Port %d masih dipakai program lain -> pindah ke port %d' % (a.port, p))
                    a.port = p
                    break
            else:
                print('  !! Semua port sibuk. Matikan manual lalu ulangi:  pkill -f a2studio.py')
                sys.exit(1)
        else:
            print('  ✔ Studio lama yang masih hidup dimatikan otomatis (%d proses) — port %d bebas.' % (n, a.port))

    def popup_browser():
        """Munculkan JENDELA APLIKASI otomatis (mode --app: tanpa address bar)."""
        if os.environ.get('A2_NO_BROWSER'):
            return
        if not os.environ.get('DISPLAY') and sys.platform != 'darwin':
            print(f'  (tanpa layar X11 — buka manual: http://localhost:{a.port})')
            return
        url = f'http://localhost:{a.port}'
        time.sleep(1.2)                       # beri waktu server siap
        for name, extra in (('chromium', ['--app=' + url, '--start-maximized']),
                            ('chromium-browser', ['--app=' + url, '--start-maximized']),
                            ('google-chrome', ['--app=' + url, '--start-maximized']),
                            ('firefox', ['--new-window', url])):
            exe = shutil.which(name)
            if exe:
                try:
                    subprocess.Popen([exe] + extra,
                                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                    print(f'  🪟 Jendela aplikasi terbuka via {name} — {url}')
                    return
                except Exception:
                    continue
        try:
            subprocess.Popen(['xdg-open', url],
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            print(f'  🪟 Browser terbuka via xdg-open — {url}')
        except Exception:
            print(f'  Buka manual di browser: {url}')

    threading.Thread(target=popup_browser, daemon=True).start()
    print(f'A2 Studio v5 -> http://localhost:{a.port}')
    app.run(host=a.host, port=a.port, debug=False)
