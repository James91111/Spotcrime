#!/bin/bash
# SPOT THE SCAM Studio — launcher 1-klik (auto-pasang komponen + buka jendela)
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export PYTHONUNBUFFERED=1
exec python3 "$DIR/studio.py"
