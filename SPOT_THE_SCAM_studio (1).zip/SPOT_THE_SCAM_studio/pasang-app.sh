#!/bin/bash
# Pemasang ikon aplikasi: klik ikon -> jendela studio langsung nongol.
# Jalankan SEKALI saja dari dalam folder studio:  bash pasang-app.sh
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
chmod +x "$DIR/studio-app.sh"

sed "s|@DIR@|$DIR|g" "$DIR/SPOT-THE-SCAM.desktop.in" > "$DIR/SPOT-THE-SCAM.desktop"
chmod +x "$DIR/SPOT-THE-SCAM.desktop"

# 1) ikon di desktop (XFCE/LXDE dst)
for d in "$HOME/Desktop" "$HOME/xdg/Desktop"; do
  [ -d "$d" ] && cp "$DIR/SPOT-THE-SCAM.desktop" "$d/" && echo "OK  ikon desktop -> $d"
done
# 2) masuk menu aplikasi sistem
mkdir -p "$HOME/.local/share/applications"
cp "$DIR/SPOT-THE-SCAM.desktop" "$HOME/.local/share/applications/"
echo "OK  menu aplikasi -> ~/.local/share/applications/Spot The Scam Studio"
echo
echo "Selesai! Cek desktop / menu aplikasi: 'Spot The Scam Studio'."
echo "Klik ikonnya -> jendela studio muncul seperti aplikasi biasa."
