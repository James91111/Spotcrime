#!/usr/bin/env python3
# ============================================================
#  FURNIGEN — pabrik furnitur & properti besar (flat, gaya studio)
#  Menghasilkan ratusan PNG ke assets/furnipack/ + manifest.json
#  Jalankan: python furnigen.py            (regenerate semua)
# ============================================================
import os, json, math
from PIL import Image, ImageDraw

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'assets', 'furnipack')
INK = (30, 34, 58)
PAL = {
    'wood':  (166, 124, 82), 'dark': (96, 78, 62), 'red': (196, 74, 64),
    'navy':  (62, 82, 138),  'teal': (84, 148, 140), 'olive': (134, 148, 92),
    'gray':  (150, 156, 170),'cream': (238, 228, 206), 'pink': (222, 168, 158),
    'brown': (128, 92, 64),
}
S = 10  # ketebalan outline

def _cvs(w=360, h=300):
    img = Image.new('RGBA', (w, h), (0, 0, 0, 0))
    return img, ImageDraw.Draw(img)

def _save(img, name):
    img.save(os.path.join(OUT, name + '.png'))

def _o(d, shape, fill, img_w=None, **kw):
    d.shape(shape, fill=fill + (255,), outline=INK + (255,), width=S, **kw)

# ---------------- bentuk dasar (masing2 fungsi dgn warna) ---------
# ---------------- v4.0: rumah sakit, pengadilan, bandara, toko, romansa --------
def bedside(c):
    img, d = _cvs(260, 240)
    d.rectangle([40, 90, 220, 210], fill=c + (255,), outline=INK + (255,), width=S)
    d.rectangle([56, 106, 204, 130], fill=tuple(min(255, x+24) for x in c) + (255,),
                outline=INK + (255,), width=6)
    d.line([40, 170, 220, 170], fill=INK + (255,), width=6)
    d.rectangle([70, 210, 86, 232], fill=INK + (255,))
    d.rectangle([174, 210, 190, 232], fill=INK + (255,))
    d.rectangle([178, 52, 206, 90], fill=(240, 200, 90) + (255,), outline=INK + (255,), width=6)
    d.line([192, 90, 192, 108], fill=INK + (255,), width=6)
    return img

def ivstand(c):
    img, d = _cvs(220, 340)
    d.line([110, 60, 110, 310], fill=INK + (255,), width=10)
    d.line([70, 310, 150, 310], fill=INK + (255,), width=10)
    d.rectangle([76, 40, 144, 96], fill=(214, 232, 244) + (255,), outline=INK + (255,), width=7)
    d.line([76, 78, 144, 78], fill=(214, 84, 78) + (255,), width=10)
    d.line([110, 96, 110, 130], fill=INK + (255,), width=5)
    d.ellipse([96, 130, 124, 158], fill=c + (255,), outline=INK + (255,), width=6)
    return img

def judgebench(c):
    img, d = _cvs(470, 280)
    d.rectangle([30, 80, 440, 130], fill=c + (255,), outline=INK + (255,), width=S)
    d.polygon([(60, 130), (410, 130), (430, 260), (40, 260)], fill=c + (255,),
              outline=INK + (255,))
    d.rectangle([190, 40, 280, 80], fill=(238, 242, 248) + (255,), outline=INK + (255,), width=6)
    d.line([200, 160, 270, 160], fill=INK + (255,), width=6)
    d.ellipse([330, 150, 370, 190], outline=INK + (255,), width=8)
    return img

def witnessbox(c):
    img, d = _cvs(300, 260)
    d.rectangle([40, 90, 260, 130], fill=c + (255,), outline=INK + (255,), width=S)
    for x0 in (40, 130, 220):
        d.rectangle([x0, 130, x0+40, 240], fill=c + (255,), outline=INK + (255,), width=8)
    d.rectangle([70, 40, 230, 90], fill=(238, 242, 248) + (255,), outline=INK + (255,), width=6)
    return img

def depboard(c):
    img, d = _cvs(460, 260)
    d.rectangle([30, 40, 430, 190], fill=(52, 60, 88) + (255,), outline=INK + (255,), width=S)
    for r in range(3):
        y = 66 + r*44
        d.rectangle([56, y, 190, y+26], fill=(150, 200, 170) + (255,))
        d.rectangle([210, y, 290, y+26], fill=(240, 200, 90) + (255,))
        d.rectangle([310, y, 404, y+26], fill=(224, 122, 110) + (255,))
    d.line([150, 190, 120, 250], fill=INK + (255,), width=10)
    d.line([310, 190, 340, 250], fill=INK + (255,), width=10)
    return img

def depseats(c):
    img, d = _cvs(460, 240)
    for k in range(3):
        x0 = 30 + k*145
        d.rectangle([x0, 60, x0+110, 140], fill=c + (255,), outline=INK + (255,), width=S)
        d.rectangle([x0, 140, x0+110, 170], fill=tuple(min(255, x+20) for x in c) + (255,),
                    outline=INK + (255,), width=6)
        d.rectangle([x0+8, 170, x0+26, 220], fill=INK + (255,))
        d.rectangle([x0+84, 170, x0+102, 220], fill=INK + (255,))
    return img

def railing(c):
    img, d = _cvs(440, 200)
    for x0 in (40, 200, 360):
        d.rectangle([x0, 60, x0+24, 180], fill=c + (255,), outline=INK + (255,), width=7)
        d.ellipse([x0-6, 34, x0+30, 64], fill=c + (255,), outline=INK + (255,), width=6)
    for x0 in (52, 212):
        d.line([x0, 84, x0+148, 84], fill=INK + (255,), width=10)
    return img

def reception(c):
    img, d = _cvs(440, 260)
    d.polygon([(60, 90), (380, 90), (410, 240), (30, 240)], fill=c + (255,),
              outline=INK + (255,))
    d.rectangle([40, 66, 400, 96], fill=tuple(min(255, x+24) for x in c) + (255,),
                outline=INK + (255,), width=S)
    d.ellipse([330, 30, 376, 70], fill=(240, 200, 90) + (255,), outline=INK + (255,), width=6)
    d.line([353, 30, 353, 10], fill=INK + (255,), width=5)
    d.line([120, 150, 240, 150], fill=INK + (255,), width=6)
    return img

def shopcounter(c):
    img, d = _cvs(460, 260)
    d.rectangle([30, 100, 430, 150], fill=c + (255,), outline=INK + (255,), width=S)
    d.rectangle([60, 150, 110, 240], fill=c + (255,), outline=INK + (255,), width=8)
    d.rectangle([350, 150, 400, 240], fill=c + (255,), outline=INK + (255,), width=8)
    d.rectangle([300, 44, 396, 100], fill=(52, 60, 88) + (255,), outline=INK + (255,), width=7)
    d.ellipse([326, 58, 356, 88], fill=(120, 200, 140) + (255,), outline=INK + (255,), width=5)
    d.rectangle([70, 60, 150, 100], fill=(238, 242, 248) + (255,), outline=INK + (255,), width=6)
    return img

def shelfgoods(c):
    img, d = _cvs(360, 300)
    for y0 in (60, 140, 220):
        d.rectangle([40, y0, 320, y0+22], fill=c + (255,), outline=INK + (255,), width=7)
        for k in range(4):
            x0 = 58 + k*70
            col = [(224, 122, 110), (240, 200, 90), (120, 150, 200), (134, 186, 130)][(k+y0//80) % 4]
            d.rectangle([x0, y0-42, x0+48, y0], fill=col + (255,), outline=INK + (255,), width=5)
    return img

def heartballoon(c):
    import math as _m
    img, d = _cvs(240, 340)
    pts = []
    for i in range(72):
        t = 2*_m.pi*i/72
        x = 16*(_m.sin(t)**3)
        y = 13*_m.cos(t) - 5*_m.cos(2*t) - 2*_m.cos(3*t) - _m.cos(4*t)
        pts.append((120 + x*5.4, 104 - y*5.4))
    d.polygon(pts, fill=c + (255,))
    d.line(pts + [pts[0]], fill=INK + (255,), width=S, joint='curve')
    d.polygon([(106, 196), (134, 196), (120, 214)], fill=INK + (255,))
    d.arc([70, 200, 170, 330], 300, 25, fill=INK + (255,), width=5)
    return img

def flowerstand(c):
    img, d = _cvs(300, 280)
    d.rectangle([60, 120, 240, 150], fill=c + (255,), outline=INK + (255,), width=S)
    d.rectangle([80, 150, 100, 250], fill=c + (255,), outline=INK + (255,), width=7)
    d.rectangle([200, 150, 220, 250], fill=c + (255,), outline=INK + (255,), width=7)
    for x0, col in ((84, (224, 122, 110)), (140, (226, 152, 166)), (196, (240, 200, 90))):
        d.line([x0+14, 120, x0+14, 76], fill=(134, 186, 130) + (255,), width=6)
        d.ellipse([x0-4, 40, x0+34, 78], fill=col + (255,), outline=INK + (255,), width=5)
    return img


def tollbooth(c):
    img, d = _cvs(360, 340)
    d.rectangle([60, 100, 200, 320], fill=c + (255,), outline=INK + (255,), width=S)
    d.rectangle([46, 60, 214, 104], fill=tuple(min(255, x+22) for x in c) + (255,),
                outline=INK + (255,), width=S)
    d.rectangle([88, 150, 172, 190], fill=(200, 226, 244) + (255,), outline=INK + (255,), width=6)
    d.line([200, 130, 330, 130], fill=INK + (255,), width=12)
    d.rectangle([238, 118, 300, 142], fill=(224, 122, 110) + (255,), outline=INK + (255,), width=5)
    return img

def goldcrate(c):
    img, d = _cvs(380, 260)
    d.polygon([(60, 110), (320, 110), (350, 240), (30, 240)], fill=c + (255,),
              outline=INK + (255,))
    d.rectangle([48, 78, 332, 114], fill=tuple(min(255, x+20) for x in c) + (255,),
                outline=INK + (255,), width=S)
    for x in (110, 180, 250):
        d.polygon([(x, 74), (x+18, 44), (x+52, 44), (x+70, 74)],
                  fill=(240, 200, 90) + (255,), outline=INK + (255,))
    d.line([90, 170, 290, 170], fill=INK + (255,), width=6)
    d.line([90, 205, 290, 205], fill=INK + (255,), width=6)
    return img

def desk(c):
    img, d = _cvs(380, 280)
    d.rectangle([30, 110, 350, 138], fill=c + (255,), outline=INK + (255,), width=S)
    d.rectangle([50, 138, 82, 258], fill=c + (255,), outline=INK + (255,), width=S)
    d.rectangle([296, 138, 328, 258], fill=c + (255,), outline=INK + (255,), width=S)
    d.rectangle([100, 150, 270, 236], fill=tuple(min(255, x + 22) for x in c) + (255,),
                outline=INK + (255,), width=S)
    d.line([100, 193, 270, 193], fill=INK + (255,), width=6)
    d.ellipse([172, 180, 196, 204], fill=INK + (255,))
    return img

def roundtable(c):
    img, d = _cvs(360, 280)
    d.ellipse([40, 90, 320, 170], fill=c + (255,), outline=INK + (255,), width=S)
    d.line([180, 160, 180, 250], fill=INK + (255,), width=14)
    d.ellipse([130, 240, 230, 268], fill=c + (255,), outline=INK + (255,), width=S)
    return img

def chair(c):
    img, d = _cvs(260, 300)
    d.rectangle([60, 40, 200, 60], fill=c + (255,), outline=INK + (255,), width=S)
    d.rectangle([60, 40, 84, 190], fill=c + (255,), outline=INK + (255,), width=S)
    d.rectangle([52, 170, 208, 196], fill=c + (255,), outline=INK + (255,), width=S)
    d.rectangle([64, 196, 84, 282], fill=c + (255,), outline=INK + (255,), width=S)
    d.rectangle([176, 196, 196, 282], fill=c + (255,), outline=INK + (255,), width=S)
    return img

def bed(c):
    img, d = _cvs(430, 260)
    d.rectangle([20, 120, 60, 240], fill=c + (255,), outline=INK + (255,), width=S)
    d.rectangle([20, 150, 410, 210], fill=(240, 240, 244) + (255,), outline=INK + (255,), width=S)
    d.rectangle([370, 100, 410, 240], fill=c + (255,), outline=INK + (255,), width=S)
    d.rounded_rectangle([44, 154, 130, 200], 12, fill=(255, 255, 255) + (255,),
                        outline=INK + (255,), width=6)
    d.rectangle([150, 140, 400, 172], fill=c + (255,), outline=INK + (255,), width=6)
    return img

def door(c):
    img, d = _cvs(240, 340)
    d.rectangle([40, 20, 200, 320], fill=c + (255,), outline=INK + (255,), width=S)
    d.rectangle([64, 44, 176, 296], outline=INK + (255,), width=6)
    d.ellipse([160, 164, 182, 186], fill=INK + (255,))
    return img

def window(c):
    img, d = _cvs(300, 240)
    d.rectangle([30, 20, 270, 210], fill=(200, 226, 244) + (255,), outline=INK + (255,), width=S)
    d.line([150, 20, 150, 210], fill=INK + (255,), width=S)
    d.line([30, 115, 270, 115], fill=INK + (255,), width=S)
    d.arc([60, 40, 130, 100], 180, 360, fill=(255, 255, 255) + (255,), width=10)
    return img

def rug(c):
    img, d = _cvs(380, 160)
    d.ellipse([20, 30, 360, 130], fill=c + (255,), outline=INK + (255,), width=S)
    d.ellipse([70, 52, 310, 108], outline=(255, 255, 255) + (255,), width=8)
    return img

def cabinet(c):
    img, d = _cvs(240, 320)
    d.rectangle([40, 30, 200, 300], fill=c + (255,), outline=INK + (255,), width=S)
    for y in (30, 120, 210):
        d.line([40, y, 200, y], fill=INK + (255,), width=6)
        d.ellipse([110, y + 36, 130, y + 56], fill=INK + (255,))
    return img

def tvstand(c):
    img, d = _cvs(420, 300)
    d.rectangle([30, 30, 390, 180], fill=(40, 44, 64) + (255,), outline=INK + (255,), width=S)
    d.rectangle([60, 60, 360, 150], fill=(120, 190, 235) + (255,))
    d.rectangle([80, 200, 340, 280], fill=c + (255,), outline=INK + (255,), width=S)
    return img

def plantbig(c):
    img, d = _cvs(260, 340)
    d.polygon([(80, 150), (180, 150), (200, 320), (60, 320)], fill=c + (255,),
              outline=INK + (255,))
    for ang in (-70, -35, 0, 35, 70):
        x2 = 130 + 95 * math.sin(math.radians(ang))
        y2 = 150 - 110 * abs(math.cos(math.radians(ang))) + 12
        d.line([130, 150, x2, y2], fill=(74, 128, 84) + (255,), width=10)
        d.ellipse([x2 - 26, y2 - 16, x2 + 26, y2 + 16], fill=(108, 168, 112) + (255,),
                  outline=INK + (255,), width=6)
    return img

def moneybag(c):
    img, d = _cvs(280, 300)
    d.polygon([(110, 80), (170, 80), (230, 180), (230, 270), (50, 270), (50, 180)],
              fill=c + (255,), outline=INK + (255,), width=S)
    d.rectangle([110, 56, 170, 92], fill=c + (255,), outline=INK + (255,), width=8)
    d.text((140, 190), '$', font=None if False else __import__('PIL').ImageFont.\
           truetype(os.path.join(os.path.dirname(__file__), '..', 'assets',
                    'fonts', 'Montserrat-900.ttf'), 96),
           fill=INK + (255,), anchor='mm')
    return img

def chart(up=False):
    col = (60, 150, 90) if up else (208, 60, 60)
    img, d = _cvs(340, 300)
    d.line([40, 30, 40, 270], fill=INK + (255,), width=8)
    d.line([40, 270, 310, 270], fill=INK + (255,), width=8)
    pts = [(60, 80), (120, 140), (170, 110), (230, 190), (290, 250)] if not up else \
          [(60, 250), (120, 190), (170, 215), (230, 120), (290, 60)]
    d.line(pts, fill=col + (255,), width=16, joint='curve')
    x0, y0 = pts[-1]
    arr = -40 if not up else 40
    d.polygon([(x0, y0), (x0 - 34, y0 + arr), (x0 - 8, y0 + arr - 6 if not up else y0 + arr + 6)],
              fill=col + (255,), outline=INK + (255,))
    return img

def counter(c):     # meja teller bank
    img, d = _cvs(460, 260)
    d.rectangle([20, 100, 440, 140], fill=c + (255,), outline=INK + (255,), width=S)
    d.rectangle([40, 140, 80, 240], fill=c + (255,), outline=INK + (255,), width=S)
    d.rectangle([380, 140, 420, 240], fill=c + (255,), outline=INK + (255,), width=S)
    d.rectangle([330, 40, 430, 100], fill=(240, 240, 244) + (255,), outline=INK + (255,), width=8)
    d.line([345, 70, 415, 70], fill=INK + (255,), width=6)
    d.line([345, 88, 395, 88], fill=INK + (255,), width=6)
    return img

def hospitalbed(c):
    img, d = _cvs(430, 240)
    d.rectangle([30, 130, 400, 165], fill=(238, 242, 248) + (255,), outline=INK + (255,), width=S)
    d.rectangle([36, 60, 52, 130], fill=c + (255,), outline=INK + (255,), width=S)
    d.line([60, 165, 60, 225], fill=INK + (255,), width=12)
    d.line([370, 165, 370, 225], fill=INK + (255,), width=12)
    d.ellipse([120, 92, 170, 138], fill=(255, 255, 255) + (255,), outline=INK + (255,), width=6)
    return img

def courtbench(c):
    img, d = _cvs(460, 260)
    for x0 in (20, 160, 300):
        d.rectangle([x0, 90, x0 + 140, 130], fill=c + (255,), outline=INK + (255,), width=S)
        d.rectangle([x0 + 20, 130, x0 + 50, 230], fill=c + (255,), outline=INK + (255,), width=S)
        d.rectangle([x0 + 110, 130, x0 + 140, 230], fill=c + (255,), outline=INK + (255,), width=S)
    return img

def busstop(c):
    img, d = _cvs(360, 340)
    d.rectangle([30, 40, 330, 70], fill=INK + (255,))
    d.rectangle([50, 70, 90, 300], fill=c + (255,), outline=INK + (255,), width=S)
    d.rectangle([290, 70, 330, 300], fill=c + (255,), outline=INK + (255,), width=S)
    d.rectangle([100, 90, 280, 220], fill=(200, 226, 244) + (255,), outline=INK + (255,), width=8)
    d.rectangle([110, 240, 270, 300], fill=c + (255,), outline=INK + (255,), width=8)
    return img

def atmbox(c):
    img, d = _cvs(240, 320)
    d.rectangle([40, 30, 200, 300], fill=c + (255,), outline=INK + (255,), width=S)
    d.rectangle([64, 60, 176, 130], fill=(40, 44, 64) + (255,), outline=INK + (255,), width=6)
    d.rectangle([64, 150, 176, 200], fill=(240, 240, 244) + (255,), outline=INK + (255,), width=6)
    d.ellipse([100, 210, 140, 250], fill=(120, 200, 140) + (255,), outline=INK + (255,), width=6)
    return img

def safebox(c):
    img, d = _cvs(260, 300)
    d.rectangle([40, 40, 220, 270], fill=c + (255,), outline=INK + (255,), width=S)
    d.ellipse([90, 110, 170, 190], outline=INK + (255,), width=10)
    d.line([130, 110, 130, 190], fill=INK + (255,), width=8)
    d.line([90, 150, 170, 150], fill=INK + (255,), width=8)
    return img

def pulpit(c):
    img, d = _cvs(260, 300)
    d.polygon([(70, 60), (190, 60), (210, 280), (50, 280)], fill=c + (255,),
              outline=INK + (255,))
    d.rectangle([50, 40, 210, 68], fill=c + (255,), outline=INK + (255,), width=S)
    return img

def pc_desk(c):
    img = desk(c)
    d = ImageDraw.Draw(img)
    d.rectangle([150, 40, 260, 106], fill=(40, 44, 64) + (255,), outline=INK + (255,), width=8)
    d.rectangle([160, 50, 250, 96], fill=(130, 195, 235) + (255,))
    return img

def gate(c):
    img, d = _cvs(420, 320)
    d.rectangle([20, 50, 60, 300], fill=c + (255,), outline=INK + (255,), width=S)
    d.rectangle([360, 50, 400, 300], fill=c + (255,), outline=INK + (255,), width=S)
    d.arc([60, 40, 360, 220], 180, 360, fill=INK + (255,), width=S)
    for x in range(80, 340, 40):
        d.line([x, 90 + (abs(200 - x) // 6), x, 280], fill=INK + (255,), width=10)
    return img

def carside(c):
    img, d = _cvs(460, 240)
    d.rounded_rectangle([30, 90, 430, 190], 30, fill=c + (255,), outline=INK + (255,), width=S)
    d.polygon([(120, 92), (180, 40), (320, 40), (360, 92)], fill=c + (255,),
              outline=INK + (255,))
    d.ellipse([90, 160, 160, 230], fill=(50, 54, 70) + (255,), outline=INK + (255,), width=S)
    d.ellipse([300, 160, 370, 230], fill=(50, 54, 70) + (255,), outline=INK + (255,), width=S)
    d.rectangle([380, 120, 424, 140], fill=(255, 220, 120) + (255,), outline=INK + (255,), width=5)
    return img

def dronequad(c):
    img, d = _cvs(320, 180)
    d.rounded_rectangle([120, 70, 200, 120], 14, fill=(70, 76, 96) + (255,),
                        outline=INK + (255,), width=S)
    d.line([120, 80, 50, 50], fill=INK + (255,), width=10)
    d.line([200, 80, 270, 50], fill=INK + (255,), width=10)
    d.line([120, 112, 50, 140], fill=INK + (255,), width=10)
    d.line([200, 112, 270, 140], fill=INK + (255,), width=10)
    for x, y in ((50, 50), (270, 50), (50, 140), (270, 140)):
        d.ellipse([x - 26, y - 9, x + 26, y + 9], fill=(150, 156, 172) + (255,),
                  outline=INK + (255,), width=6)
    d.ellipse([146, 112, 174, 140], fill=(226, 54, 54) + (255,), outline=INK + (255,), width=6)
    return img

def phonebooth(c):
    img, d = _cvs(220, 340)
    d.rectangle([40, 30, 180, 320], fill=c + (255,), outline=INK + (255,), width=S)
    d.rectangle([60, 60, 160, 200], fill=(190, 226, 244) + (255,), outline=INK + (255,), width=8)
    d.rectangle([70, 230, 150, 290], fill=(40, 44, 64) + (255,), outline=INK + (255,), width=6)
    return img

def mailboxbig(c):
    img, d = _cvs(260, 320)
    d.rounded_rectangle([40, 60, 220, 170], 26, fill=c + (255,), outline=INK + (255,), width=S)
    d.rectangle([120, 170, 140, 290], fill=(96, 78, 62) + (255,), outline=INK + (255,), width=S)
    d.rectangle([70, 95, 190, 110], fill=(96, 78, 62) + (255,), outline=INK + (255,), width=5)
    return img

def streetlamp(c):
    img, d = _cvs(240, 360)
    d.line([120, 60, 120, 330], fill=INK + (255,), width=14)
    d.arc([40, 40, 200, 160], 180, 300, fill=INK + (255,), width=14)
    d.ellipse([40, 130, 84, 168], fill=(255, 214, 110) + (255,), outline=INK + (255,), width=8)
    return img

def trashdumpster(c):
    img, d = _cvs(340, 260)
    d.polygon([(40, 90), (300, 90), (280, 240), (60, 240)], fill=c + (255,),
              outline=INK + (255,))
    d.rectangle([30, 60, 310, 96], fill=c + (255,), outline=INK + (255,), width=S)
    d.line([110, 110, 110, 220], fill=INK + (255,), width=6)
    d.line([170, 110, 170, 220], fill=INK + (255,), width=6)
    d.line([230, 110, 230, 220], fill=INK + (255,), width=6)
    return img

# ---------------- rakit varian & simpan ---------------------------
ITEMS = [
    # (fungsi, nama_dasar, palet varian, tags)
    (desk,        'desk',        ['wood', 'dark', 'navy', 'teal', 'olive', 'gray'], ['indoor', 'office', 'bank', 'police']),
    (roundtable,  'roundtable',  ['wood', 'cream', 'teal', 'red'],                  ['indoor', 'home']),
    (chair,       'chair',       ['wood', 'dark', 'navy', 'red', 'teal', 'olive'],  ['indoor', 'office', 'home']),
    (bed,         'bed',         ['wood', 'navy', 'pink', 'teal'],                  ['indoor', 'home']),
    (door,        'door',        ['wood', 'dark', 'gray', 'cream'],                 ['indoor', 'home', 'police']),
    (window,      'window',      ['wood', 'gray', 'cream'],                         ['indoor', 'home']),
    (rug,         'rug',         ['red', 'navy', 'teal', 'olive', 'pink'],          ['indoor', 'home']),
    (cabinet,     'cabinet',     ['gray', 'dark', 'navy', 'cream'],                 ['indoor', 'office', 'police']),
    (tvstand,     'tvstand',     ['dark', 'wood', 'gray'],                          ['indoor', 'home']),
    (plantbig,    'plantbig',    ['red', 'teal', 'cream', 'olive'],                 ['indoor', 'home', 'bank']),
    (moneybag,    'moneybag',    ['cream', 'olive'],                                ['money']),
    (counter,     'counter',     ['wood', 'navy', 'gray'],                          ['bank', 'indoor']),
    (hospitalbed, 'hospitalbed', ['gray', 'teal'],                                  ['hospital', 'indoor']),
    (courtbench,  'courtbench',  ['wood', 'dark'],                                  ['police', 'indoor']),
    (busstop,     'busstop',     ['navy', 'teal', 'red'],                           ['outdoor', 'street']),
    (atmbox,      'atmbox',      ['navy', 'gray', 'teal'],                          ['money', 'street', 'outdoor']),
    (safebox,     'safebox',     ['dark', 'gray', 'navy'],                          ['money', 'indoor']),
    (pulpit,      'pulpit',      ['wood', 'dark'],                                  ['police', 'bank', 'indoor']),
    (pc_desk,     'pcdesk',      ['wood', 'dark', 'gray'],                          ['office', 'indoor', 'scam']),
    (gate,        'gate',        ['dark', 'gray', 'navy'],                          ['outdoor', 'police']),
    (carside,     'carside',     ['red', 'navy', 'teal', 'gray'],                   ['outdoor', 'street']),
    (dronequad,   'drone',       ['gray'],                                          ['outdoor', 'police']),
    (phonebooth,  'phonebooth',  ['navy', 'red', 'teal'],                           ['outdoor', 'street']),
    (mailboxbig,  'mailboxbig',  ['navy', 'red', 'olive'],                          ['outdoor', 'street', 'money']),
    (streetlamp,  'streetlamp',  ['gray', 'dark'],                                  ['outdoor', 'street']),
    (trashdumpster, 'dumpster',  ['teal', 'gray', 'olive'],                         ['outdoor', 'street', 'scam']),
    (bedside,     'bedside',     ['gray', 'teal', 'cream'],  ['hospital', 'indoor']),
    (ivstand,     'ivstand',     ['gray', 'teal', 'navy'],   ['hospital', 'indoor']),
    (judgebench,  'judgebench',  ['wood', 'dark', 'brown'],  ['police', 'indoor']),
    (witnessbox,  'witnessbox',  ['wood', 'dark', 'brown'],  ['police', 'indoor']),
    (depboard,    'depboard',    ['navy', 'gray', 'teal'],   ['outdoor', 'street']),
    (depseats,    'depseats',    ['navy', 'teal', 'gray'],   ['outdoor', 'street']),
    (railing,     'railing',     ['gray', 'navy', 'teal'],   ['outdoor', 'street', 'police']),
    (reception,   'reception',   ['wood', 'teal', 'gray'],   ['indoor', 'office', 'hospital']),
    (shopcounter, 'shopcounter', ['wood', 'teal', 'red'],    ['indoor', 'money', 'street']),
    (shelfgoods,  'shelfgoods',  ['wood', 'teal', 'olive'],  ['indoor', 'money']),
    (heartballoon,'heartballoon',['red', 'pink', 'cream'],   ['romance', 'outdoor']),
    (flowerstand, 'flowerstand', ['teal', 'cream', 'olive'], ['romance', 'indoor']),
    (tollbooth,   'tollbooth',   ['navy', 'teal', 'gray'],   ['outdoor', 'street']),
    (goldcrate,   'goldcrate',   ['wood', 'dark', 'brown'],  ['money', 'indoor'])]

def main():
    os.makedirs(OUT, exist_ok=True)
    for f in os.listdir(OUT):
        if f.endswith('.png'):
            os.remove(os.path.join(OUT, f))
    manifest = {}
    n = 0
    for fn, base, pals, tags in ITEMS:
        for p in pals:
            name = f'{base}_{p}'
            _save(fn(PAL[p]), name)
            manifest[name] = dict(tags=tags, label=base)
            n += 1
    # chart selalu spesifik warna
    _save(chart(False), 'chart_down')
    manifest['chart_down'] = dict(tags=['money', 'scam', 'indoor'], label='chart turun')
    _save(chart(True), 'chart_up')
    manifest['chart_up'] = dict(tags=['money', 'recovery', 'indoor'], label='chart naik')
    n += 2
    json.dump(manifest, open(os.path.join(OUT, 'manifest.json'), 'w'), indent=1)
    print(f'FURNIPACK: {n} file -> {os.path.abspath(OUT)}')

if __name__ == '__main__':
    main()
