#!/usr/bin/env python3
# ============================================================
#  STICKGEN — mesin gambar stickman otomatis (offline, instan)
#  Kanvas navy + karakter + props digambar murni dengan kode.
#  Input : scenes.txt  ->  output.png | template [mood=..] [flip]
#  Setup : pkg install python && pip install pillow
#  Pakai : python stickgen.py scenes.txt [folder_output]
#  CATATAN: variabel PHASE (0..1) dipakai stickanim.py utk animasi.
# ============================================================
import os, sys, random, math
from PIL import Image, ImageDraw, ImageFilter

W, H = 1920, 1080
FLOOR = 920
BG    = (11, 29, 63)
BG2   = (8, 22, 50)
DIM   = (32, 52, 94)      # garis properti latar
DIM2  = (24, 42, 80)
WHITE = (240, 246, 255)
SOFT  = (203, 215, 238)
AMBER = (255, 197, 61)
AMBER_L=(255, 216, 158)
NAVY_D=(4, 10, 28)
LW    = 9                 # ketebalan garis tokoh
PHASE = 0.0               # fase animasi 0..1 (diisi stickanim.py)

def pulse():
    """0..1 berdenyut 2x per loop"""
    return (math.sin(PHASE*2*math.pi*2 - math.pi/2) + 1) / 2
def bob(a=3.0):
    """naik-turun halus (napas)"""
    return math.sin(PHASE*2*math.pi) * a
def sway(a=6.0):
    """kiri-kanan halus"""
    return math.sin(PHASE*2*math.pi) * a

# ---------------- util dasar ----------------
def canvas():
    img = Image.new('RGB', (W, H), BG)
    d = ImageDraw.Draw(img)
    for i in range(220):
        a = int(70 * (1 - i / 220))
        d.line([(0, i), (W, i)], fill=(max(BG[0]-a//3,0), max(BG[1]-a//3,0), max(BG[2]-a//3,0)))
    for x in range(50, W, 46):
        for y in range(50, H, 46):
            d.ellipse([x, y, x+2, y+2], fill=(20, 40, 78))
    return img

def glow(img, xy, r, color=AMBER, strength=150, steps=26):
    ov = Image.new('RGBA', img.size, (0,0,0,0))
    od = ImageDraw.Draw(ov)
    x, y = xy
    for i in range(steps, 0, -1):
        rr = r * i / steps
        a  = int(strength * (1 - i/steps)**1.6)
        od.ellipse([x-rr, y-rr, x+rr, y+rr], fill=color+(a,))
    ov = ov.filter(ImageFilter.GaussianBlur(r*0.18))
    return Image.alpha_composite(img.convert('RGBA'), ov).convert('RGB')

def limb(d, pts, w=LW, col=None):
    col = col or WHITE
    d.line(pts, fill=col, width=w, joint='curve')
    for p in (pts[0], pts[-1]):
        d.ellipse([p[0]-w/2, p[1]-w/2, p[0]+w/2, p[1]+w/2], fill=col)

def soft_figure(img, draw_fn):
    halo = Image.new('RGBA', img.size, (0,0,0,0))
    draw_fn(ImageDraw.Draw(halo), w=LW+14, col=(200,215,240,60))
    halo = halo.filter(ImageFilter.GaussianBlur(10))
    img = Image.alpha_composite(img.convert('RGBA'), halo).convert('RGB')
    draw_fn(ImageDraw.Draw(img), w=LW, col=WHITE)
    return img

def grain_vignette(img, grain_amt=13):
    noise = Image.frombytes('L', (W//3, H//3), os.urandom((W//3)*(H//3)))
    noise = noise.resize((W, H)).point(lambda p: grain_amt - abs(p-grain_amt))
    img = Image.blend(img, Image.merge('RGB', [noise]*3), 0.06)
    m = Image.new('L', (W, H), 0)
    ImageDraw.Draw(m).ellipse([-W*0.3, -H*0.3, W*1.3, H*1.3], fill=255)
    m = m.filter(ImageFilter.GaussianBlur(160))
    return Image.composite(img, Image.new('RGB', (W,H), NAVY_D), m)

# ---------------- bagian tokoh ----------------
def head(d, cx, cy, r=44, mood='neutral', glasses=True, bun=True, flip=1, col=WHITE, w=LW):
    d.ellipse([cx-r, cy-r, cx+r, cy+r], outline=col, width=w)
    ex = 14*flip
    d.ellipse([cx-16+ex-4, cy-8, cx-16+ex+4, cy], fill=col)
    d.ellipse([cx+16+ex-4, cy-8, cx+16+ex+4, cy], fill=col)
    if mood in ('worried','scared'):
        d.line([cx-26+ex, cy-22, cx-8+ex, cy-14], fill=col, width=6)
        d.line([cx+8+ex, cy-14, cx+26+ex, cy-22], fill=col, width=6)
        d.arc([cx-14, cy+12, cx+14, cy+34], 200, 340, fill=col, width=6)
    elif mood in ('happy','calm'):
        d.line([cx-26+ex, cy-16, cx-8+ex, cy-20], fill=col, width=6)
        d.line([cx+8+ex, cy-20, cx+26+ex, cy-16], fill=col, width=6)
        d.arc([cx-14, cy+6, cx+14, cy+30], 20, 160, fill=col, width=6)
    else:
        d.line([cx-26+ex, cy-18, cx-8+ex, cy-18], fill=col, width=6)
        d.line([cx+8+ex, cy-18, cx+26+ex, cy-18], fill=col, width=6)
        d.line([cx-10, cy+24, cx+10, cy+24], fill=col, width=6)
    if glasses:
        for gx in (-18, 18):
            d.ellipse([cx+gx-15+ex, cy-16, cx+gx+15+ex, cy+14], outline=col, width=5)
        d.line([cx-3+ex, cy-2, cx+3+ex, cy-2], fill=col, width=5)
    if bun:
        bx = cx + 40*flip
        d.ellipse([bx-20, cy-52, bx+20, cy-12], fill=(13,31,66), outline=col, width=7)

def grandma_standing(d, B, w, col, mood='neutral', flip=1, arm='down', phone=False):
    bx, by = B
    hipy, necky, heady = by-255, by-385, by-440
    limb(d, [(bx-14,hipy), (bx-32, by-130), (bx-40, by)], w)
    limb(d, [(bx+14,hipy), (bx+32, by-130), (bx+40, by)], w)
    d.polygon([(bx-40, hipy+8), (bx+40, hipy+8), (bx+66, necky+18), (bx-66, necky+18)],
              fill=(13,31,66), outline=col)
    d.line([(bx-66, necky+18), (bx-40, hipy+8)], fill=col, width=7)
    d.line([(bx+66, necky+18), (bx+40, hipy+8)], fill=col, width=7)
    d.line([(bx, hipy), (bx, necky)], fill=col, width=w)
    sh = (bx, necky+14)
    if arm == 'phone':
        limb(d, [sh, (bx-72*flip, hipy-70), (bx-40*flip, hipy-120)], w)
        limb(d, [sh, (bx+76*flip, hipy-92), (bx+64*flip, hipy-160)], w)
    elif arm == 'hip':
        limb(d, [sh, (bx-74*flip, hipy-60), (bx-30*flip, hipy-16)], w)
        limb(d, [sh, (bx+76*flip, hipy-80), (bx+56*flip, hipy-14)], w)
    else:
        limb(d, [sh, (bx-70*flip, hipy-52), (bx-64*flip, hipy+58)], w)
        limb(d, [sh, (bx+70*flip, hipy-52), (bx+64*flip, hipy+58)], w)
    head(d, bx, heady, mood=mood, flip=flip)

# ---------------- props ----------------
def floor_line(d, y=FLOOR):
    d.line([(0, y), (W, y)], fill=DIM2, width=4)

def rug(d, cx, y=FLOOR, rw=560):
    d.ellipse([cx-rw, y-26, cx+rw, y+46], outline=DIM2, width=5)
    d.ellipse([cx-rw*0.72, y-12, cx+rw*0.72, y+32], outline=DIM2, width=3)

def frame(d, x, y, w=190, h=140, family=False):
    d.rectangle([x, y, x+w, y+h], outline=DIM, width=6)
    if family:
        cxm, cym = x+w/2, y+h/2
        for i, (fx, fh) in enumerate([(-52,54),(-16,64),(20,50),(50,38)]):
            d.line([(cxm+fx, cym+fh//2), (cxm+fx, cym+30)], fill=DIM, width=5)
            d.ellipse([cxm+fx-9, cym+30-fh*0.55-18, cxm+fx+9, cym+30-fh*0.55], outline=DIM, width=5)

def window_moon(d, x, y, w=300, h=380, warm=False):
    col = (255, 208, 130) if warm else DIM
    d.rectangle([x, y, x+w, y+h], outline=DIM, width=7)
    d.line([(x+w/2, y), (x+w/2, y+h)], fill=DIM, width=5)
    d.line([(x, y+h/2), (x+w, y+h/2)], fill=DIM, width=5)
    mx, my = x+w*0.68, y+h*0.26
    d.ellipse([mx-34, my-34, mx+34, my+34], fill=col)

def floor_lamp(d, x, y=FLOOR):
    d.line([(x, y), (x, y-330)], fill=DIM, width=7)
    d.line([(x-56, y), (x+56, y)], fill=DIM, width=7)
    d.polygon([(x-64, y-330), (x+64, y-330), (x+38, y-412), (x-38, y-412)], outline=DIM, width=6)

def wall_clock(d, x, y, r=52, t='late'):
    d.ellipse([x-r, y-r, x+r, y+r], outline=DIM, width=6)
    a = {'late': -2.2, 'dawn': 5.4}.get(t, -2.2)
    d.line([(x, y), (x+math.cos(a)*r*0.62, y+math.sin(a)*r*0.62)], fill=DIM, width=6)
    d.line([(x, y), (x+r*0.22, y-r*0.55)], fill=DIM, width=5)

def armchair(d, x, y=FLOOR, w=380, h=360):
    d.rounded_rectangle([x-w/2, y-h+40, x+w/2, y], radius=44, outline=DIM, width=8)
    d.rounded_rectangle([x-w/2+18, y-h+70, x+w/2-18, y-120], radius=30, outline=DIM2, width=5)
    d.rounded_rectangle([x-w/2-26, y-190, x-w/2+40, y-40], radius=22, outline=DIM, width=7)
    d.rounded_rectangle([x+w/2-40, y-190, x+w/2+26, y-40], radius=22, outline=DIM, width=7)

def smartphone(d, xy, s=1.0):
    x, y = xy; w, h = 44*s, 78*s
    d.rounded_rectangle([x-w/2, y-h/2, x+w/2, y+h/2], radius=10*s, fill=(10,20,44), outline=WHITE, width=5)
    d.line([(x-10*s, y+h*0.18), (x+10*s, y+h*0.18)], fill=WHITE, width=4)

def cane(d, x, y=FLOOR, lean=0.18):
    top = (x + (y-560)*lean, y-560)
    d.line([(x, y), top], fill=WHITE, width=8)
    d.arc([top[0]-26, top[1]-20, top[0]+26, top[1]+26], 180, 360, fill=WHITE, width=8)

def landline_wall(d, x, y, amber=True):
    d.rounded_rectangle([x-34, y-120, x+34, y+40], radius=12, outline=WHITE, width=7)
    for r in range(2):
        for c in range(3):
            d.rectangle([x-20+c*15, y-96+r*15, x-10+c*15, y-86+r*15], outline=WHITE, width=3)
    d.rounded_rectangle([x-58, y-180, x+16, y-148], radius=14, outline=AMBER if amber else WHITE, width=7)
    d.arc([x-6, y-150, x+52, y-96], 270, 90, fill=AMBER if amber else WHITE, width=6)
    for i in range(8):
        d.arc([x-70, y-40+i*9, x+30, y+10+i*9], 0, 180, fill=DIM, width=3)

def scammer_den(d, x=1180, y=FLOOR, seed=None):
    rng = random.Random(seed)
    d.line([(x-560, y-230), (x+620, y-230)], fill=DIM, width=8)
    d.line([(x-500, y-230), (x-500, y)], fill=DIM, width=8)
    d.line([(x+520, y-230), (x+520, y)], fill=DIM, width=8)
    for i, mx in enumerate((x-330, x-60, x+210)):
        d.rounded_rectangle([mx, y-500, mx+250, y-300], radius=12, outline=(120,150,200), width=6)
        d.rounded_rectangle([mx+14, y-486, mx+236, y-314], radius=6, fill=(24,44,86))
        for li in range(4):
            ln = rng.randint(90, 190)                     # layar "berkedip"
            br = rng.randint(60, 130)
            d.line([(mx+30, y-460+li*32), (mx+30+ln, y-460+li*32)],
                   fill=(br, br+40, br+90), width=5)
        d.line([(mx+125, y-300), (mx+125, y-262)], fill=DIM, width=6)
    for sx, sy in ((x-460, y-280), (x+520, y-275)):
        d.rectangle([sx, sy, sx+34, sy+34], outline=DIM, width=4)
    B = (x-95, y)
    d.rounded_rectangle([B[0]-150, y-560, B[0]+40, y-90], radius=36, outline=DIM2, width=7)
    d.polygon([(B[0]-150, y-105), (B[0]-145, y-330), (B[0]-95, y-420),
               (B[0]-25, y-335), (B[0]-15, y-105)], fill=(5,12,30), outline=(90,110,150))
    d.ellipse([B[0]-145, y-520, B[0]-45, y-420], fill=(5,12,30), outline=(110,130,170))
    d.polygon([(B[0]-165, y-445), (B[0]-95, y-545), (B[0]-20, y-440), (B[0]-60, y-395)], fill=(5,12,30))
    d.arc([B[0]-160, y-515, B[0]-30, y-435], 110, 250, fill=WHITE, width=8)
    d.ellipse([B[0]-165, y-490, B[0]-137, y-462], outline=WHITE, width=7)
    j1, j2 = rng.randint(-7, 7), rng.randint(-7, 7)      # tangan "mengetik"
    d.line([(B[0]-135, y-330), (B[0]-40, y-280), (B[0]+30+j1, y-262)], fill=(90,110,150), width=16)
    d.line([(B[0]-60, y-320), (B[0]+10, y-270), (B[0]+60+j2, y-255)], fill=(90,110,150), width=16)
    d.rounded_rectangle([B[0]-10, y-268, B[0]+180, y-238], radius=8, outline=(120,150,200), width=5)

def young_woman(d, B, w, col, flip=1):
    bx, by = B
    hipy, necky, heady = by-250, by-380, by-435
    limb(d, [(bx-14,hipy), (bx-34, by-128), (bx-42, by)], w)
    limb(d, [(bx+14,hipy), (bx+34, by-128), (bx+42, by)], w)
    d.polygon([(bx-38, hipy+6), (bx+38, hipy+6), (bx+52, necky+16), (bx-52, necky+16)],
              fill=(13,31,66), outline=col)
    d.line([(bx, hipy), (bx, necky)], fill=col, width=w)
    d.arc([bx-52, heady-46, bx+52, heady+90], 60, 120, fill=col, width=10)
    head(d, bx, heady, mood='happy', glasses=False, bun=False, flip=flip)

# ---------------- template adegan (mendukung animasi via PHASE) ----------------
def t_armchair_call(mood='worried', flip=1):
    img = canvas(); d = ImageDraw.Draw(img)
    floor_line(d); rug(d, 820)
    window_moon(d, 1380, 150)
    frame(d, 700, 130, family=True)
    floor_lamp(d, 330)
    armchair(d, 860)
    img = glow(img, (330, FLOOR-380), 240, strength=90)
    dy = bob(3.5); pu = pulse()
    def fig(dd, w, col):
        bx, by = 830, FLOOR + dy
        hipy, necky, heady = by-215, by-370, by-425
        limb(dd, [(bx-6, hipy), (bx+120, by-186), (bx+112, by)], w)
        limb(dd, [(bx-30, hipy+6), (bx+86, by-176), (bx+72, by-6)], w-1)
        dd.polygon([(bx-48, hipy+10), (bx+42, hipy+10), (bx+62, necky+18), (bx-70, necky+18)],
                   fill=(13,31,66), outline=col)
        dd.line([(bx-70, necky+18), (bx-48, hipy+10)], fill=col, width=7)
        dd.line([(bx+62, necky+18), (bx+42, hipy+10)], fill=col, width=7)
        dd.line([(bx-8, hipy), (bx+2, necky)], fill=col, width=w)
        limb(dd, [(bx-2, necky+16), (bx+70, by-260), (bx+96, by-206)], w)
        limb(dd, [(bx+6, necky+20), (bx+92, by-246), (bx+106, by-198)], w)
        smartphone(dd, (bx+104, by-172), 1.05)
        head(dd, bx+10, heady, mood=mood, flip=1)
    img = soft_figure(img, fig)
    img = glow(img, (936, FLOOR-172+dy), 170+45*pu, strength=150+80*pu)
    d = ImageDraw.Draw(img)
    smartphone(d, (936, FLOOR-172+dy), 1.05)
    cane(d, 640, FLOOR, lean=0.10)
    return grain_vignette(img)

def t_scammer_den(**kw):
    img = canvas(); d = ImageDraw.Draw(img)
    floor_line(d)
    frame(d, 260, 160, w=150, h=110)
    scammer_den(d, 1180, seed=int(PHASE*997))
    pu = pulse()
    img = glow(img, (1180, FLOOR-390), 380+60*pu, color=(150,180,235), strength=90+50*pu)
    img = glow(img, (620, FLOOR-360), 200, strength=120)
    d = ImageDraw.Draw(img)
    d.line([(620, FLOOR), (620, FLOOR-330)], fill=DIM, width=7)
    d.polygon([(560, FLOOR-330), (680, FLOOR-330), (650, FLOOR-400), (590, FLOOR-400)], outline=DIM, width=6)
    return grain_vignette(img)

def t_hallway_call(mood='scared', flip=1):
    img = canvas(); d = ImageDraw.Draw(img)
    floor_line(d)
    d.line([(300, 120), (860, 620)], fill=DIM2, width=5)
    d.line([(1620, 120), (1060, 620)], fill=DIM2, width=5)
    d.line([(300, 120), (300, 900)], fill=DIM2, width=5)
    d.line([(1620, 120), (1620, 900)], fill=DIM2, width=5)
    d.rectangle([820, 330, 1100, 640], outline=DIM2, width=5)
    d.rectangle([900, 450, 1000, 640], outline=DIM2, width=4)
    wall_clock(d, 480, 300, t='late')
    cane(d, 1240, FLOOR, lean=0.14)
    dy = bob(3.5); pu = pulse()
    def fig(dd, w, col):
        grandma_standing(dd, (980, FLOOR+dy), w, col, mood=mood, flip=-1, arm='phone')
    img = soft_figure(img, fig)
    img = glow(img, (916, FLOOR-330+dy), 130+40*pu, strength=140+80*pu)
    d = ImageDraw.Draw(img)
    smartphone(d, (916, FLOOR-330+dy), 0.95)
    return grain_vignette(img)

def t_counter_cards(mood='neutral', flip=1):
    img = canvas(); d = ImageDraw.Draw(img)
    floor_line(d); rug(d, 900, rw=480)
    rx, ry = 1240, 180
    d.line([(rx+140, ry+520), (rx+140, ry+40)], fill=DIM, width=8)
    d.line([(rx, ry+40), (rx+280, ry+40)], fill=DIM, width=8)
    for i in range(4):
        hx = rx + 30 + i * 74
        d.line([(hx, ry+40), (hx, ry+64)], fill=DIM, width=4)
        d.rounded_rectangle([hx-26, ry+64, hx+26, ry+180], radius=8, outline=DIM, width=5)
    d.line([(rx+30+3*74, ry+40), (rx+30+3*74, ry+64)], fill=DIM, width=4)
    d.line([(180, 700), (620, 700)], fill=DIM, width=8)
    d.line([(240, 700), (240, FLOOR)], fill=DIM2, width=6)
    d.line([(560, 700), (560, FLOOR)], fill=DIM2, width=6)
    frame(d, 300, 250, w=170, h=120)
    dy = bob(2.5); pu = pulse()
    def fig(dd, w, col):
        bx, by = 900, FLOOR + dy
        grandma_standing(dd, (bx, by), w, col, mood='worried', flip=-1, arm='down')
        sh = (bx, by-371)
        limb(dd, [sh, (bx+90, by-300), (bx+150, by-250)], w)
        dd.rounded_rectangle([bx+140, by-290, bx+226, by-196], radius=10,
                             fill=(46,38,16), outline=AMBER, width=6)
    img = soft_figure(img, fig)
    img = glow(img, (1063, FLOOR-243+dy), 160+50*pu, strength=150+90*pu)
    d = ImageDraw.Draw(img)
    d.rounded_rectangle([1040, FLOOR-290+dy, 1126, FLOOR-196+dy], radius=10,
                        fill=(46,38,16), outline=AMBER, width=6+int(3*pu))
    return grain_vignette(img)

def t_hangup(mood='calm', flip=1):
    img = canvas(); d = ImageDraw.Draw(img)
    floor_line(d); rug(d, 980, rw=500)
    frame(d, 1310, 170, w=220, h=160, family=True)
    d.line([(1620, FLOOR), (1620, FLOOR-300)], fill=DIM, width=7)
    d.line([(1560, FLOOR), (1680, FLOOR)], fill=DIM, width=7)
    d.polygon([(1560, FLOOR-300), (1680, FLOOR-300), (1650, FLOOR-370), (1590, FLOOR-370)],
              outline=DIM, width=6)
    pu = pulse(); dy = bob(2.5)
    img = glow(img, (1620, FLOOR-345), 200+60*pu, strength=110+80*pu)
    landline_wall(d, 420, 560)
    img = glow(img, (420, 400), 150+40*pu, strength=120+60*pu)
    def fig(dd, w, col):
        grandma_standing(dd, (900, FLOOR+dy), w, col, mood='calm', flip=1, arm='hip')
    img = soft_figure(img, fig)
    d = ImageDraw.Draw(img)
    limb(d, [(900, FLOOR-371+dy), (820, FLOOR-300+dy), (700, FLOOR-260+dy), (560, FLOOR-238+dy)], LW)
    d.ellipse([520, FLOOR-262+dy, 580, FLOOR-214+dy], fill=None, outline=WHITE, width=8)
    return grain_vignette(img)

def t_family_hug(mood='happy', flip=1):
    img = canvas(); d = ImageDraw.Draw(img)
    floor_line(d); rug(d, 960)
    window_moon(d, 1330, 140, w=340, h=430, warm=True)
    frame(d, 430, 170, family=True)
    d.rounded_rectangle([1420, FLOOR-190, 1740, FLOOR-160], radius=10, outline=DIM, width=6)
    d.line([(1450, FLOOR-160), (1450, FLOOR)], fill=DIM, width=6)
    d.line([(1710, FLOOR-160), (1710, FLOOR)], fill=DIM, width=6)
    ln = sway(3.0); pu = pulse(); pu2 = (math.sin(PHASE*2*math.pi - math.pi/2)+1)/2
    def fig(dd, w, col):
        bx, by = 880-ln, FLOOR
        hipy, necky, heady = by-255, by-385, by-440
        limb(dd, [(bx-14,hipy), (bx-34, by-128), (bx-44, by)], w)
        limb(dd, [(bx+6, hipy), (bx+26, by-124), (bx+30, by)], w)
        dd.polygon([(bx-40, hipy+8), (bx+34, hipy+8), (bx+58, necky+18), (bx-64, necky+18)],
                   fill=(13,31,66), outline=col)
        dd.line([(bx, hipy), (bx-4, necky)], fill=col, width=w)
        head(dd, bx+14, heady, mood='happy', flip=1)
        cx, cy = 1120+ln, FLOOR
        chipy, cnecky, cheady = cy-250, cy-378, cy-433
        limb(dd, [(cx-6, chipy), (cx-26, cy-126), (cx-36, cy)], w)
        limb(dd, [(cx+18, chipy), (cx+38, cy-124), (cx+46, cy)], w)
        dd.polygon([(cx-38, chipy+6), (cx+40, chipy+6), (cx+54, cnecky+16), (cx-54, cnecky+16)],
                   fill=(13,31,66), outline=col)
        dd.line([(cx-4, chipy), (cx-12, cnecky)], fill=col, width=w)
        head(dd, cx-52, cheady+6, mood='happy', glasses=False, bun=False, flip=-1)
        limb(dd, [(bx-6, necky+18), (bx+90, hipy-120), (cx-40, chipy-110)], w-1)
        limb(dd, [(cx-12, cnecky+16), (cx-120, chipy-130), (bx+50, hipy-140)], w-1)
    img = soft_figure(img, fig)
    img = glow(img, (1580, FLOOR-235), 120+50*pu2, strength=120+70*pu2)
    d = ImageDraw.Draw(img)
    d.rounded_rectangle([1556, FLOOR-282, 1624, FLOOR-190], radius=10,
                        fill=(10,20,44), outline=WHITE, width=5)
    d.ellipse([1574, FLOOR-268, 1606, FLOOR-236], outline=AMBER, width=4)
    d.arc([1570, FLOOR-232, 1610, FLOOR-198], 20, 160, fill=AMBER, width=4)
    return grain_vignette(img)

def t_door_night(mood='worried', flip=1):
    img = canvas(); d = ImageDraw.Draw(img)
    floor_line(d)
    d.rectangle([1150, 160, 1600, FLOOR], outline=DIM, width=8)
    d.ellipse([1520, 560, 1560, 600], fill=AMBER)
    wall_clock(d, 480, 280, t='late')
    frame(d, 620, 200, w=170, h=130)
    dy = bob(2.5)
    def fig(dd, w, col):
        grandma_standing(dd, (760, FLOOR+dy), w, col, mood='worried', flip=1, arm='down')
    img = soft_figure(img, fig)
    sh = Image.new('RGBA', img.size, (0,0,0,0))
    sd = ImageDraw.Draw(sh)
    swx = sway(10)
    sd.polygon([(790+swx, FLOOR-500), (860+swx, FLOOR-470), (1120+swx, FLOOR), (700+swx, FLOOR)],
               fill=(3, 8, 22, 160))
    img = Image.alpha_composite(img.convert('RGBA'), sh).convert('RGB')
    return grain_vignette(img)

def t_tv_alert(mood='worried', flip=1):
    img = canvas(); d = ImageDraw.Draw(img)
    floor_line(d); rug(d, 900, rw=620)
    d.rounded_rectangle([620, 260, 1300, 660], radius=18, fill=(14,30,62), outline=DIM, width=8)
    d.line([(960, 660), (960, 720)], fill=DIM, width=9)
    d.line([(840, 720), (1080, 720)], fill=DIM, width=9)
    pu = pulse(); dy = bob(2.5)
    img = glow(img, (960, 460), 330+70*pu, color=(150,180,235), strength=70+60*pu)
    d = ImageDraw.Draw(img)
    c = tuple(int(v*(0.65+0.35*pu)) for v in AMBER)
    d.polygon([(960, 340), (1090, 570), (830, 570)], outline=c, width=9)
    d.line([(960, 410), (960, 500)], fill=c, width=9)
    d.ellipse([950, 516, 970, 536], fill=c)
    def fig(dd, w, col):
        grandma_standing(dd, (1560, FLOOR+dy), w, col, mood='worried', flip=-1, arm='down')
    img = soft_figure(img, fig)
    return grain_vignette(img)

TEMPLATES = {
    'armchair_call':  t_armchair_call,
    'scammer_den':    t_scammer_den,
    'hallway_call':   t_hallway_call,
    'counter_cards':  t_counter_cards,
    'hangup':         t_hangup,
    'family_hug':     t_family_hug,
    'door_night':     t_door_night,
    'tv_alert':       t_tv_alert,
}

# ---------------- parser instruksi ----------------
def parse_line(line, idx):
    line = line.strip()
    if not line or line.startswith('#'): return None
    out, rest = (line.split('|', 1) + [''])[:2]
    out = out.strip() or f'scene_{idx:02d}.png'
    toks = rest.split()
    tmpl = toks[0] if toks else 'armchair_call'
    kw = {}
    for t in toks[1:]:
        if '=' in t:
            k, v = t.split('=', 1); kw[k] = v
        elif t == 'flip': kw['flip'] = -1
    return out, tmpl, kw

def main():
    src = sys.argv[1] if len(sys.argv) > 1 else 'scenes.txt'
    outdir = sys.argv[2] if len(sys.argv) > 2 else 'output'
    os.makedirs(outdir, exist_ok=True)
    n_ok = 0
    for i, raw in enumerate(open(src, encoding='utf-8'), 1):
        p = parse_line(raw, i)
        if not p: continue
        out, tmpl, kw = p
        if tmpl not in TEMPLATES:
            print(f'[?] template "{tmpl}" tidak ada. Pilihan: {", ".join(TEMPLATES)}')
            continue
        img = TEMPLATES[tmpl](**kw)
        path = os.path.join(outdir, out if out.endswith('.png') else out + '.png')
        img.save(path)
        n_ok += 1
        print(f'[OK] {path}  ({tmpl})')
    print(f'=== {n_ok} adegan digambar. Instan, offline, karakter selalu sama. ===')

if __name__ == '__main__':
    main()
