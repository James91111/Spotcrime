#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
THUMB_GEN — Generator Thumbnail YouTube 1280x720 (SPOT THE SCAM)
Resep dari riset CTR 2026:
  [KANAN] karakter stickman ekspresi SHOCK (pengganti wajah manusia)
  [KIRI]  teks 2-4 kata, putih + 1 kata aksen (merah/amber)
  [BAWAH] objek bukti + LINGKARAN MERAH
  [LATAR] navy gelap + vignette (kontras maksimal di feed HP)

Pakai (di Termux):
  python thumb_gen.py                          -> pakai preset motif default
  python thumb_gen.py --l1 "GRANDSON?" --l2 "NOT HIM." --motif phone --out thumb.png
  python thumb_gen.py --list                   -> lihat semua preset motif

Preset motif = pasangan [teks, objek bukti] per jenis scam (motifs.dat-friendly).
"""
import argparse, math, os, sys
from PIL import Image, ImageDraw, ImageFilter, ImageFont

W, H = 1280, 720
NAVY = (14, 26, 54)
NAVY2 = (24, 42, 84)
WHITE = (255, 255, 255)
RED = (224, 32, 32)
AMBER = (255, 197, 61)

FONT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets", "fonts")

def font(weight=900, size=100):
    for cand in (os.path.join(FONT_DIR, f"Montserrat-{weight}.ttf"),
                 os.path.join(FONT_DIR, f"Montserrat-{weight}.otf")):
        if os.path.exists(cand):
            return ImageFont.truetype(cand, size)
    # fallback: font sistem
    try:
        return ImageFont.truetype("DejaVuSans-Bold.ttf", size)
    except Exception:
        return ImageFont.load_default()

# ---------------------------------------------------------------- presets
PRESETS = {
    # motif: (line1, (line2, warna aksen), objek bukti)
    "phone":    ("GRANDSON?", ("NOT HIM.", RED),      "phone"),
    "giftcard": ("GIFT CARDS", ("= SCAM", RED),       "card"),
    "bank":     ("THE BANK", ("NEVER ASKS", AMBER),   "card"),
    "medicare": ("FREE BRACE?", ("IT'S A TRAP", RED), "card"),
    "crypto":   ("CRYPTO", ("LIE", RED),              "coin"),
    "prize":    ("YOU WON!", ("YOU DIDN'T", RED),     "coin"),
    "check":    ("REAL CHECK?", ("FAKE", RED),        "check"),
    "custom":   ("LINE 1", ("LINE 2", RED),           "phone"),
}

# ---------------------------------------------------------------- background
def bg():
    img = Image.new("RGB", (W, H), NAVY)
    d = ImageDraw.Draw(img)
    # gradasi radial lembut di kanan (di belakang karakter)
    glow = Image.new("L", (W, H), 0)
    gd = ImageDraw.Draw(glow)
    gd.ellipse([640, -140, 1500, 740], fill=70)
    glow = glow.filter(ImageFilter.GaussianBlur(120))
    img = Image.composite(Image.new("RGB", (W, H), NAVY2), img, glow)
    d = ImageDraw.Draw(img)
    # titik-titik halus (tekstur)
    for i in range(90):
        x = (i * 197) % W
        y = (i * 331) % H
        d.ellipse([x, y, x + 3, y + 3], fill=(38, 58, 104))
    # lantai
    d.polygon([(0, H), (W, H), (W, H - 70), (0, H - 130)], fill=(10, 19, 40))
    return img

def vignette(img):
    m = Image.new("L", (W, H), 0)
    md = ImageDraw.Draw(m)
    md.rectangle([60, 50, W - 60, H - 50], fill=255)
    m = m.filter(ImageFilter.GaussianBlur(110))
    dark = Image.new("RGB", (W, H), (4, 8, 18))
    return Image.composite(img, dark, m)

# ---------------------------------------------------------------- karakter shock (kanan)
def draw_grandma(img, cx=880, cy=350, scale=1.0, ring=AMBER):
    """Stickman oma ekspresi shock: mulut O, tangan ke atas, ring peran.
    Proporsi thumbnail: kepala BESAR, badan tebal, semuanya muat 1 frame."""
    d = ImageDraw.Draw(img)
    s = scale
    lw = max(6, int(13 * s))

    # ring peran (halo) di belakang kepala
    hx, hy = cx, cy - int(200 * s)
    rx, ry = int(140 * s), int(48 * s)
    d.ellipse([hx - rx, hy - ry, hx + rx, hy + ry], outline=ring, width=max(6, int(11 * s)))

    # LEHER + BADAN (dress trapesium lebar, tanpa kotak)
    neck_top = (cx, hy + int(62 * s))
    sh_l, sh_r = (cx - int(60 * s), cy - int(115 * s)), (cx + int(60 * s), cy - int(115 * s))
    hip_l, hip_r = (cx - int(155 * s), cy + int(135 * s)), (cx + int(155 * s), cy + int(135 * s))
    d.line([neck_top, (cx, cy - int(100 * s))], fill=(250, 246, 238), width=lw)
    d.polygon([sh_l, sh_r, hip_r, hip_l], fill=(178, 58, 68), outline=(28, 28, 38))
    # garis tengah dress halus
    d.line([(cx, sh_r[1] + int(12 * s)), (cx, hip_r[1] - int(14 * s))],
           fill=(140, 42, 50), width=max(3, int(5 * s)))

    # TANGAN KE ATAS (shock) — dari bahu, melewati sisi kepala
    for sx in (-1, 1):
        a = (cx + sx * int(52 * s), cy - int(100 * s))
        e = (cx + sx * int(165 * s), cy - int(245 * s))
        d.line([a, e], fill=(250, 246, 238), width=lw)
        hr = int(20 * s)
        d.ellipse([e[0] - hr, e[1] - hr, e[0] + hr, e[1] + hr],
                  fill=(250, 246, 238), outline=(28, 28, 38), width=max(4, int(6 * s)))

    # KAKI + sepatu
    for sx in (-1, 1):
        a = (cx + sx * int(70 * s), cy + int(135 * s))
        e = (cx + sx * int(95 * s), cy + int(320 * s))
        d.line([a, e], fill=(250, 246, 238), width=lw)
        d.line([e, (e[0] + sx * int(38 * s), e[1])], fill=(28, 28, 38), width=max(6, int(11 * s)))

    # KEPALA (paling atas, menutupi leher rapi)
    r = int(82 * s)
    d.ellipse([hx - r, hy - r, hx + r, hy + r], fill=(250, 246, 238), outline=(28, 28, 38), width=lw)
    # rambut + bun
    d.pieslice([hx - r, hy - r, hx + r, hy + r], 180, 360, fill=(208, 208, 216))
    br = int(26 * s)
    d.ellipse([hx - br, hy - r - br - int(6 * s), hx + br, hy - r + br - int(6 * s)],
              fill=(208, 208, 216), outline=(28, 28, 38), width=max(4, int(6 * s)))
    # kacamata + MATA KAGET (bulat besar)
    gy = hy - int(6 * s)
    gw = int(30 * s)
    for ex in (hx - int(25 * s), hx + int(25 * s)):
        d.ellipse([ex - gw, gy - gw, ex + gw, gy + gw], outline=(28, 28, 38), width=max(4, int(7 * s)))
    d.line([hx - int(25 * s) + gw, gy, hx + int(25 * s) - gw, gy], fill=(28, 28, 38), width=max(4, int(7 * s)))
    for ex in (hx - int(25 * s), hx + int(25 * s)):
        er = int(10 * s)
        d.ellipse([ex - er, gy - er, ex + er, gy + er], fill=(18, 18, 28))
    # alis terangkat
    for ex in (hx - int(25 * s), hx + int(25 * s)):
        d.line([ex - int(17 * s), gy - int(30 * s), ex + int(17 * s), gy - int(35 * s)],
               fill=(28, 28, 38), width=max(4, int(7 * s)))
    # MULUT O (shock)
    mo = int(22 * s)
    my = hy + int(40 * s)
    d.ellipse([hx - mo, my - mo, hx + mo, my + mo], fill=(96, 22, 27), outline=(28, 28, 38),
              width=max(4, int(6 * s)))


# ---------------------------------------------------------------- objek bukti (bawah)
def draw_object(img, kind, cx, cy, scale=1.0):
    d = ImageDraw.Draw(img)
    lw = max(4, int(8 * scale))
    if kind == "phone":
        w2, h2 = int(60 * scale), int(105 * scale)
        d.rounded_rectangle([cx - w2, cy - h2, cx + w2, cy + h2], radius=int(18 * scale),
                            fill=(240, 240, 245), outline=(25, 25, 35), width=lw)
        d.rectangle([cx - w2 + int(10 * scale), cy - h2 + int(14 * scale),
                     cx + w2 - int(10 * scale), cy + h2 - int(14 * scale)], fill=(120, 180, 255))
        d.text((cx, cy - int(30 * scale)), "SCAM?", font=font(800, int(26 * scale)),
               fill=(200, 40, 40), anchor="mm")
        # gelombang panggilan
        for i, rr in enumerate((int(40 * scale), int(64 * scale), int(88 * scale))):
            d.arc([cx + w2 + int(6 * scale), cy - rr, cx + w2 + int(6 * scale) + 2 * rr, cy + rr],
                  -50, 50, fill=AMBER, width=max(3, int(7 * scale)))
    elif kind == "coin":
        r = int(85 * scale)
        d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=(255, 200, 60), outline=(140, 100, 20), width=lw)
        d.ellipse([cx - r + int(14 * scale), cy - r + int(14 * scale),
                   cx + r - int(14 * scale), cy + r - int(14 * scale)], outline=(140, 100, 20),
                  width=max(3, int(5 * scale)))
        d.text((cx, cy), "$", font=font(900, int(100 * scale)), fill=(140, 100, 20), anchor="mm")
    elif kind == "check":
        w2, h2 = int(120 * scale), int(64 * scale)
        d.rectangle([cx - w2, cy - h2, cx + w2, cy + h2], fill=(248, 248, 245),
                    outline=(25, 25, 35), width=lw)
        d.line([cx - w2 + int(12 * scale), cy - int(20 * scale), cx + int(10 * scale), cy - int(20 * scale)],
               fill=(60, 90, 160), width=max(3, int(5 * scale)))
        d.text((cx + int(22 * scale), cy + int(18 * scale)), "$9,800.00",
               font=font(800, int(24 * scale)), fill=(25, 25, 35), anchor="mm")
        d.line([cx - w2 + int(12 * scale), cy + h2 - int(14 * scale), cx + w2 - int(12 * scale),
                cy + h2 - int(14 * scale)], fill=(150, 150, 160), width=max(2, int(3 * scale)))
    else:  # card (kartu bank / gift card)
        w2, h2 = int(150 * scale), int(95 * scale)
        d.rounded_rectangle([cx - w2, cy - h2, cx + w2, cy + h2], radius=int(14 * scale),
                            fill=(235, 60, 60), outline=(25, 25, 35), width=lw)
        d.rectangle([cx - w2, cy - int(30 * scale), cx + w2, cy - int(6 * scale)], fill=(60, 60, 80))
        d.text((cx - int(120 * scale), cy + int(38 * scale)), "**** 4821",
               font=font(800, int(34 * scale)), fill=(255, 255, 255), anchor="lm")

def red_circle(img, cx, cy, r):
    d = ImageDraw.Draw(img)
    lw = 14
    for k in range(3):  # glow ringan
        d.ellipse([cx - r - k, cy - r - k, cx + r + k, cy + r + k], outline=(255, 60, 60), width=2)
    d.ellipse([cx - r, cy - r, cx + r, cy + r], outline=RED, width=lw)

# ---------------------------------------------------------------- teks kiri
def draw_text(img, l1, l2, accent):
    d = ImageDraw.Draw(img)
    x = 70
    y = 90
    def fit(txt, max_w, start):
        s = start
        while s > 30:
            f = font(900, s)
            bb = d.textbbox((0, 0), txt, font=f)
            if bb[2] - bb[0] <= max_w:
                return f, s
            s -= 4
        return font(900, 30), 30
    f1, s1 = fit(l1, 560, 128)
    d.text((x, y), l1, font=f1, fill=WHITE, anchor="la")
    # outline tebal ala thumbnail
    d.text((x, y), l1, font=f1, fill=WHITE, anchor="la",
           stroke_width=max(4, s1 // 18), stroke_fill=(10, 16, 34))
    y2 = y + s1 + int(s1 * 0.28)
    f2, s2 = fit(l2, 560, 104)
    d.text((x, y2), l2, font=f2, fill=accent, anchor="la",
           stroke_width=max(3, s2 // 18), stroke_fill=(10, 16, 34))
    # garis aksen bawah teks
    d.line([x + 4, y2 + s2 + 26, x + int(s2 * 3.2), y2 + s2 + 26], fill=accent, width=10)

# ---------------------------------------------------------------- utama
def render(l1, l2, accent, obj_kind, out_path, scale=1.0):
    img = bg()
    img = vignette(img)          # vignette dulu, SEMUA elemen di atasnya
    draw_grandma(img, cx=890, cy=345, scale=0.82 * scale)
    # objek bukti + lingkaran merah (kanan-bawah, depan kaki)
    sc_obj = 0.58 if obj_kind == "check" else 0.72
    ox, oy, orr = 1075, 590, 106
    draw_object(img, obj_kind, ox, oy, scale=sc_obj)
    red_circle(img, ox, oy, orr)
    draw_text(img, l1, l2, accent)
    os.makedirs(os.path.dirname(os.path.abspath(out_path)), exist_ok=True)
    img.save(out_path, "PNG")
    return out_path

def main():
    ap = argparse.ArgumentParser(description="Generator thumbnail 1280x720 SPOT THE SCAM")
    ap.add_argument("--l1", help="baris 1 (putih)")
    ap.add_argument("--l2", help="baris 2 (warna aksen)")
    ap.add_argument("--accent", choices=["red", "amber"], default=None)
    ap.add_argument("--motif", choices=sorted(PRESETS.keys()), default=None)
    ap.add_argument("--obj", choices=["phone", "card", "coin", "check"], default=None)
    ap.add_argument("--out", default=os.path.join("hasil", "thumb.png"))
    ap.add_argument("--list", action="store_true", help="tampilkan preset motif")
    a = ap.parse_args()
    if a.list:
        print("Preset motif tersedia:")
        for k, (p1, (p2, c), obj) in PRESETS.items():
            print(f"  {k:9s} -> '{p1}' / '{p2}' [{obj}]")
        return
    if a.motif:
        p1, (p2, c), obj = PRESETS[a.motif]
    else:
        p1, p2, obj = "LINE 1", "LINE 2", "phone"
    l1 = a.l1 or p1
    l2 = a.l2 or p2
    accent = {"red": RED, "amber": AMBER}[a.accent] if a.accent else c
    objk = a.obj or obj
    path = render(l1.upper(), l2.upper(), accent, objk, a.out)
    print(f"OK  thumbnail -> {path}  (1280x720, teks: '{l1}' / '{l2}')")

if __name__ == "__main__":
    main()
