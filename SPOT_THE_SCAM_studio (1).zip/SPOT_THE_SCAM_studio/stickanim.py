#!/usr/bin/env python3
# ============================================================
#  STICKANIM — ubah template stickgen jadi ANIMASI bergerak
#  Gerak: napas karakter, glow berdenyut, penipu mengetik,
#         layar monitor berkedip, bayangan bergoyang, dsb.
#  Input : scenes.txt (format sama dgn stickgen)
#  Output: <nama>.mp4  (fallback: .webp / .gif kalau tanpa ffmpeg)
#  Setup : pkg install python ffmpeg && pip install pillow
#          (tanpa ffmpeg: pip install imageio-ffmpeg juga bisa)
#  Pakai : python stickanim.py scenes.txt [folder] [detik=4] [fps=12]
# ============================================================
import os, sys, shutil, subprocess
import stickgen as sg
from PIL import Image

def find_ffmpeg():
    ff = shutil.which('ffmpeg')
    if ff: return ff
    try:
        import imageio_ffmpeg
        return imageio_ffmpeg.get_ffmpeg_exe()
    except Exception:
        return None

def render_frames(tmpl, kw, n, fdir):
    os.makedirs(fdir, exist_ok=True)
    paths = []
    for i in range(n):
        sg.PHASE = i / n
        img = sg.TEMPLATES[tmpl](**kw)
        p = os.path.join(fdir, f'f{i:03d}.png')
        img.save(p); paths.append(p)
    return paths

def make_mp4(ff, fdir, out, fps):
    cmd = [ff, '-y', '-framerate', str(fps),
           '-i', os.path.join(fdir, 'f%03d.png'),
           '-c:v', 'libx264', '-pix_fmt', 'yuv420p', '-crf', '20', out]
    r = subprocess.run(cmd, capture_output=True)
    return r.returncode == 0

def make_webp(paths, out, fps, scale=0.5):
    tw, th = int(1920*scale), int(1080*scale)
    ims = [Image.open(p).resize((tw, th), Image.LANCZOS) for p in paths]
    ims[0].save(out, save_all=True, append_images=ims[1:],
                duration=int(1000/fps), loop=0, quality=80, method=4)

def make_gif(paths, out, fps, scale=0.4):
    tw, th = int(1920*scale), int(1080*scale)
    ims = [Image.open(p).resize((tw, th), Image.LANCZOS)
              .convert('P', palette=Image.ADAPTIVE, colors=64) for p in paths]
    ims[0].save(out, save_all=True, append_images=ims[1:],
                duration=int(1000/fps), loop=0, optimize=True)

def main():
    src  = sys.argv[1] if len(sys.argv) > 1 else 'scenes.txt'
    outd = sys.argv[2] if len(sys.argv) > 2 else 'output_anim'
    secs = float(sys.argv[3]) if len(sys.argv) > 3 else 4.0
    fps  = int(sys.argv[4]) if len(sys.argv) > 4 else 12
    os.makedirs(outd, exist_ok=True)
    ff = find_ffmpeg()
    n  = int(secs * fps)

    items = []
    for i, raw in enumerate(open(src, encoding='utf-8'), 1):
        p = sg.parse_line(raw, i)
        if p: items.append(p)
    print(f'=== STICKANIM: {len(items)} klip x {secs}s @ {fps}fps = {n} frame/klip ===')
    print(f'    encoder: {"MP4 (ffmpeg)" if ff else "WEBP+GIF (ffmpeg tidak ada)"}\n')

    for idx, (out, tmpl, kw) in enumerate(items, 1):
        if tmpl not in sg.TEMPLATES:
            print(f'[?] template "{tmpl}" tidak ada — lewati'); continue
        base = os.path.splitext(out)[0]
        fdir = os.path.join(outd, base + '_frames')
        print(f'[{idx}/{len(items)}] {base}  ({tmpl}) render {n} frame...')
        paths = render_frames(tmpl, kw, n, fdir)
        if ff:
            ok = make_mp4(ff, fdir, os.path.join(outd, base + '.mp4'), fps)
            if ok:
                print(f'    OK -> {base}.mp4')
                for p in paths: os.remove(p)          # hemat ruang
                os.rmdir(fdir)
                continue
        make_webp(paths, os.path.join(outd, base + '.webp'), fps)
        make_gif(paths,  os.path.join(outd, base + '.gif'),  fps)
        print(f'    OK -> {base}.webp + {base}.gif (frame asli disimpan di {base}_frames/)')
    print('\n=== Selesai. Klip MP4 tinggal disusun di CapCut — gerak sudah built-in. ===')

if __name__ == '__main__':
    main()
