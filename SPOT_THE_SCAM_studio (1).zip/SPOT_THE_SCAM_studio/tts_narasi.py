#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# ============================================================
#  TTS_NARASI — adapter script edge-tts (versi user) ↔ A2VIDEO
#
#  Yang diubah dari script asli (deepwatch):
#   1. Semua path menuju /root/storage/Aspotcrime (jalur studio)
#      - pecahan wav -> audio_in/   (input a2video.py, TIDAK perlu pindah-pindah)
#      - SRT klip    -> srt/ep01.srt  (MASTER durasi klip, 1 cue = 1 pecahan!)
#   2. SRT klip = 1 cue per chunk (bukan pecahan proporsional 45-char)
#      → jumlah cue == jumlah wav → pasangan audio↔teks pasti 1:1 sinkron
#   3. SRT tampilan YouTube (proporsional 45 char) tetap ada di transkrip/
#   4. librosa OPSIONAL: kalau tak ada, decode pakai ffmpeg (imageio-ffmpeg)
#      + trim sederhana → script tetap jalan di Termux polos
#   5. Jika TTS gagal → diisi hening 1 dtk (penomoran wav tidak melompat,
#      agar tidak salah pasangan di pipeline)
#   6. --clean : hapus wav lama di audio_in sebelum mulai (episode baru)
#
#  Pakai:
#    python tts_narasi.py            # proses narasi.txt
#    python tts_narasi.py --clean    # episode baru (hapus wav lama dulu)
# ============================================================
import os, re, json, sys, asyncio, subprocess
import numpy as np
import contextlib, wave
import soundfile as sf
import edge_tts
import textwrap

try:
    import librosa
    HAS_LIBROSA = True
except Exception:
    HAS_LIBROSA = False

# ====================== ⚙️ KONFIGURASI UTAMA ======================
_PREFERRED = os.environ.get("A2_BASE") or "/root/storage/Aspotcrime"                   # jalur proot di HP
try:
    os.makedirs(_PREFERRED, exist_ok=True)
    if not os.access(_PREFERRED, os.W_OK):
        raise OSError
    BASE_PATH = _PREFERRED
except Exception:                                         # fallback otomatis
    _here = os.path.dirname(os.path.abspath(__file__))
    BASE_PATH = os.path.join(os.path.dirname(_here), 'Aspotcrime')
    os.makedirs(BASE_PATH, exist_ok=True)

TXT_PATH              = os.path.join(BASE_PATH, "narasi.txt")
AUDIO_OUT_FOLDER      = os.path.join(BASE_PATH, "drive")
FINAL_SLOW_AUDIO_PATH = os.path.join(BASE_PATH, "Final_narasi.wav")
TMP_TTS_FOLDER        = os.path.join(BASE_PATH, "audio_in")  # ← langsung input pipeline!
CHECKPOINT_FILE       = os.path.join(BASE_PATH, "checkpoint_chunks.txt")

TRANSKRIP_FOLDER      = os.path.join(BASE_PATH, "transkrip")
SRT_PATH              = os.path.join(TRANSKRIP_FOLDER, "subtitles.srt")   # utk YouTube
SRT_CLIP_PATH         = os.path.join(BASE_PATH, "srt", "ep01.srt")        # ← MASTER klip!
JSON_LOG_PATH         = os.path.join(TMP_TTS_FOLDER, "tts_chunks_log.json")

# ---- Parameter Suara (kandidat utk narasi scam-breakdown 55+) ----
#  en-US-AndrewNeural      : hangat+percaya diri (dipakai di demo review) ← rekomendasi #1
#  en-US-ChristopherNeural : paling dalam/berwibawa, nuansa dokumenter     ← rekomendasi #2
#  en-US-GuyNeural         : energik gaya berita
#  en-US-BrianNeural       : santai, deep
#  Tempo utk audiens 55+: rate -8% s/d -10% (jangan terburu-buru)
VOICE_NAME  = os.environ.get("TTS_VOICE", "en-US-AndrewNeural")
VOICE_RATE  = os.environ.get("TTS_RATE", "-8%")
VOICE_PITCH = os.environ.get("TTS_PITCH", "-8Hz")

os.makedirs(AUDIO_OUT_FOLDER, exist_ok=True)
os.makedirs(TMP_TTS_FOLDER, exist_ok=True)
os.makedirs(TRANSKRIP_FOLDER, exist_ok=True)
os.makedirs(os.path.dirname(SRT_CLIP_PATH), exist_ok=True)

MAX_CHARS       = 270
SR              = 24000

MAX_SRT_CHARS   = 45
MIN_SPLIT_SEC   = 2.0

PAUSE_ELLIPSIS  = 0.9
PAUSE_DASH      = 0.7
PAUSE_DOT       = 1.1
PAUSE_COMMA     = 0.4
PAUSE_DEFAULT   = 0.5
# =================================================================

def format_srt_time(seconds):
    hrs = int(seconds // 3600)
    mins = int((seconds % 3600) // 60)
    secs = int(seconds % 60)
    millis = int(round((seconds % 1) * 1000))
    if millis >= 1000:
        millis = 999
    return f"{hrs:02d}:{mins:02d}:{secs:02d},{millis:03d}"

def create_silence(duration_seconds, sr=SR):
    return np.zeros(int(duration_seconds * sr))

def split_text_smart(text, max_chars=MAX_CHARS):
    """Potong teks secara aman pada tanda baca"""
    if len(text) <= max_chars:
        return [text.strip()]
    chunks = []
    current = text
    while len(current) > max_chars:
        cut_pos = -1
        for punct in ["...", ". ", "? ", "! ", " — ", " -- "]:
            temp_pos = current.rfind(punct, int(max_chars * 0.4), max_chars + 50)
            if temp_pos != -1 and temp_pos > cut_pos:
                cut_pos = temp_pos + len(punct.strip())
        if cut_pos == -1:
            for punct in [", ", "; ", ": "]:
                temp_pos = current.rfind(punct, max_chars - 60, max_chars + 30)
                if temp_pos != -1:
                    cut_pos = temp_pos + 1
                    break
        if cut_pos == -1:
            cut_pos = current.rfind(" ", max_chars - 30, max_chars + 10)
            if cut_pos == -1:
                cut_pos = max_chars
        chunk = current[:cut_pos].strip()
        if chunk:
            chunks.append(chunk)
        current = current[cut_pos:].strip()
    if current:
        chunks.append(current)
    return [c for c in chunks if c]

# ---- loader audio: librosa kalau ada, kalau tidak pakai ffmpeg ----
def _ffmpeg_exe():
    try:
        import imageio_ffmpeg
        return imageio_ffmpeg.get_ffmpeg_exe()
    except Exception:
        return "ffmpeg"

def load_audio(path, sr=SR):
    if HAS_LIBROSA:
        return librosa.load(path, sr=sr)[0]
    ff = _ffmpeg_exe()
    r = subprocess.run([ff, '-v', 'error', '-i', path, '-f', 'f32le',
                        '-acodec', 'pcm_f32le', '-ac', '1', '-ar', str(sr), '-'],
                       capture_output=True)
    return np.frombuffer(r.stdout, dtype=np.float32).copy()

def trim_clean_cut(audio_np, sr):
    """sama dgn trim_clean tapi kembalikan (hasil, detik-dipotong-dari-awal)"""
    mag = np.abs(audio_np)
    if HAS_LIBROSA:
        trimmed, off = librosa.effects.trim(audio_np, top_db=40)
        cut = float(np.asarray(off).ravel()[0]) / sr
    else:
        thr = max(0.008, float(np.percentile(mag, 20)) * 2)
        idx = np.where(mag > thr)[0]
        if len(idx):
            trimmed = audio_np[idx[0]:idx[-1]+1]
            cut = float(idx[0]) / sr
        else:
            trimmed, cut = audio_np, 0.0
    fade_len = int(sr * 0.015)
    if len(trimmed) > 2 * fade_len:
        trimmed[:fade_len] *= np.linspace(0, 1, fade_len)
        trimmed[-fade_len:] *= np.linspace(1, 0, fade_len)
    return trimmed, cut

def trim_clean(audio_np, sr):
    """Bersihkan hening di ujung + micro-fade"""
    if HAS_LIBROSA:
        trimmed, _ = librosa.effects.trim(audio_np, top_db=40)
    else:
        mag = np.abs(audio_np)
        thr = max(0.008, float(np.percentile(mag, 20)) * 2)
        idx = np.where(mag > thr)[0]
        trimmed = audio_np[idx[0]:idx[-1]+1] if len(idx) else audio_np
    fade_len = int(sr * 0.015)
    if len(trimmed) > 2 * fade_len:
        trimmed[:fade_len] *= np.linspace(0, 1, fade_len)
        trimmed[-fade_len:] *= np.linspace(1, 0, fade_len)
    return trimmed

def baca_checkpoint():
    if os.path.exists(CHECKPOINT_FILE):
        try:
            with open(CHECKPOINT_FILE, "r") as f:
                return int(f.read().strip())
        except Exception:
            return 0
    return 0

def simpan_checkpoint(nomor_chunk):
    with open(CHECKPOINT_FILE, "w") as f:
        f.write(str(nomor_chunk))

async def edge_save_text_to_wav(text, out_wav_path, voice=VOICE_NAME, rate=VOICE_RATE, pitch=VOICE_PITCH):
    # v4.1: stream() — ambil audio SEKALIGUS timestamp kata asli (WordBoundary)
    try:
        communicator = edge_tts.Communicate(text, voice=voice, rate=rate, pitch=pitch,
                                            boundary='WordBoundary')
    except TypeError:                      # edge-tts lama: tanpa arg boundary
        communicator = edge_tts.Communicate(text, voice=voice, rate=rate, pitch=pitch)
    audio = bytearray()
    bounds = []
    def _ck(c, k, d=None):
        try: return c[k]
        except Exception:
            return getattr(c, k, d)
    async for chunk in communicator.stream():
        ctype = _ck(chunk, 'type', '')
        if ctype == 'audio':
            data = _ck(chunk, 'data')
            if data: audio.extend(data)
        elif ctype == 'WordBoundary':
            try:
                off = int(_ck(chunk, 'offset', 0)) / 1e7
                dur = int(_ck(chunk, 'duration', 0)) / 1e7
                wd = str(_ck(chunk, 'text', '') or '').strip()
                if wd:
                    bounds.append([round(off, 3), round(off + dur, 3), wd])
            except Exception:
                pass
    with open(out_wav_path, 'wb') as f:
        f.write(bytes(audio))
    return bounds

def synthesize_with_edge(text, out_wav_path):
    try:
        return asyncio.run(edge_save_text_to_wav(text, out_wav_path))
    except RuntimeError:
        loop = asyncio.get_event_loop()
        if loop.is_running():
            future = asyncio.ensure_future(edge_save_text_to_wav(text, out_wav_path))
            return loop.run_until_complete(future)
        else:
            return asyncio.run(edge_save_text_to_wav(text, out_wav_path))

# ==================== PROSES UTAMA ====================
if __name__ != "__main__":
    sys.exit(0)

if '--clean' in sys.argv:
    n = 0
    for f in os.listdir(TMP_TTS_FOLDER):
        if f.endswith('.wav'):
            os.remove(os.path.join(TMP_TTS_FOLDER, f)); n += 1
    if os.path.exists(CHECKPOINT_FILE):
        os.remove(CHECKPOINT_FILE)
    print(f"--clean: {n} wav lama dihapus (episode baru)")

print(f"Synthesizing with: {VOICE_NAME} | Pitch: {VOICE_PITCH} | Rate: {VOICE_RATE}")

with open(TXT_PATH, "r", encoding="utf-8") as f:
    full_text = f.read()

full_text = re.sub(r'\r\n', '\n', full_text)
full_text = re.sub(r'[ \t]+', ' ', full_text)

# 1 PARAGRAF = 1 ADEGAN: pisah dulu per --- , baru pecah panjang per paragraf
_paras = [p.strip() for p in re.split(r'(?m)^\s*-{2,}\s*$', full_text) if p.strip()]
_paras = [re.sub(r'\s*-{2,}\s*', ' ', p).strip() for p in _paras]  # --- nyasar
_paras = [p for p in _paras if p]
chunks = []
for _p in (_paras or [full_text.strip()]):
    chunks.extend(split_text_smart(_p))
print(f"Total Chunks: {len(chunks)}")

start_chunk = baca_checkpoint()
all_audio_segments = []
wb_all = []            # v4.1: timestamp kata per chunk (detik, relatif awal wav)

for i, chunk in enumerate(chunks, 1):
    temp_wav = os.path.join(TMP_TTS_FOLDER, f"edge_tmp_{i:05d}.wav")

    if i < start_chunk and os.path.exists(temp_wav):
        y = load_audio(temp_wav, SR)
        all_audio_segments.append(trim_clean(y, SR))
        try:
            with contextlib.closing(wave.open(temp_wav)) as _w:
                _d = round(_w.getnframes() / _w.getframerate(), 3)
        except Exception:
            _d = round(len(y) / SR, 3)
        wb_all.append({"dur": _d, "bounds": []})   # resume: tanpa bounds -> fallback
        continue

    simpan_checkpoint(i)
    print(f"[{i}/{len(chunks)}] Processing {len(chunk)} chars...")

    audio_ok = False
    for attempt in (1, 2, 3):                # RETRY 3x — jangan langsung hening!
        try:
            if attempt > 1:
                print(f"[{i}] percobaan ke-{attempt} ...")
                import time as _t; _t.sleep(2.0)
            _wb = synthesize_with_edge(chunk, temp_wav) or []
            y = load_audio(temp_wav, SR)
            if len(y) < SR * 0.2:            # audio terlalu pendek = gagal halus
                raise RuntimeError('audio terlalu pendek')
            trimmed, cut = trim_clean_cut(y, SR)
            all_audio_segments.append(trimmed)
            wb_all.append({"dur": round(len(trimmed) / SR, 3),
                           "bounds": [[round(max(0.0, a - cut), 3),
                                       round(max(0.0, b - cut), 3), w]
                                      for a, b, w in _wb]})
            audio_ok = True
            break
        except Exception as e:
            print(f"RETRY! Chunk {i} percobaan {attempt} gagal: {e}")
    if not audio_ok:
        print(f"GAGAL TOTAL Chunk {i} setelah 3x → diisi hening (urutan aman). CEK INTERNET!")
        sil = create_silence(1.0, SR)
        sf.write(temp_wav, sil, SR)
        all_audio_segments.append(sil)
        wb_all.append({"dur": 1.0, "bounds": []})

print("\nMenyusun audio final, log JSON, dan dua file SRT...")
final_segments = []
srt_entries = []       # SRT tampilan (proporsional 45 char)
srt_clip_entries = []  # SRT klip (1 cue = 1 chunk) — utk a2video
json_log_data = []

current_time = 0.0
srt_index = 1
clip_index = 1

for i, audio in enumerate(all_audio_segments):
    final_segments.append(audio)
    speech_duration = len(audio) / SR
    chunk_text = chunks[i].strip()

    if i < len(all_audio_segments) - 1:
        if chunk_text.endswith("...") or "..." in chunk_text[-5:]:
            pause_sec = PAUSE_ELLIPSIS
        elif chunk_text.endswith("—") or chunk_text.endswith("--"):
            pause_sec = PAUSE_DASH
        elif chunk_text.endswith(".") or chunk_text.endswith("?") or chunk_text.endswith("!"):
            pause_sec = PAUSE_DOT
        elif chunk_text.endswith(","):
            pause_sec = PAUSE_COMMA
        else:
            pause_sec = PAUSE_DEFAULT
    else:
        pause_sec = 0.0

    if pause_sec > 0:
        final_segments.append(create_silence(pause_sec, SR))

    start_time = current_time
    end_time = start_time + speech_duration

    # ---- A. SRT tampilan (proporsional, utk upload YouTube) ----
    if len(chunk_text) <= MAX_SRT_CHARS or speech_duration < MIN_SPLIT_SEC:
        formatted_text = "\n".join(textwrap.wrap(chunk_text, width=MAX_SRT_CHARS))
        srt_entries.append(f"{srt_index}\n{format_srt_time(start_time)} --> {format_srt_time(end_time)}\n{formatted_text}\n")
        srt_index += 1
    else:
        sub_chunks = textwrap.wrap(chunk_text, width=MAX_SRT_CHARS)
        total_chars = len(chunk_text)
        sub_start_time = start_time
        for sub_text in sub_chunks:
            ratio = len(sub_text) / total_chars
            sub_end_time = sub_start_time + speech_duration * ratio
            srt_entries.append(f"{srt_index}\n{format_srt_time(sub_start_time)} --> {format_srt_time(sub_end_time)}\n{sub_text}\n")
            srt_index += 1
            sub_start_time = sub_end_time

    # ---- B. SRT KLIP: 1 cue = 1 chunk (pasangan 1:1 dgn wav!) ----
    clip_end = end_time + pause_sec
    srt_clip_entries.append(
        f"{clip_index}\n{format_srt_time(start_time)} --> {format_srt_time(clip_end)}\n{chunk_text}\n")
    clip_index += 1

    # ---- C. Log JSON ----
    json_log_data.append({
        "chunk_id": i + 1,
        "text": chunk_text,
        "start_time_sec": round(start_time, 3),
        "end_time_sec": round(end_time, 3),
        "speech_duration_sec": round(speech_duration, 3),
        "pause_duration_sec": round(pause_sec, 3),
        "wav_file": f"edge_tmp_{i+1:05d}.wav"
    })

    current_time += (speech_duration + pause_sec)

if not final_segments:
    raise RuntimeError("Tidak ada audio yang berhasil dibuat.")

final_audio = np.concatenate(final_segments)
final_audio = final_audio / np.max(np.abs(final_audio)) * 0.89
sf.write(FINAL_SLOW_AUDIO_PATH, final_audio, SR)

with open(SRT_PATH, "w", encoding="utf-8") as f:
    f.write("\n".join(srt_entries) + "\n")
with open(SRT_CLIP_PATH, "w", encoding="utf-8") as f:
    f.write("\n".join(srt_clip_entries) + "\n")
with open(JSON_LOG_PATH, "w", encoding="utf-8") as f:
    json.dump(json_log_data, f, ensure_ascii=False, indent=2)

# v4.1: timestamp kata utk sinkron subtitle presisi (dibaca a2video)
try:
    _rows = []
    for i in range(len(chunks)):
        e = wb_all[i] if isinstance(wb_all[i], dict) else {"dur": 0.0, "bounds": wb_all[i]}
        _rows.append({"i": i, "text": chunks[i].strip()[:80],
                      "dur": e.get("dur", 0.0), "bounds": e.get("bounds", [])})
    with open(os.path.join(BASE_PATH, "wordbounds.json"), "w", encoding="utf-8") as f:
        json.dump(_rows, f, ensure_ascii=False)
    print("wordbounds.json:", sum(1 for r in _rows if r["bounds"]), "dari",
          len(_rows), "chunk ber-timestamp")
except Exception as _e:
    print("wordbounds gagal ditulis (fallback proporsional):", _e)

print("\n" + "="*50)
print("PROSES SELESAI!")
print(f"1. Audio Final     : {FINAL_SLOW_AUDIO_PATH}")
print(f"2. Pecahan wav     : {TMP_TTS_FOLDER} ({len(all_audio_segments)} file) ← input studio")
print(f"3. SRT KLIP master : {SRT_CLIP_PATH} ← dipasangkan 1:1 dgn pecahan")
print(f"4. SRT tampilan YT : {SRT_PATH}")
print(f"5. Log JSON        : {JSON_LOG_PATH}")
print("="*50)
print("LANJUT: python a2video.py --all --srt srt/ep01.srt")
print("(atau buka GUI a2studio → Merge + Build)")
if os.path.exists(CHECKPOINT_FILE):
    os.remove(CHECKPOINT_FILE)
