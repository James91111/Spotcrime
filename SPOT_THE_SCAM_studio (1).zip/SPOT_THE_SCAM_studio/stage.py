#!/usr/bin/env python3
# ============================================================
#  STAGE — mesin adegan "visual mewakili narasi"
#  Karakter  : buatan sendiri (cast.py) — dewasa, ekspresif
#  Latar     : Kenney CC0 (awan/pohon) di atas tema putih
#  Properti  : gambar-tangan sendiri (cast.prop) + item Kenney
#  Motif adegan otomatis dari isi kalimat:
#    telepon berdering, call center penipu, kaget, polisi datang,
#    bank, keluarga, komputer/remote access, gift cards, uang,
#    pertahanan (perisai), bahaya (tanda), jalan, dsb.
# ============================================================
import os, math, random, re, uuid
from PIL import Image, ImageDraw
import cast, kenney, kinetic, smartsub
import paths, bgpack

W, H = 1920, 1080
GROUND = 920
CHAR_H = 470          # tinggi karakter di layar
BG_C = kenney.BG_C

def _sprite(name):
    p = paths.kenney(name)
    return Image.open(p).convert('RGBA') if p else None

# ---------------- latar (Kenney, lembut) -------------------------
_bg_cache = {}
_obj_cache = {}
_OBJ_INDEX = None          # v4.5: nama -> file obj_XXX.png (dr manifest)
def _obj_path(name):
    """resolusi nama objek -> path file (objpack simpan obj_XXX.png)"""
    global _OBJ_INDEX
    import os as _os, json as _json
    if _OBJ_INDEX is None:
        _OBJ_INDEX = {}
        for a in paths.ASSETS:
            m = _os.path.join(a, 'objpack', 'manifest.json')
            if _os.path.exists(m):
                try:
                    man = _json.load(open(m))
                    _OBJ_INDEX = {v['name']: _os.path.join(a, 'objpack', f)
                                  for f, v in man.items()}
                except Exception:
                    pass
                break
    if name in _OBJ_INDEX: return _OBJ_INDEX[name]
    for a in paths.ASSETS:                      # fallback: nama langsung
        c = _os.path.join(a, 'objpack', name + '.png')
        if _os.path.exists(c): return c
    return None
def _obj_sprite(name):
    """objek ambien dr objpack (cache, diredupkan)"""
    if name in _obj_cache: return _obj_cache[name]
    p = _obj_path(name)
    if p is None: return None
    im = Image.open(p).convert('RGBA')
    im.putalpha(im.getchannel('A').point(lambda v: int(v*0.62)))
    _obj_cache[name] = im
    return im

_AMBIENT = None
_INDOOR = ('tv', 'sofa', 'bookshelf', 'mug', 'cooler', 'printer', 'whiteboard',
           'cubicle', 'wallclock', 'lamp', 'kettle', 'cup', 'photoframe',
           'plant', 'papers', 'book', 'radio', 'frame')
# tema objek per kata kunci cerita (ala film: setiap lokasi punya dekor khas)
_THEME_POOLS = {
    'money':   ['giftcard_01', 'giftcard_02', 'mailbox_01', 'mailbox_02',
                'newspaper_01', 'papers_01', 'wallet', 'sign_01'],
    'call':    ['lamp_01', 'photoframe_01', 'plant_01', 'radio_01',
                'wallclock_01', 'mug_01', 'bookshelf_01', 'tv_01'],
    'police':  ['fence_01', 'sign_02', 'lamppost_01', 'cone', 'hydrant_01',
                'trashbin_01', 'signpost_01'],
    'home':    ['sofa_01', 'tv_02', 'plant_02', 'photoframe_02', 'mug_02',
                'kettle_01', 'bookshelf_02', 'cat_01', 'book_01'],
    'street':  ['tree_01', 'pine_01', 'bush_01', 'grass_01', 'flowers_01',
                'bench_01', 'lamppost_02', 'fence_02', 'signpost_02'],
    'bank':    ['cubicle_01', 'printer_01', 'whiteboard_01', 'papers_02',
                'cooler_01', 'wallclock_02', 'mug_01'],
    'sad':     ['newspaper_02', 'plant_03', 'photoframe_03', 'bench_02'],
    'scam':    ['trashbin_02', 'sign_03', 'newspaper_01', 'papers_01', 'tv_01'],
}
_THEME_KEYS = {
    'money': ('$', 'dollar', 'thousand', 'million', 'billion', 'savings',
              'gift card', 'cash', 'wire', 'transfer', 'check', 'cheque'),
    'police': ('police', 'officer', 'sheriff', 'arrest', 'jail', 'warrant',
               'fbi', 'agent', 'crime', 'report'),
    'bank': ('bank', 'teller', 'branch', 'fraud department', 'account'),
    'street': ('street', 'outside', 'walk', 'drives', 'car', 'park', 'road',
               'knock', 'door'),
    'sad': ('cried', 'tears', 'sad', 'ashamed', 'devastated', 'alone', 'lost'),
    'scam': ('scam', 'scammer', 'fraud', 'fake', 'trick', 'steal', 'stolen',
             'threat', 'lie'),
    'call': ('phone', 'call', 'caller', 'voicemail', 'rang', 'ring'),
}

def _ambient_names(seed, indoor=False, low=''):
    global _AMBIENT
    if _AMBIENT is None:
        import os as _os, json as _json
        for a in paths.ASSETS:
            m = _os.path.join(a, 'objpack', 'manifest.json')
            if _os.path.exists(m):
                _AMBIENT = [v['name'] for v in _json.load(open(m)).values()]
                break
    names = _AMBIENT or []
    if not names: return []
    # 1) tema dari isi kalimat (match urutan dict)
    theme = None
    for th, keys in _THEME_KEYS.items():
        if any(k in low for k in keys):
            theme = th; break
    pool = list(_THEME_POOLS.get(theme, []))
    rng = random.Random(seed*31 + 11)
    # 2) isi sisa slot dari pool umum (indoor/outdoor sesuai latar)
    if indoor:
        umum = [n for n in names if n.startswith(_INDOOR)]
    else:
        umum = [n for n in names if not n.startswith(_INDOOR)
                and not n.startswith(('arrow', 'bird'))]
    rng.shuffle(umum)
    for n in umum:
        if len(pool) >= 6: break
        if n not in pool: pool.append(n)
    # 3) 2-4 objek, urutan acak per klip → tiap adegan beda komposisi
    cnt = rng.choice([2, 3, 3, 4])
    return [n for n in rng.sample(pool, min(cnt, len(pool)))]

def _bg(variant, seed=1):
    key = (variant, seed)
    if key in _bg_cache: return _bg_cache[key]
    if variant in bgpack.NAMES:            # resep bgpack (100 varian)
        img = bgpack.render(variant).copy()
        _bg_cache[key] = img
        return img
    img = Image.new('RGB', (W, H), BG_C)
    d = ImageDraw.Draw(img)
    for gy in range(60, H, 46):
        for gx in range(40, W, 46):
            d.ellipse([gx-1.5, gy-1.5, gx+1.5, gy+1.5], fill=(225, 230, 240))
    d.rectangle([0, GROUND+8, W, GROUND+16], fill=(228, 232, 242))
    rng = random.Random(seed)
    if variant == 'clouds':
        for c, x, y, s in (('bg/background_cloudA', 100, 430, 3.4),
                           ('bg/background_cloudB', 860, 480, 2.8),
                           ('bg/background_cloudA', 1520, 450, 3.0)):
            im = _sprite(c)
            if im is None: continue
            im = im.resize((int(im.width*s), int(im.height*s)))
            im.putalpha(im.getchannel('A').point(lambda v: int(v*0.35)))
            img.paste(im, (x, y), im)
    elif variant == 'trees':
        for i in range(5):
            im = _sprite('bg/background_treeLarge' if i % 2 else 'bg/background_tree')
            if im is None: continue
            s = 3.4 + rng.random()*1.6
            im = im.resize((int(im.width*s), int(im.height*s)))
            im.putalpha(im.getchannel('A').point(lambda v: int(v*0.22)))
            img.paste(im, (int(i*(W-400)/4) + rng.randint(-40, 40), GROUND+8-im.height), im)
    elif variant == 'office':    # call center: garis meja + monitor dinding
        d.rectangle([0, GROUND+8, W, GROUND+16], fill=(210, 216, 232))
        for x in range(140, W, 460):
            d.rounded_rectangle([x, 420, x+150, 500], 10, outline=(214, 220, 236), width=5)
            d.line([x+75, 500, x+75, 560], fill=(214, 220, 236), width=5)
    elif variant == 'home':      # ruang keluarga: bingkai foto + tanaman
        d.rounded_rectangle([260, 300, 470, 470], 8, outline=(214, 220, 236), width=8)
        d.rounded_rectangle([300, 340, 430, 430], 4, fill=(226, 232, 244))
        d.rounded_rectangle([1350, 280, 1620, 500], 8, outline=(214, 220, 236), width=8)
        d.rounded_rectangle([1392, 322, 1578, 458], 4, fill=(226, 232, 244))
        d.rounded_rectangle([1690, 690, 1800, 830], 10, fill=(196, 152, 116),
                            outline=(170, 176, 192), width=5)
        for a_, b_ in ((1720, 690), (1745, 676), (1770, 690)):
            d.ellipse([a_-22, b_-46, a_+22, b_+18], fill=(150, 178, 148))
    elif variant == 'street':    # jalanan: rumah kecil + jalan bergaris
        hs = cast.prop('house')
        if hs is not None:
            hs = hs.resize((int(hs.width*1.7), int(hs.height*1.7)), Image.LANCZOS)
            al = hs.getchannel('A').point(lambda v: int(v*0.55))
            hs.putalpha(al)
            img.paste(hs, (60, GROUND+8-hs.height), hs)
        for x in range(140, W, 180):
            d.rounded_rectangle([x, GROUND+52, x+90, GROUND+62], 4, fill=(214, 220, 236))
    _bg_cache[key] = img
    return img

def _shadow(img, cx, cy, w):
    d = ImageDraw.Draw(img, 'RGBA')
    d.ellipse([cx-w/2, cy-9, cx+w/2, cy+9], fill=(210, 214, 226, 120))

# ---------------- aktor ------------------------------------------
ROLE_HALO = {}
for _v in ('grandma', 'grandma2', 'grandma3', 'grandpa', 'grandpa2', 'neighbor'):
    ROLE_HALO[_v] = (120, 190, 140)          # korban/orang baik: HIJAU
for _s in ('scammer', 'scammer2', 'tech'):
    ROLE_HALO[_s] = (226, 90, 90)            # penipu: MERAH
for _a in ('cop', 'sheriff', 'agent', 'irs', 'banker'):
    ROLE_HALO[_a] = (90, 120, 200)           # otoritas: BIRU
for _f in ('daughter', 'son'):
    ROLE_HALO[_f] = (240, 190, 70)           # keluarga: KUNING

def _actor(img, a, now, dur, env=None, env_fps=12, env_off=0.0):
    who  = a.get('who', 'grandma')
    act  = a.get('action', 'talk')
    x    = a.get('x', 620)
    h    = a.get('height', CHAR_H)
    pose, emo = a.get('pose', 'stand'), a.get('emo')
    yoff, xoff = 0.0, 0.0
    step = 0

    if act == 'enter':
        span = min(1.6, dur*0.35)
        if now < span:
            t = now / span
            side = -1 if a.get('side', 'left') == 'left' else 1
            xoff = side * (1-t) * (W/2 + 300)
            pose, step = 'walk', int(now*12/2.6)
        else: pose = a.get('pose', 'stand')
    elif act == 'exit':
        span = min(1.6, dur*0.3)
        if now > dur - span:
            t = (now-(dur-span)) / span
            side = 1 if a.get('side', 'left') == 'left' else -1
            xoff = side * t * (W/2 + 300)
            pose, step = 'walk', int(now*12/2.6)
        else: pose = a.get('pose', 'stand')
    elif act == 'walk':
        w0 = a.get('w0', 0.0)
        if now >= w0:
            t = min(1.0, (now-w0)/max(0.1, dur-w0-0.3))
            xoff = a.get('dx', 420) * t
            pose, step = 'walk', int(now*12/2.6)
        else: pose = 'stand'
    elif act == 'jump':
        for k in range(2):
            t0 = 0.28 + k*0.34
            if t0 <= now/dur <= t0+0.18:
                yoff = -math.sin(math.pi*(now/dur-t0)/0.18) * 190
                pose = 'happy'
    elif act == 'shockhit':          # kaget + getar di tengah
        t0 = dur*0.5
        if now > t0:
            pose, emo = 'shock', emo or 'shock'
    elif act == 'phased':
        pose = a.get('pose', 'talk')
        for (t0, t1, p_) in a.get('phases', []):
            if t0 <= now < t1:
                pose = p_; break
    elif act == 'pace':                  # v4.4: mondar-mandir cemas
        ph2 = math.sin(now*0.9 + (hash(who) % 5))
        xoff += ph2 * 90
        pose, step = 'walk', int(now*7)
        if abs(ph2) > 0.25: a['_flipauto'] = ph2 < 0
    elif act == 'gesture':               # v4.4: bicara + tangan luas
        pose = 'gesture' if (int(now*1.4) % 2 == 0) else 'talk'
        yoff = -abs(math.sin(now*2.9)) * 10
    elif act == 'look':                  # v4.4: waspada, melihat kanan-kiri
        pose = a.get('pose', 'talk')
        yoff = -abs(math.sin(now*2.2)) * 7
    elif act == 'nod':                   # v4.4: mengangguk
        pose = a.get('pose', 'talk')
        yoff = -abs(math.sin(now*5.2)) * 6
    elif act == 'shake':                 # v4.4: menggeleng menolak
        pose = a.get('pose', 'talk')
        xoff += math.sin(now*9.0) * 4
    elif act == 'stepback':              # v4.4: mundur terkejut
        t0b = dur*0.35
        if t0b <= now < t0b + 0.9:
            e2 = math.sin(min(1.0, (now-t0b)/0.35) * math.pi)
            xoff += (-1 if a.get('side', 'left') == 'left' else 1) * 84 * e2
            pose, emo = 'stand', emo or 'shock'
        else:
            pose = a.get('pose', 'talk')
    elif act == 'run':                   # v4.4: berlari tergesa
        w0 = a.get('w0', 0.0)
        if now >= w0:
            t2 = min(1.0, (now-w0)/max(0.1, dur-w0-0.3))
            xoff = a.get('dx', 620) * t2
            pose, step = 'run', int(now*13)
        else:
            pose = 'stand'
    elif act == 'give':                  # v4.4: menyerahkan barang
        p01g = (now - dur*0.32) / max(0.1, dur*0.30)
        pose = 'point' if 0.0 < p01g < 1.0 else a.get('pose', 'talk')
    else:  # talk — ringan hidup
        base = a.get('pose', 'talk')
        pose = 'stand' if (int(now*2.2) % 3 == 0 and base == 'talk') else base
        yoff = -abs(math.sin(now*2.6)) * 8

    if pose == 'walk':                        # jalan lebih hidup (bob)
        yoff = -abs(math.sin(now*7.0)) * 9
    yoff -= 2.0 + 1.5*math.sin(now*2.1 + (hash(who) % 7))   # napas halus
    # v4.3: mikro-gerak — geser berat badan + gemetar kalau cemas
    idk = (a.get('_uk', 0) % 7) + (hash(who) % 5)
    if act in ('talk', 'stand', 'point', 'phone', 'phased', 'happy'):
        xoff += math.sin(now*0.85 + idk) * 7
        if emo in ('worried', 'shock'):
            xoff += math.sin(now*13.0 + idk) * 1.8

    if act == 'look':                    # v4.4: mata menengok kiri/kanan
        a['_look'] = 1 if math.sin(now*0.55 + idk) > 0 else -1
    else:                                # sesekali melirik natural
        a['_look'] = 1 if math.sin(now*0.42 + idk*1.7) > -0.72 else -1
    im = cast.frame(who, pose, emo, step, look=a['_look'])
    s = h / im.height
    im = im.resize((max(1, int(im.width*s)), max(1, int(im.height*s))), Image.LANCZOS)
    if a.get('flip') or a.get('_flipauto', False): im = im.transpose(Image.FLIP_LEFT_RIGHT)
    px, py = int(x + xoff - im.width/2), int(GROUND + yoff - im.height)
    _shadow(img, x + xoff, GROUND + 6, im.width*0.72)
    halo = ROLE_HALO.get(who)
    if halo:                                 # ring identitas di kaki
        hw = im.width*0.46
        d = ImageDraw.Draw(img, 'RGBA')
        d.ellipse([x+xoff-hw, GROUND-4, x+xoff+hw, GROUND+18],
                  outline=halo + (230,), width=7)
    img.paste(im, (px, py), im)
    a['_head'] = (px + (460-230 if a.get('flip') else 230)*s, py + 190*s, s)
    if act == 'give':                     # v4.4: barang diserahkan melengkung
        p01 = min(1.0, max(0.0, (now - dur*0.32) / max(0.1, dur*0.30)))
        if 0.02 < p01 < 0.98:
            gx0 = x + (300 if a.get('give_dx', 300) > 0 else -300)*0.0
            gx0 = x + (im.width*0.5 if a.get('give_dx', 300) > 0 else -im.width*0.5)
            gdx = float(a.get('give_dx', 300))
            gi = gx0 + gdx * p01
            gy2 = GROUND - 200 - math.sin(p01*math.pi)*74
            d3 = ImageDraw.Draw(img, 'RGBA')
            if str(a.get('give_item', 'bill')) == 'card':
                d3.rounded_rectangle([gi-32, gy2-20, gi+32, gy2+20], 6,
                                     fill=(120, 150, 200, 240), outline=(30, 34, 58, 255), width=4)
                d3.line([gi-16, gy2, gi+16, gy2], fill=(230, 236, 248, 255), width=4)
            else:
                d3.rounded_rectangle([gi-36, gy2-22, gi+36, gy2+22], 6,
                                     fill=(198, 228, 188, 245), outline=(30, 34, 58, 255), width=4)
                d3.ellipse([gi-15, gy2-10, gi+15, gy2+10], fill=(150, 190, 150, 240))
    if emo == 'sad':                      # air mata jatuh (animasi)
        d2 = ImageDraw.Draw(img, 'RGBA')
        for k in (0, 1):
            prog = ((now*1.3 + k*0.45) % 0.9) / 0.9
            ty = py + (186 + 10 + prog*70)*s
            exx = (460-239 if a.get('flip') else 239) + (14 if k else -14)
            r = 5*s*(1-prog*0.4)
            tx = px + exx*s
            d2.ellipse([tx-r, ty-r, tx+r, ty+r], fill=(90, 140, 220, 210))
    if a.get('speaker') and env is not None:
        d2 = ImageDraw.Draw(img, 'RGBA')
        _talk_mouth(img, px, py, s, now + env_off, bool(a.get('flip')), who, emo,
                    env, env_fps, d2)
    return (px + im.width//2, py)

# ---------------- ANIMASI PLUS: mulut bicara + kedip -------------
def _talk_mouth(img, px, py, s, now, flip, who, emo, env, env_fps, d):
    """Mulut buka-tutup (env = envelope audio 0..1) + kedip mata tiap ±3 dtk.
    Koordinat ruang cast (460x640): kepala (230,190) r74; mulut (256,214);
    mata (239,186) & (273,186). flip = cermin horizontal."""
    if flip:
        mx, e1x, e2x = 460-256, 460-273, 460-239
    else:
        mx, e1x, e2x = 256, 239, 273
    MX, MY = px + mx*s, py + 214*s
    INKW = max(2, int(3*s))
    if emo != 'shock':                        # shock sudah punya mulut O
        if env is None:
            op = 0.0
        else:
            k = min(len(env)-1, max(0, int(now*env_fps)))
            op = max(0.0, min(1.0, env[k]))
        if op < 0.07:
            d.line([MX-13*s, MY, MX+13*s, MY], fill=cast.INK, width=max(2, int(4*s)))
        else:
            rx, ry = (10+13*op)*s, (2+13*op)*s
            d.ellipse([MX-rx, MY-ry, MX+rx, MY+ry], fill=(112, 40, 46),
                      outline=cast.INK, width=INKW)
    ph = (hash(who) % 10) * 0.33
    if (now + ph) % 3.3 < 0.13:
        skin = cast.SKIN.get(cast.PRESET.get(who, cast.PRESET['grandma'])
                             .get('skin', 'light'), (241, 215, 190))
        for exx in (e1x, e2x):
            cx0, cy0 = px+exx*s, py+186*s
            r = 13*s
            d.ellipse([cx0-r, cy0-r, cx0+r, cy0+r], fill=skin)
            d.line([cx0-9*s, cy0, cx0+9*s, cy0], fill=cast.INK, width=INKW)

# ---------------- properti ---------------------------------------
_objfull_cache = {}
def _objfull(name):
    """objpack alpha penuh utk prop utama (v4.0)"""
    if name in _objfull_cache: return _objfull_cache[name]
    p = _obj_path(name)
    if p is None: return None
    im = Image.open(p).convert('RGBA')
    _objfull_cache[name] = im
    return im

def _prop(img, p, now, dur):
    t0 = float(p.get('t0', 0.4))
    if now < t0: return
    tt = now - t0
    x, y = p.get('x', 1450), p.get('y', 600)
    scale = float(p.get('scale', 1.6))
    anim = p.get('anim', 'pop')
    src = cast.prop(p['prop']) if p.get('prop') else (_objfull(p['obj']) if p.get('obj') else (_sprite(p['sprite']) if p.get('sprite') else None))
    if src is None: return
    base = src.resize((int(src.width*scale), int(src.height*scale)), Image.LANCZOS)
    if anim == 'pop' and tt < 0.34:
        e = tt/0.34
        sc = 0.35 + 0.65*e + math.sin(e*math.pi)*0.10
        cur = base.resize((max(1, int(base.width*sc)), max(1, int(base.height*sc))), Image.LANCZOS)
    elif anim == 'pulse':
        sc = 1 + math.sin(tt*4.2)*0.05
        cur = base.resize((int(base.width*sc), int(base.height*sc)), Image.LANCZOS)
    elif anim == 'float':
        cur, y = base, y + math.sin(tt*2.1)*15
    elif anim == 'spin' and p.get('sprite'):
        cur = base.rotate(-(tt*240) % 360, expand=True, resample=Image.BICUBIC)
    elif anim == 'vibrate':               # v4.4: bergetar (HP berdering)
        cur = base; x += int(math.sin(tt*46)*5)
    elif anim == 'sway':                  # v4.4: berayun pelan
        cur = base.rotate(math.sin(tt*2.0)*8, expand=True, resample=Image.BICUBIC)
    elif anim == 'flicker':               # v4.4: layar berkedip
        cur = base
        if math.sin(tt*17) > 0.4:
            cur = base.copy()
            cur.putalpha(cur.getchannel('A').point(lambda vv: int(vv*0.55)))
    elif anim == 'slide':                 # v4.4: meluncur masuk (ease-out)
        x0s = float(p.get('x0', x - 320))
        e5 = min(1.0, tt/0.7)
        x = x0s + (x - x0s)*(1 - (1-e5)*(1-e5))
        cur = base
    else:
        cur = base
    _shadow(img, x, min(y + cur.height/2, GROUND+6), base.width*0.6)
    img.paste(cur, (int(x-cur.width/2), int(y-cur.height/2)), cur)

# ---------------- kamus motif custom (motifs.dat) ----------------
def _load_custom():
    import os as _os
    rules = []
    p = _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), 'motifs.dat')
    if not _os.path.exists(p): return rules
    for line in open(p, encoding='utf-8'):
        line = line.strip()
        if not line or line.startswith('#'): continue
        parts = [x.strip() for x in line.split('|')]
        if len(parts) < 3: continue
        name = parts[0]
        keys = [k.lower() for k in parts[1].split(',') if k.strip()]
        actors = [a.strip() for a in parts[2].split(';') if a.strip()]
        props = parts[3] if len(parts) > 3 else ''
        bg = parts[4].strip() if len(parts) > 4 else 'otomatis'
        rules.append(dict(name=name, keys=keys, actors=actors, props=props, bg=bg))
    return rules

def _try_custom(low, spec, dur):
    for r in _load_custom():
        if any(k in low or _has(low, k) for k in r['keys']):
            left = True
            for a in r['actors']:
                who, _, act = a.partition('@')
                side = 'left' if left else 'right'
                if who == 'victim': who = VICTIMS[0]
                if who in ('scammer2', 'tech'): pass
                c = dict(who=who, action=act or 'talk', side=side,
                         x=620 if left else 1310, flip=not left)
                c['emo'] = 'sly' if who in ('scammer', 'scammer2', 'tech') else None
                spec['actors'].append(c); left = False
            for p in [x.strip() for x in r['props'].split('+') if x.strip()]:
                seg = p.split(':')
                pname = seg[0]
                anim = seg[1] if len(seg) > 1 else 'pop'
                pos = seg[2].split(',') if len(seg) > 2 else ['1400', '560']
                sc = float(seg[3]) if len(seg) > 3 else 2.6
                spec['props'].append(dict(
                    prop=pname if pname in ('phone', 'giftcards', 'monitor', 'shield',
                                            'sign', 'counter', 'laptop', 'car', 'house',
                                            'mail', 'wallet', 'atm', 'btc', 'card',
                                            'report', 'clock', 'blockphone', 'checklist')
                    else None,
                    sprite=None if pname in ('phone', 'giftcards', 'monitor', 'shield',
                                             'sign', 'counter', 'laptop', 'car', 'house',
                                             'mail', 'wallet', 'atm', 'btc', 'card',
                                             'report', 'clock', 'blockphone', 'checklist')
                    else f'items/{pname}',
                    anim=anim, x=int(pos[0]), y=int(pos[1]), scale=sc, t0=0.5))
            if r['bg'] != 'otomatis':
                spec['bg'] = r['bg']
            return r['name']
    return None

# ---------------- template motif ---------------------------------
# posisi standar: kiri = 620, tengah = 960, kanan = 1310
VICTIMS  = ['grandma', 'grandma2', 'grandpa', 'grandma3', 'grandpa2']
SCAMMERS = ['scammer', 'scammer2', 'techgirl']
COPS     = ['cop', 'sheriff']

def _has(low, *words):
    """cocokkan kata UTUH (bukan sebagian) — hindari 'person'→'son' dsb."""
    import re as _re
    return any(_re.search(r'\b' + _re.escape(w) + r'\b', low) for w in words)


def _motif(low, spec, dur):
    A = spec['actors']; P = spec['props']
    import re as _re
    sd = int(spec.get('seed', 1))
    # korban KONSISTEN sepanjang cerita: kata ganti perempuan → oma,
    # laki-laki → opa, narasi statistik (victims/seniors) → rotasi variatif
    if _re.search(r'\b(she|her|hers|grandma|grandmother|grand ma|margaret|woman|lady|aunt)\b', low):
        victim = 'grandma'
    elif _re.search(r'\b(he|his|him|grandpa|grandfather|grand pa|man|uncle|husband)\b', low):
        victim = 'grandpa'
    elif any(w in low for w in ('victims', 'seniors', 'americans', 'people', 'callers', 'customers')):
        victim = VICTIMS[sd % len(VICTIMS)]
    else:
        victim = 'grandma'   # protagonis utama channel
    scammer = SCAMMERS[sd % len(SCAMMERS)]
    cop = COPS[sd % len(COPS)]
    def add(who, action='talk', side='left', **kw):
        c = dict(who=who, action=action, side=side,
                 x=620 if side == 'left' else 1310,
                 flip=(side == 'right'))
        c['_uk'] = int(spec.get('seed', 1))*7 + len(A)*13 + 7301   # v4.0: variasi posisi
        if action == 'talk':                     # v4.4: variasi GERAK bicara
            r3 = (int(spec.get('seed', 1))*31 + len(A)*17 + 5) % 10
            if r3 < 4:   action = 'gesture'      # tangan bergerak luas
            elif r3 < 6: action = 'look'         # melihat sekeliling
            elif r3 < 7: action = 'nod'          # mengangguk
        c.update(kw); A.append(c); return c
    def prop(**kw):
        kw.setdefault('x', 1500); kw.setdefault('y', 560)
        kw.setdefault('scale', 1.7); kw.setdefault('t0', 0.5)
        P.append(kw); return kw

    if 'call center' in low or 'callcentre' in low or 'boiler room' in low or _has(low, 'office'):
        add(scammer, 'talk', 'left'); add('scammer2' if scammer=='scammer' else 'scammer', 'talk', 'right')
        return 'callcenter'
    if _has(low, 'wire', 'wired', 'zelle', 'western union', 'transfer') or \
            'bank transfer' in low:
        add(victim, 'give', 'left', emo='worried', give_dx=330, give_item='card')
        add(scammer, 'point', 'right', emo='sly')
        prop(obj='creditcard_01', x=1400, y=540, scale=1.6, t0=0.4, anim='pop')
        return 'wire'
    # ---- v4.5: motif dari narasi asli (5 scam terburuk) ----
    if 'step one' in low or 'step two' in low or 'quick recap' in low or \
            'recap before you go' in low:
        add('agent', 'gesture', 'left')                    # LANGKAH 1-2-3
        prop(obj='stepscard_01', x=1420, y=520, scale=1.6, t0=0.35, anim='pulse')
        return 'steps'
    if _has(low, 'virus', 'microsoft', 'tech support', 'pop up', 'pop-up',
            'popup', 'remote', 'control of your computer') or \
            'screen suddenly' in low:
        add('tech', 'point', 'left', emo='sly')            # HACKER BAYANGAN
        add(victim, 'talk', 'right', emo='worried')
        prop(obj='popalert_01', x=1420, y=520, scale=1.6, t0=0.4, anim='pulse')
        return 'virus'
    if _has(low, 'comment', 'subscribe', 'drop the number', 'send it to') and \
            not _has(low, 'lost', 'stole'):
        add('grandma', 'happy', 'left')                    # AJAKAN KOMEN
        prop(obj='commentbubble_01', x=1400, y=500, scale=1.5, t0=0.4, anim='pop')
        return 'comments'
    if _has(low, 'toll', 'text message', 'sms') or ('text' in low and 'phone' in low):
        if _has(low, 'highway', 'drove', 'toll road', 'license'):
            add(victim, 'walk', 'left', dx=420, w0=0.3)   # JALAN TOL
            prop(prop='car', x=1430, y=780, scale=1.45, t0=0.2, anim='pop')
            return 'tollroad'
        add(victim, 'talk', 'left', emo='worried')        # SMS TOL PALSU
        prop(prop='phone', x=340, y=470, scale=1.15, t0=0.05, anim='vibrate')
        prop(obj='phonechat_02', x=1430, y=520, scale=1.4, t0=0.4, anim='pop')
        return 'smstext'
    if _has(low, 'clone', 'cloned', 'sobbing', 'sounds exactly like',
            'voice clone', 'ai clones'):
        add(victim, 'phone', 'left', emo='sad')           # SUARA DIKLONING AI
        add('son', 'phone', 'right', emo='sad')
        prop(obj='waveform_01', x=960, y=430, scale=1.6, t0=0.4, anim='pulse')
        return 'voiceclone'
    if _has(low, 'billion', 'million', 'thousand', 'percent', '%') and \
            _has(low, 'ftc', 'fbi', 'irs', 'says', 'said', 'recorded', 'complaints',
                 'reported', 'reports', 'logged', 'tracked', 'investigators',
                 'losses', 'cost', 'count', 'jumped', 'total') and \
            not _has(low, 'gold', 'arrest', 'courier'):
        add('agent', 'gesture', 'left')                    # ANGKA STATISTIK
        prop(obj='mapusa_01' if 'states' in low else 'pollcard_01',
             x=1430, y=520, scale=1.5, t0=0.35, anim='pulse')
        return 'stats'
    if _has(low, 'imposter', 'impersonat', 'caller id', 'spoof'):
        add(victim, 'phone', 'left', emo='worried')        # CALLER-ID PALSU
        add(scammer, 'talk', 'right', emo='sly')
        prop(prop='monitor', x=1430, y=520, scale=1.5, t0=0.4, behind=True)
        return 'callerid'
    if 'courier' in low or 'doorbell' in low or _has(low, 'reference code') or \
            (_has(low, 'handed', 'handing over') and _has(low, 'box', 'envelope')):
        _gold = 'gold' in low
        add(victim, 'give', 'left',
            give_item='box' if _gold else 'bill', give_dx=330)   # KURIR DI PINTU
        add('courier', 'enter', 'right', pose='point')
        if _gold:
            prop(obj='goldbox_01', x=1180, y=560, scale=1.4, t0=0.4, anim='pop')
            return 'goldcourier'
        prop(obj='cashenvelope_01', x=1420, y=540, scale=1.5, t0=0.4, anim='pop')
        return 'courierdoor'
    if _has(low, 'arrest', 'arrested', 'caught two', 'police arrived',
            'handcuff', 'suspects'):
        add(scammer, 'stepback', 'left', emo='shock')      # PENANGKAPAN
        add('cop', 'enter', 'right', pose='point', emo='stern')
        prop(obj='handcuffs_01', x=1180, y=560, scale=1.3, t0=0.5, anim='pop')
        return 'arrest'
    if 'step one' in low or 'step two' in low or 'quick recap' in low or \
            'recap before you go' in low:
        add('agent', 'gesture', 'left')                    # LANGKAH 1-2-3
        prop(obj='stepscard', x=1420, y=520, scale=1.6, t0=0.35, anim='pulse')
        return 'steps'
    if _has(low, 'comment', 'subscribe', 'drop the number') and \
            not _has(low, 'lost', 'stole'):
        add('grandma', 'happy', 'left')                    # AJAKAN KOMEN
        prop(obj='commentbubble', x=1400, y=500, scale=1.5, t0=0.4, anim='pop')
        return 'comments'
    if _has(low, 'family', 'safe word', 'grandchild', 'wife', 'husband') and \
            not _has(low, 'lost', 'stole', 'fraud', 'drained',
                     'golden rule', 'hang up'):
        _oth = 'grandpa' if 'wife' in low else 'grandma'   # KELUARGA HANGAT
        add(victim, 'happy', 'left')
        add(_oth if victim != 'grandpa' else 'grandma', 'happy', 'right')
        prop(sprite='items/star', x=960, y=380, scale=2.6, t0=0.5, anim='float')
        return 'family'
    if _has(low, 'ssn', 'social security', 'medicare') or 'maiden name' in low:
        add(victim, 'talk', 'left', emo='worried')       # PENCURIAN IDENTITAS
        add(scammer, 'talk', 'right', emo='sly')
        prop(obj='ssncard_01', x=1400, y=540, scale=1.6, t0=0.4, anim='pop')
        return 'identity'
    if _has(low, 'delete', 'ignore', 'block', 'verify', 'hung') or \
       'hang up' in low or 'hangs up' in low or 'hung up' in low or \
       'call your bank' in low or 'call the bank' in low or 'call back' in low or \
       'do not' in low or "don't" in low:
        add(victim, 'point', 'left', emo='worried')
        prop(prop='blockphone' if 'block' in low else 'sign',
             x=1430, y=590, scale=1.4, t0=0.45, anim='pop')
        if 'slow' in low:
            prop(prop='clock', x=1120, y=540, scale=1.0, t0=0.9, anim='float')
        return 'hangup'
    if _has(low, 'protect', 'defense', 'defend', 'freeze', 'safe', 'shield',
            'prevent', 'smart'):
        add(victim, 'happy', 'left')
        prop(prop='shield', x=1330, y=600, scale=1.6, t0=0.4, anim='pulse')
        prop(prop='checklist', x=1580, y=660, scale=1.0, t0=0.9, anim='pop')
        return 'protect'
    # ---- v4.0: lokasi & genre baru ------------------------------------
    if _has(low, 'hospital', 'sick', 'emergency', 'ambulance', 'accident',
            'surgery', 'icu', 'injured', 'hurt', 'coma', 'medical'):
        add(victim, 'talk', 'left', emo='worried')
        add('doctor', 'talk', 'right')
        return 'hospital'
    if _has(low, 'court', 'judge', 'lawsuit', 'bail', 'testify', 'trial',
            'lawyer') or 'grand jury' in low:
        add(victim, 'talk', 'left', emo='worried')
        add('judge', 'point', 'right', emo='stern')
        return 'court'
    if _has(low, 'airport', 'flight', 'passport', 'visa', 'customs', 'luggage') or \
            'stuck abroad' in low or 'stuck in' in low or 'come home' in low:
        add(victim, 'talk', 'left', emo='worried')
        add('officer', 'talk', 'right')
        return 'airport'
    if _has(low, 'romance', 'lover', 'boyfriend', 'girlfriend', 'dating', 'fiance',
            'widower') or 'met online' in low or 'never met' in low or \
            'deployed' in low or 'stationed overseas' in low or 'online love' in low:
        add(victim, 'happy', 'left')
        add(scammer, 'phone', 'right', emo='sly')
        return 'romance'
    if _has(low, 'prize', 'lottery', 'jackpot', 'sweepstake', 'winner') or \
            'you won' in low or 'you have won' in low or 'won a' in low:
        add(victim, 'happy', 'left')
        add(scammer, 'point', 'right', emo='sly')
        prop(obj='trophy_01', x=1430, y=520, scale=1.5, t0=0.4, anim='pulse')
        return 'prize'
    if _has(low, 'identity theft', 'impersonate') or 'stole her identity' in low:
        add(victim, 'talk', 'left', emo='worried')
        add(scammer, 'talk', 'right', emo='sly')
        prop(obj='ssncard_01', x=1400, y=540, scale=1.6, t0=0.4, anim='pop')
        return 'identity'
    if _has(low, 'virus', 'infected', 'malware', 'ransomware', 'hacked',
            'tech support') or 'pop-up' in low or 'popup' in low \
            or 'pop up' in low or 'your computer' in low or 'screen suddenly' in low:
        add('tech', 'point', 'left', emo='sly')
        add(victim, 'talk', 'right', emo='worried')
        prop(obj='popalert_01', x=1420, y=520, scale=1.6, t0=0.4, anim='pulse')
        return 'virus'
    if _has(low, 'donate', 'donation', 'charity', 'relief', 'flood', 'hurricane',
            'wildfire', 'veterans'):
        add(victim, 'talk', 'left')
        add(scammer, 'talk', 'right', emo='sly')
        prop(obj='donationbox_01', x=1400, y=580, scale=1.5, t0=0.4, anim='pop')
        return 'charity'
    if _has(low, 'mall', 'store', 'shop', 'kiosk', 'checkout') or \
            'information desk' in low or 'front desk' in low:
        add(victim, 'talk', 'left')
        add('banker', 'talk', 'right')
        return 'mall'
    if any(k in low for k in ('phone', 'call', 'robocall', 'answer',
                              'hello', 'voicemail', 'caller')) or _has(low, 'ring', 'rings', 'rang') or 'rang her' in low:
        victim_actor = add(victim, 'talk', 'left', emo='worried')
        # animasi 2 fase: 1.4 dtk pertama lihat HP berdering -> angkat ke telinga
        victim_actor['phases'] = [(0.0, 1.4, 'phonecheck'), (1.4, dur, 'phone')]
        victim_actor['action'] = 'phased'
        prop(prop='phone', x=340, y=470, scale=1.15, t0=0.05, anim='vibrate')
        if any(k in low for k in ('scammer', 'stranger', 'caller', 'voice')):
            add(scammer, 'talk', 'right')
        return 'phone'
        # menelepon KELUARGA (bukan penipu)? → suasana hangat
        import re as _re
        scam_ctx = any(k in low for k in ('claimed', 'pretend', 'pretending', 'jail',
                                          'arrest', 'bail', 'scammer', 'stranger',
                                          'voice', 'robocall', 'caller'))
        fam = _re.search(r'\b(daughter|son|granddaughter|niece|nephew|family)\b', low)
        if fam and not scam_ctx:
            who = 'son' if fam.group(1) in ('son', 'nephew') else 'daughter'
            add(victim, 'phone', 'left', emo='happy')
            add(who, 'talk', 'right', emo='happy')
            return 'family-call'
        add(victim, 'phone', 'left', emo='worried')
        if any(k in low for k in ('scammer', 'stranger', 'caller', 'voice')):
            add(scammer, 'talk', 'right')
        return 'phone'
    if any(k in low for k in ('gift card', 'gift cards', 'card number')):
        add(victim, 'give', 'left', give_dx=330)
        add(scammer, 'point', 'right', emo='sly')
        prop(prop='giftcards', x=960, y=620, scale=1.35, t0=0.5, anim='pop')
        if 'number' in low or 'read' in low:
            prop(prop='card', x=1290, y=690, scale=0.95, t0=1.0, anim='float')
        return 'giftcards'
    if 'atm' in low:
        add(victim, 'shockhit', 'left', emo='shock')
        prop(prop='atm', x=1430, y=650, scale=1.4, t0=0.4, anim='pop')
        prop(sprite='items/coinGold', x=1180, y=560, scale=3.0, t0=0.6, anim='spin')
        return 'money'
    if _has(low, 'bitcoin', 'crypto', 'cryptocurrency', 'wallet', 'btc', 'coinbase') or 'bitcoin' in low:
        add(victim, 'talk', 'left', emo='worried'); add(scammer, 'talk', 'right', emo='sly')
        prop(prop='btc', x=960, y=620, scale=1.15, t0=0.5, anim='pulse')
        return 'crypto'
    if _has(low, 'recover', 'recovered', 'refund', 'filed') or \
       'got back' in low or 'money back' in low or 'report the' in low or 'file a' in low:
        add(victim, 'talk', 'left'); add(cop, 'talk', 'right')
        prop(sprite='items/flagRed', x=1560, y=560, scale=3.0, t0=0.5, anim='pulse')
        prop(prop='report', x=1290, y=660, scale=1.0, t0=0.9, anim='pop')
        return 'recovery'
    if any(k in low for k in ('$', 'wire', 'wired', 'transfer', 'wiring')) or \
       _has(low, 'dollar', 'dollars', 'billion', 'million', 'thousand', 'money',
            'savings', 'cash') or 'life savings' in low:
        if _has(low, 'within 24', '24 hours', '48 hours', 'one hour', 'final warning',
                'expires', 'deadline', 'immediately', 'or else', 'act now',
                'limited time', 'right now'):
            add(victim, 'shockhit', 'left', emo='shock')      # TEKANAN WAKTU + UANG
            prop(obj='timer_01', x=1430, y=500, scale=1.9, t0=0.35, anim='pulse')
            return 'urgency'
        add(victim, 'shockhit', 'left', emo='shock')
        if 'atm' in low:
            prop(prop='atm', x=1450, y=640, scale=1.4, t0=0.4, anim='pop')
            prop(sprite='items/coinGold', x=1180, y=560, scale=3.0, t0=0.5, anim='spin')
        else:
            prop(sprite='items/coinGold', x=1360, y=560, scale=3.4, t0=0.4, anim='spin')
            prop(sprite='items/weightChained', x=1560, y=640, scale=3.0, t0=dur*0.45, anim='drop')
        return 'money'
    if ('knock' in low or 'front door' in low or 'at the door' in low or
            'answer the door' in low or 'doorstep' in low or 'doorbell' in low):
        add(victim, 'talk', 'left', emo='worried')     # ADA ORANG DI PINTU
        if _has(low, 'police', 'officer', 'cop', 'cops', 'sheriff', 'agent'):
            add(cop, 'enter', 'right', pose='point', emo='stern')
        else:                                          # penipu/stranger datang sendiri
            add(scammer, 'enter', 'right', pose='point', emo='sly')
        return 'doorvisit'
    if _has(low, 'police', 'officer', 'sheriff', 'badge', 'cop', 'cops'):
        add(victim, 'talk', 'left')
        add(cop, 'enter', 'right', pose='point', emo='stern')
        return 'police'
    if _has(low, 'irs', 'tax', 'taxes', 'treasury') or 'owe back taxes' in low:
        add('irs', 'point', 'left', emo='stern'); add(victim, 'phone', 'right', emo='worried')
        return 'irs'
    if _has(low, 'fbi', 'agent', 'investigate', 'ic3', 'ftc') or 'task force' in low:
        add(victim, 'talk', 'left'); add('agent', 'talk', 'right', emo='stern')
        prop(sprite='items/star', x=1500, y=520, scale=3.0, t0=0.6, anim='pulse')
        return 'fbi'
    if _has(low, 'bank', 'banker', 'teller', 'branch') or 'fraud department' in low:
        add(victim, 'talk', 'left'); add('banker', 'talk', 'right')
        prop(prop='counter', x=960, y=880, scale=1.5, t0=0.3, behind=True)
        return 'bank'
    if _has(low, 'daughter', 'son', 'grandson', 'granddaughter', 'family',
            'niece', 'nephew', 'grandchild'):
        add('grandma', 'happy', 'left', emo='happy')
        add('daughter' if 'daughter' in low or 'family' in low else 'son', 'happy', 'right', emo='happy')
        prop(sprite='items/star', x=960, y=380, scale=2.6, t0=0.5, anim='float')
        return 'family'
    if _has(low, 'email', 'inbox', 'letter', 'envelope', 'mail'):
        add(victim, 'talk', 'left', emo='worried')
        prop(prop='mail', x=1250, y=560, scale=1.6, t0=0.4, anim='pop')
        return 'email'
    if _has(low, 'computer', 'screen', 'clicked', 'link', 'download', 'software') or \
       'pop-up' in low or 'remote access' in low or 'remote' in low:
        add('tech', 'point', 'left', emo='sly')
        prop(prop='laptop', x=1180, y=650, scale=1.5, t0=0.4, anim='pulse')
        return 'computer'
    if _has(low, 'cried', 'crying', 'tears', 'sad', 'devastated', 'heartbroken',
            'ashamed', 'depressed', 'broke down') or 'started to cry' in low:
        add(victim, 'talk', 'left', emo='sad')            # SEDIH: air mata
        prop(prop='wallet', x=1400, y=630, scale=1.1, t0=0.5, anim='float')
        return 'sad'
    if _has(low, 'danger', 'warning', 'illegal', 'crime', 'criminal', 'victims',
            'lost', 'stole', 'stolen'):
        add(victim, 'shockhit', 'left', emo='shock')
        prop(prop='sign', x=1420, y=580, scale=1.5, t0=0.35, anim='pulse')
        return 'danger'
    if _has(low, 'car', 'cars', 'vehicle', 'branch') or 'drove' in low or 'drive to' in low or 'in person' in low:
        add(victim, 'walk', 'left', dx=420, w0=0.3)
        prop(prop='car', x=1430, y=780, scale=1.45, t0=0.2, anim='pop')
        return 'car'
    if _has(low, 'ai', 'robot') or 'voice clone' in low or 'cloned' in low or 'artificial' in low:
        add(scammer, 'phone', 'left', emo='sly')
        prop(sprite='enemies/slimeWalk1', x=1380, y=560, scale=3.4, t0=0.5, anim='float')
        return 'ai'
    # netral — tetap mewakili: 2 tokoh bicara / 1 tokoh jalan
    r = spec.get('seed', 1) % 3
    if r == 0:
        add('grandma', 'talk', 'left'); add('scammer', 'talk', 'right', emo='sly')
    elif r == 1:
        add('grandma', 'talk', 'left')
        prop(sprite='items/star', x=1420, y=500, scale=2.6, t0=0.6, anim='float')
    else:
        add('grandma', 'walk', 'left', dx=420, w0=0.3)
    return 'neutral'

# ---------------- FURNIPACK: furnitur besar per adegan ------------
_FURNI_CACHE = {}
def _furni(name):
    if name in _FURNI_CACHE: return _FURNI_CACHE[name]
    import os as _os
    im = None
    for a in paths.ASSETS:
        p = _os.path.join(a, 'furnipack', name + '.png')
        if _os.path.exists(p):
            im = Image.open(p).convert('RGBA'); break
    _FURNI_CACHE[name] = im
    return im

# skema furnitur per motif: (nama, sisi(x), skala, belakang?)
_FURNI_SCHEMA = {
    'bank':      [('counter_wood', 960, 1.6, True), ('plantbig_teal', 200, 1.0, True),
                  ('chart_down', 1650, 1.0, False)],
    'callcenter':[('desk_navy', 350, 1.35, False), ('desk_dark', 990, 1.35, False),
                  ('pcdesk_dark', 1600, 1.2, True)],
    'office':    [('desk_wood', 960, 1.5, False), ('cabinet_gray', 1700, 1.0, True),
                  ('plantbig_olive', 170, 0.95, True)],
    'home':      [('rug_red', 960, 1.7, True), ('window_cream', 210, 1.25, True),
                  ('plantbig_olive', 1710, 1.0, True)],
    'police':    [('desk_dark', 1500, 1.3, False), ('courtbench_wood', 300, 1.1, True)],
    'money':     [('safebox_dark', 1500, 1.15, False), ('moneybag_cream', 250, 1.0, True),
                  ('chart_down', 1250, 0.9, False)],
    'recovery':  [('chart_up', 1500, 1.1, False), ('counter_navy', 500, 1.3, True)],
    'car':       [('carside_red', 960, 1.5, False), ('streetlamp_gray', 1700, 1.0, True)],
    'street':    [('streetlamp_gray', 250, 1.05, True), ('busstop_navy', 1650, 1.0, True)],
    'sad':       [('chair_wood', 1400, 1.0, False), ('window_cream', 300, 1.0, True)],
    'email':     [('desk_wood', 1250, 1.35, False), ('mailboxbig_navy', 250, 1.0, True)],
    'giftcards': [('desk_wood', 1250, 1.4, False), ('moneybag_cream', 260, 0.95, True)],
    'danger':    [('chart_down', 1550, 1.15, False), ('dumpster_teal', 260, 1.0, True)],
    'fbi':       [('courtbench_wood', 400, 1.05, True), ('desk_dark', 1450, 1.3, False)],
    'irs':       [('desk_dark', 960, 1.45, False), ('cabinet_gray', 1700, 0.95, True)],
    'ai':        [('pcdesk_dark', 1500, 1.25, False), ('tvstand_dark', 300, 1.0, True)],
    'computer':  [('pcdesk_dark', 1200, 1.35, False), ('cabinet_gray', 1720, 0.95, True)],
}
_FURNI_MOTIF = {
    'doorvisit':  [('door_wood', 960, 1.9, False), ('plantbig_teal', 210, 1.0, True),
                   ('rug_red', 560, 1.35, True)],
    'phone':      [('plantbig_teal', 200, 1.0, True), ('rug_navy', 960, 1.6, True)],
    'hangup':     [('plantbig_olive', 200, 1.0, True), ('rug_teal', 960, 1.6, True),
                   ('window_cream', 1740, 1.1, True)],
    'protect':    [('chart_up', 1560, 1.05, False), ('plantbig_olive', 210, 1.0, True)],
    'money':      [('safebox_dark', 1520, 1.15, False), ('moneybag_cream', 260, 1.0, True)],
    'atm':        [('atmbox_navy', 1500, 1.25, False), ('streetlamp_gray', 230, 1.0, True)],
    'giftcards':  [('desk_wood', 1250, 1.4, False), ('moneybag_cream', 260, 0.95, True)],
    'crypto':     [('pcdesk_dark', 1250, 1.3, False), ('safebox_gray', 260, 1.0, True)],
    'police':     [('desk_dark', 1480, 1.3, False), ('courtbench_wood', 300, 1.05, True)],
    'recovery':   [('counter_navy', 500, 1.3, True), ('chart_up', 1520, 1.1, False)],
    'bank':       [('counter_wood', 960, 1.6, True), ('plantbig_teal', 200, 1.0, True),
                   ('chart_down', 1650, 1.0, False)],
    'callcenter': [('desk_navy', 350, 1.35, False), ('desk_dark', 990, 1.35, False),
                   ('pcdesk_dark', 1600, 1.2, True)],
    'fbi':        [('courtbench_wood', 400, 1.05, True), ('desk_dark', 1450, 1.3, False)],
    'irs':        [('desk_dark', 960, 1.45, False), ('cabinet_gray', 1700, 0.95, True)],
    'home':       [('rug_red', 960, 1.7, True), ('window_cream', 210, 1.25, True),
                   ('plantbig_olive', 1710, 1.0, True)],
    'family':     [('rug_teal', 960, 1.7, True), ('tvstand_dark', 1730, 1.0, True)],
    'email':      [('desk_wood', 1250, 1.35, False), ('mailboxbig_navy', 250, 1.0, True)],
    'computer':   [('pcdesk_dark', 1200, 1.35, False), ('cabinet_gray', 1720, 0.95, True)],
    'ai':         [('pcdesk_dark', 1500, 1.25, False), ('tvstand_dark', 300, 1.0, True)],
    'danger':     [('chart_down', 1550, 1.15, False), ('dumpster_teal', 260, 1.0, True)],
    'car':        [('carside_red', 960, 1.5, False), ('streetlamp_gray', 1700, 1.0, True)],
    'street':     [('streetlamp_gray', 250, 1.05, True), ('busstop_navy', 1650, 1.0, True)],
    'sad':        [('chair_wood', 1400, 1.0, False), ('window_cream', 300, 1.0, True)],
    'prize':      [('moneybag_cream', 1450, 1.1, False), ('chart_up', 1150, 0.95, False)],
}
_FURNI_KEYS = {
    'bank': ('bank', 'teller', 'branch', 'fraud department', 'account', 'savings'),
    'callcenter': ('call center', 'callcentre', 'boiler room', 'cubicle', 'office'),
    'home': ('at home', 'her home', 'his home', 'house', 'kitchen', 'living room'),
    'police': ('police', 'officer', 'sheriff', 'arrest', 'jail', 'warrant', 'crime'),
    'money': ('$', 'dollar', 'thousand', 'million', 'billion', 'gift card',
              'wire', 'transfer', 'cash', 'savings'),
    'recovery': ('recover', 'refund', 'got back', 'money back', 'reported the'),
    'car': ('car', 'drove', 'drive', 'van'),
    'street': ('street', 'outside', 'walk', 'park', 'road', 'knock', 'door'),
    'sad': ('cried', 'tears', 'sad', 'ashamed', 'devastated'),
    'email': ('email', 'letter', 'envelope', 'mail', 'inbox'),
    'giftcards': ('gift card', 'card number'),
    'danger': ('danger', 'warning', 'stole', 'stolen', 'lost'),
    'fbi': ('fbi', 'agent', 'investigate', 'ic3', 'ftc'),
    'irs': ('irs', 'tax', 'treasury'),
    'ai': ('ai', 'robot', 'voice clone', 'cloned'),
    'computer': ('computer', 'screen', 'clicked', 'link', 'download', 'remote'),
}

def _furni_for(motif, low, idx):
    sk = _FURNI_MOTIF.get(motif) or SKEMA_V40.get(motif) or _FURNI_SCHEMA.get(motif)
    if sk is None:
        sk = None
    if sk is None:                       # motif belum ada skemanya -> cocokkan kata
        for th, keys in _FURNI_KEYS.items():
            if th in _FURNI_MOTIF and any(k in low for k in keys):
                sk = _FURNI_MOTIF[th]; break
    if sk is None:                       # netral: deko ruangan umum, bervariasi
        sk = [('plantbig_olive', 210, 1.0, True), ('rug_navy', 960, 1.6, True),
              ('window_cream', 1720, 1.1, True)][:(2 + idx % 2)]
    # rotasi warna HANYA ke varian yang benar2 ada (kalau tidak, nama asli)
    import re as _re
    warna = ['wood', 'dark', 'navy', 'teal', 'olive', 'red', 'gray', 'cream', 'pink']
    out = []
    for k, (n, x, sc, b) in enumerate(sk):
        m = _re.search(r'_(wood|dark|navy|teal|olive|red|gray|cream|pink)$', n)
        if m:
            base = n.rsplit('_', 1)[0]
            mulai = warna.index(m.group(1))
            for j in range(len(warna)):
                cand = base + '_' + warna[(mulai + idx + k + j) % len(warna)]
                if _furni(cand) is not None:
                    n = cand; break
        if _furni(n) is None and '_' not in n:      # v4.0: nama polos -> cari varian
            for w in warna:
                if _furni(n + '_' + w) is not None:
                    n = n + '_' + w; break
        if _furni(n) is None:                       # tetap tak ada -> lewati
            continue
        out.append(dict(furni=n, x=x, scale=sc, behind=b, anim='none'))
    return out

# ---------------- ELEMEN HIDUP: burung, awan, layar, uang ----------
def _living(img, spec, now, rng):
    low = (spec.get('fulltext', '') or '').lower()
    outdoor = spec.get('bg') not in ('home', 'office', 'bank')
    d = ImageDraw.Draw(img, 'RGBA')
    # awan bergerak pelan (selalu)
    c1 = _sprite('bg/background_cloudA')
    if c1 is not None:
        c1 = c1.resize((int(c1.width*1.6), int(c1.height*1.6)))
        c1.putalpha(c1.getchannel('A').point(lambda v: int(v*0.30)))
        cx1 = int((now*22 + spec.get('seed', 7)*80) % (W + 500)) - 250
        img.paste(c1, (cx1, 90), c1)
    if outdoor:
        im2 = _sprite('bg/background_cloudB')                 # awan kedua (lawan arah)
        if im2 is not None:
            im2 = im2.resize((int(im2.width*1.1), int(im2.height*1.1)))
            im2.putalpha(im2.getchannel('A').point(lambda vv: int(vv*0.26)))
            cx2 = int(W - ((now*31 + spec.get('seed', 7)*55) % (W + 400))) + 200
            img.paste(im2, (cx2, 200), im2)
        # v4.7: tanpa satwa (burung/kupu-kupu dihapus total — masukan user)
    # layar komputer/TV berkedip kalau ada prop laptop/monitor/pcdesk
    for p in spec.get('props', []):
        if p.get('prop') in ('laptop', 'monitor') or str(p.get('furni', '')).startswith('pcdesk'):
            pass
    # ---- v4.0: FX uang — KERUGIAN (koin terbang keluar + X merah)
    #                 PEMULIHAN (koin masuk + centang hijau)
    m_money = _RE_MONEY.search(low)
    m_loss = _RE_LOSS.search(low)
    m_gain = _RE_GAIN.search(low)
    coin = _sprite('items/coinGold')
    cimg = coin.resize((int(coin.width*1.05), int(coin.height*1.05))) if coin else None
    if m_money and m_loss and not m_gain and cimg is not None:
        ph = min(1.0, now/max(0.8, float(spec.get('dur', 8))*0.55))
        for k in range(4):
            e = min(1.0, max(0.05, ph*1.3 - k*0.10))
            fx = int(760 + k*150 + math.sin(now*1.3 + k*2)*30)
            fy = int(700 - e*640)
            a = cimg.copy()
            a.putalpha(a.getchannel('A').point(lambda vv: int(vv*(0.25+0.75*e))))
            img.paste(a, (fx, fy), a)
        if ph >= 0.5:
            s = 46 + int(5*math.sin(now*6))
            d.line([1530-s, 430-s, 1530+s, 430+s], fill=(214, 60, 60, 235), width=32)
            d.line([1530+s, 430-s, 1530-s, 430+s], fill=(214, 60, 60, 235), width=32)
    elif m_money and m_gain and not m_loss and cimg is not None:
        ph = min(1.0, now/max(0.8, float(spec.get('dur', 8))*0.5))
        for k in range(4):
            e = ph - k*0.09
            if 0.02 < e < 1.0:
                fx = int(660 + k*160 + (1-e)*120)
                fy = int(140 + e*560)
                a = cimg.copy()
                a.putalpha(a.getchannel('A').point(lambda vv: int(vv*(0.3+0.7*e))))
                img.paste(a, (fx, fy), a)
        if ph >= 0.5:
            d.line([1400, 470, 1470, 540], fill=(52, 160, 92, 235), width=32)
            d.line([1470, 540, 1610, 380], fill=(52, 160, 92, 235), width=32)
    elif m_money and cimg is not None:      # tema uang biasa: koin melayang
        for k in range(4):
            fx = 1100 + k*130 + int(math.sin(now*1.4 + k*2)*40)
            fy = int(150 + ((now*95 + k*160) % 620))
            img.paste(cimg, (fx, fy), cimg)
    # v4.3: daun gugur saat senja/parkir senja
    if str(spec.get('bg', '')).startswith(('dusk', 'parkdusk')):
        for k in range(4):
            lx = int((spec.get('seed', 7)*97 + k*420 + now*(26+k*7)) % (W+160)) - 80
            ly = 150 + int((now*(55+k*11) + k*260) % 700)
            sw = math.sin(now*2.2 + k)*26
            d.ellipse([lx+sw-7, ly, lx+sw+7, ly+12], fill=(214, 170, 96, 190))
            d.line([lx+sw, ly+2, lx+sw, ly+10], fill=(160, 120, 60, 160), width=2)
    # v4.3: kilau untuk adegan hadiah/lotre
    if str(spec.get('motif', '')).split('-')[0] in ('prize', 'lottery'):
        for k in range(5):
            sx = 1150 + (k*137) % 420
            sy = 150 + (k*89) % 240
            tw = (math.sin(now*5 + k*1.9) + 1) / 2
            r = 4 + 9*tw
            col = (255, 226, 130, int(90 + 150*tw))
            d.line([sx-r, sy, sx+r, sy], fill=col, width=4)
            d.line([sx, sy-r, sx, sy+r], fill=col, width=4)
    # ---------------- v4.4: KEHIDUPAN LATAR per jenis adegan ----------------
    bgname = str(spec.get('bg', ''))
    # jendela gedung menyala-berganti (kota senja)
    if bgname.startswith('dusk'):
        sd2 = int(spec.get('seed', 7))
        for k in range(7):
            wx = 60 + (sd2*131 + k*283) % 1760
            wy = 470 + (k*173 + sd2*37) % 330
            if math.sin(now*0.9 + k*2.1) > 0.15:
                d.rectangle([wx, wy, wx+26, wy+36], fill=(255, 214, 130, 110))
    # layar PC berkedip lembut (kantor / call center)
    for f in spec.get('furni', []):
        if str(f.get('furni', '')).startswith('pcdesk'):
            fx2 = int(f.get('x', 900))
            a2 = 26 + int(18*(0.5 + 0.5*math.sin(now*13 + fx2)))
            d.rectangle([fx2-52, GROUND-332, fx2+58, GROUND-208],
                        fill=(150, 190, 240, a2))
    # garis ECG berjalan di rumah sakit (monitor detak jantung)
    if str(spec.get('motif', '')).split('-')[0] == 'hospital':
        bx2, by2 = 900, 548
        ph3 = (now*1.5) % 1.0
        for i in range(24):
            t0 = i/24
            px2 = bx2 + t0*190
            spike = max(0.0, 1.0 - abs(t0 - 0.45)*9)
            py2 = by2 - spike*48
            al = 210 if abs(t0 - ph3) < 0.10 else 90
            d.line([px2, py2, px2+9, py2], fill=(80, 200, 130, al), width=4)
    # hujan tipis di adegan sedih
    if str(spec.get('motif', '')).split('-')[0] == 'sad' or 'cried' in low:
        for k in range(26):
            rx = (int(spec.get('seed', 7))*151 + k*137 + int(now*300)) % (W + 80) - 40
            ry = (k*211 + int(now*430)) % 880
            d.line([rx, ry, rx-9, ry+24], fill=(120, 150, 200, 70), width=2)
    # lampu mobil lewat sesekali (jalan / senja / adegan mobil)
    if bgname.startswith(('dusk', 'street')) or 'car' in str(spec.get('motif', '')):
        cyc = now % 7.0
        if 4.6 < cyc < 6.4:
            p4 = (cyc - 4.6) / 1.8
            sx4 = int(-260 + p4*(W + 620))
            for j in range(5):
                al4 = int(150 - j*26)
                d.ellipse([sx4-j*52, GROUND-104, sx4-j*52+18, GROUND-86],
                          fill=(255, 250, 210, al4))
            d.line([sx4-40, GROUND-96, sx4+8, GROUND-96], fill=(255, 244, 190, 90), width=6)
    # debu melayang di berkas cahaya pengadilan
    if str(spec.get('motif', '')).split('-')[0] == 'court':
        for k in range(9):
            mx = (int(spec.get('seed', 7))*97 + k*211 + int(now*11)) % 1780 + 70
            my = 210 + (k*137 + int(now*6)) % 430
            d.ellipse([mx, my, mx+4, my+4], fill=(240, 230, 200, 60))

# ---------------- publik API (sama seperti kenney.py) ------------
BG_BY_MOTIF = {'bank': 'office', 'callcenter': 'office', 'car': 'street',
               'family': 'home', 'family-call': 'home', 'email': 'home',
               'police': 'trees', 'fbi': 'trees', 'recovery': 'trees'}

# ---------------- v4.0: skema furni, latar & kata utk lokasi baru ------------
SKEMA_V40 = {
    'hospital':  [('hospitalbed', 400, 1.75, True), ('bedside', 980, 1.05, False),
                  ('ivstand', 1320, 1.0, False)],
    'court':     [('judgebench', 1180, 1.7, True), ('witnessbox', 350, 1.15, False),
                  ('railing', 1650, 1.0, True)],
    'airport':   [('depseats', 380, 1.25, True), ('depboard', 1300, 1.7, False),
                  ('railing', 1750, 0.9, True)],
    'mall':      [('shopcounter', 700, 1.5, True), ('shelfgoods', 1480, 1.45, True)],
    'romance':   [('flowerstand', 180, 1.2, True), ('heartballoon', 960, 1.15, False),
                  ('railing', 1600, 1.0, True)],
    'prize':     [('shopcounter', 1650, 1.4, True)],
    'lottery':   [('shopcounter', 1650, 1.4, True)],
    'charity':   [('flowerstand', 190, 1.1, True)],
    'identity':  [('desk_navy', 960, 1.5, True)],
    'virus':     [('pcdesk_dark', 900, 1.6, True)],
    'urgency':   [('roundtable_teal', 1500, 1.1, True)],
    'wire':      [('counter_navy', 960, 1.5, True)],
    # ---- v4.5: dari analisis narasi asli (5 scam terburuk) ----
    'smstext':   [('roundtable', 480, 1.2, True), ('window', 1660, 1.05, True)],
    'tollroad':  [('tollbooth', 1400, 1.7, True), ('railing', 420, 1.0, True)],
    'voiceclone':[('rug', 960, 1.5, True)],
    'stats':     [('chart_up', 1360, 2.0, True)],
    'callerid':  [('pcdesk', 960, 1.55, True)],
    'courierdoor':[('door', 960, 1.9, False), ('plantbig', 210, 1.0, True),
                   ('rug', 560, 1.35, True)],
    'goldcourier':[('goldcrate', 740, 1.5, True), ('door', 1480, 1.6, False)],
    'arrest':    [('gate', 1520, 1.5, True)],
    'steps':     [('desk', 960, 1.4, True)],
    'comments':  [('roundtable', 1480, 1.15, True)],
}
BG_V40 = {'hospital': 'hospital', 'court': 'court', 'airport': 'airport',
          'mall': 'mall', 'romance': 'dusk', 'prize': 'store', 'lottery': 'store', 'charity': 'street',
          'smstext': 'home', 'tollroad': 'highway', 'voiceclone': 'home',
          'stats': 'news', 'callerid': 'office', 'courierdoor': 'home',
          'goldcourier': 'home', 'arrest': 'street', 'steps': 'news', 'comments': 'home',
          'wire': 'office', 'identity': 'office', 'virus': 'office', 'urgency': 'home'}
# tema objek ambien baru (kata -> pool objek objpack)
_THEME_KEYS.update({'medical': ('hospital', 'sick', 'doctor', 'emergency', 'ambulance',
                                'surgery', 'medicine'),
                    'legal': ('court', 'judge', 'lawsuit', 'bail', 'jail', 'arrest',
                              'testify', 'prison'),
                    'travel': ('airport', 'flight', 'passport', 'abroad', 'visa', 'luggage'),
                    'urgency': ('urgent', 'immediately', 'deadline', 'final warning',
                                'expires', 'hours')})
_THEME_POOLS.update({'medical': ['medkit_01', 'medkit_02', 'syringe_01', 'crutch_01',
                                 'pill_01', 'medkit_03'],
                     'legal': ['gavel_01', 'gavel_02', 'handcuffs_01', 'handcuffs_02',
                               'papersfly_01'],
                     'travel': ['passport_01', 'passport_02', 'suitcase_01',
                                'suitcase_02', 'suitcase_03'],
                     'urgency': ['timer_01', 'timer_02', 'timer_03', 'stamp_01', 'stamp_02'],
                     'romance': ['roses_01', 'roses_02', 'phonechat_01', 'phonechat_02',
                                 'roses_03', 'confetti_01']})
_THEME_POOLS['money'] = list(_THEME_POOLS.get('money', [])) + [
    'creditcard_01', 'ssncard_01', 'goldbar_01', 'moneyfly_01', 'walletcoins_01', 'bigcheck_01']
# regex FX kerugian/pemulihan (uang keluar vs uang kembali)
_RE_MONEY = re.compile(r'(\$|\bdollars?\b|\bmoney\b|\bthousand\b|\bmillion\b|\bbillion\b|\bsavings\b)')
_RE_LOSS = re.compile(r'\b(lost|lose|loses|losing|stole|stolen|wired|transferred|sent|gave|paid|took|drained)\b')
_RE_GAIN = re.compile(r'(refund|refunded|recovered|reimbursed|got .{0,16}?back|money back|unfroze|reversed)')

def auto_scene(text, dur, idx, avoid=None, two_actors=None):
    if isinstance(avoid, str):
        avoid = [avoid]
    avoid = list(avoid or [])
    low = (text or '').lower()
    spec = {'dur': dur, 'seed': idx*13 + 5, 'actors': [], 'props': [], 'captions': []}
    motif = _try_custom(low, spec, dur)      # kamus user dulu (prioritas)
    if motif is None:
        motif = _motif(low, spec, dur)
    # ---- VARIASI WAJIB: motif yang barusan dipakai diberi visual BERBEDA ----
    if motif in avoid:
        if motif == 'phone':                 # jangan HP lagi: ganti adegannya
            spec['props'] = [p for p in spec['props'] if p.get('prop') != 'phone']
        if spec['actors']:
            a0 = spec['actors'][0]
            if a0.get('action') in ('talk', 'phased', 'stand', None, 'phone'):
                mode = idx % 3
                if mode == 0:
                    a0['action'] = 'shockhit'; a0['emo'] = 'shock'
                elif mode == 1:
                    a0['action'] = 'talk'
                    if not a0.get('emo'): a0['emo'] = 'worried'
                else:
                    a0['action'] = 'walk'; a0.update(dx=180, w0=0.2)
        pool = [('house', 170, 880, 1.5, True), ('car', 190, 856, 1.2, True),
                ('laptop', 960, 660, 1.0, False), ('mail', 960, 640, 1.0, False),
                ('monitor', 960, 620, 0.95, False), ('wallet', 960, 650, 1.0, False)]
        pname, px_, py_, psc_, pbeh = pool[idx % len(pool)]
        spec['props'].append(dict(prop=pname, x=px_, y=py_, scale=psc_,
                                  t0=0.3, anim='pop', behind=pbeh))
    mb = motif.split('-')[0]
    if any(k in low for k in ('at home', 'her home', 'his home', 'house', 'kitchen', 'living room')):
        spec['bg'] = 'home'
    elif mb in BG_BY_MOTIF:
        spec['bg'] = BG_BY_MOTIF[mb]
    elif mb in BG_V40:                      # v4.0: latar lokasi (RS, pengadilan, dll)
        spec['bg'] = BG_V40[mb]
    else:                                   # 100 resep bgpack, beda tiap klip
        spec['bg'] = bgpack.pick(mb, idx, avoid=None)
    spec['ambient'] = _ambient_names(idx*13 + 5,
                                     indoor=spec['bg'] in ('home', 'office') or str(spec['bg']).startswith(('hospital', 'court', 'airport', 'mall', 'store', 'clinic', 'lobby')),
                                     low=low)
    spec['fulltext'] = low
    spec['furni'] = _furni_for(motif, low, idx)
    # motif berulang? ganti varian netral biar visual bervariasi
    # (kecuali motif "mahal": callcenter/police/bank/family/fbi boleh berulang)
    if motif == avoid and motif not in ('callcenter', 'police', 'bank', 'family', 'fbi'):
        spec['actors'].clear(); spec['props'].clear()
        r = idx % 3
        sd = int(spec.get('seed', 1))
        vic = VICTIMS[sd % len(VICTIMS)]; scm = SCAMMERS[sd % len(SCAMMERS)]
        if r == 0:
            spec['actors'].append(dict(who=scm, action='talk', side='left',
                                       x=620, flip=False, emo='sly'))
            spec['actors'].append(dict(who=vic, action='phone', side='right',
                                       x=1310, flip=True, emo='worried'))
        elif r == 1:
            spec['actors'].append(dict(who=vic, action='walk', side='left',
                                       x=520, flip=False, dx=420, w0=0.3))
            spec['props'].append(dict(sprite='items/star', x=1500, y=560,
                                      scale=2.8, t0=0.6, anim='float'))
        else:
            spec['actors'].append(dict(who='cop', action='talk', side='left',
                                       x=620, flip=False, emo='stern'))
            spec['props'].append(dict(sprite='items/flagRed', x=1450, y=580,
                                      scale=3.0, t0=0.5, anim='pulse'))
        motif = motif + '-alt'
    if motif.split('-')[0] in ('callcenter', 'bank'):
        spec['bg'] = 'office'
    spec['motif'] = motif
    return spec

def render_spec_frame(spec, now):
    rng = random.Random(int(spec.get('seed', 7)) + int(now*100))
    img = _bg(spec.get('bg', 'plain'), spec.get('seed', 7)).copy()
    # ---- v4.3: PENEMPATAN BEBAS TUMPUK (dihitung sekali per adegan) ----
    if '_amb_pos' not in spec:
        occ = []
        for a in spec.get('actors', []):         # v4.4: TOKOH = zona suci, jangan ditutupi
            occ.append((float(a.get('x', 620)) - 185, float(a.get('x', 620)) + 185))
        for f in spec.get('furni', []):
            imf = _furni(f.get('furni', ''))
            if imf is None: continue
            if str(f.get('furni', '')).startswith('rug'): continue   # karpet = alas
            w_ = imf.width * float(f.get('scale', 1.3))
            xc_ = float(f.get('x', 960))
            occ.append((xc_ - w_/2, xc_ + w_/2))
        for p in spec.get('props', []):          # prop menghindari furnitur
            src_ = None
            try:
                if p.get('sprite'): src_ = _sprite(p['sprite'])
                elif p.get('obj'): src_ = _objfull(p['obj'])
                elif p.get('prop'): src_ = cast.prop(p['prop'])
            except Exception:
                src_ = None
            hw_ = (src_.width * float(p.get('scale', 1.6)) / 2) if src_ is not None \
                else 170 * float(p.get('scale', 1.6)) / 1.6
            xp_ = float(p.get('x', 1450))
            def _tabrak(xq, hw=hw_):
                return not all(xq + hw < a0 - 30 or xq - hw > a1 + 30 for a0, a1 in occ)
            if _tabrak(xp_):                     # sapu kiri→kanan cari lubang
                for cx in range(14, int(W - hw_) - 14, 30):
                    if not _tabrak(cx):
                        xp_ = cx; break
            xp_ = max(hw_ + 12, min(W - hw_ - 12, xp_))
            p['x'] = int(xp_)
            if _tabrak(xp_):                     # v4.4: tak ada slot -> di BELAKANG tokoh
                p['behind'] = True
            occ.append((xp_ - hw_, xp_ + hw_))
        for p in spec.get('props', []):          # v4.4: prop besar di tengah jangan tutupi tokoh
            try:
                if not p.get('behind') and 700 < float(p.get('x', 1450)) < 1250 \
                        and float(p.get('scale', 1.0)) >= 1.1:
                    p['behind'] = True
            except Exception:
                pass
        slots3 = [150, 390, 640, 1280, 1530, 1770, 60, 1860, 900, 1120]
        arng2 = random.Random(int(spec.get('seed', 7)) * 7 + 3)
        arng2.shuffle(slots3)
        posisi = []
        amb2 = list(spec.get('ambient', []))[:3 + (2 if not spec.get('furni') else 0)]
        for name in amb2:
            im = _obj_sprite(name)
            if im is None: continue
            w_ = im.width * 1.3
            for cx in slots3:
                if all(cx + w_/2 < a0 - 26 or cx - w_/2 > a1 + 26 for a0, a1 in occ):
                    posisi.append((name, cx))
                    occ.append((cx - w_/2, cx + w_/2))
                    break
        spec['_amb_pos'] = posisi
    for name, cx in spec.get('_amb_pos', []):
        im = _obj_sprite(name)
        if im is None: continue
        im = im.resize((int(im.width*1.3), int(im.height*1.3)), Image.LANCZOS)
        img.paste(im, (int(cx - im.width/2), GROUND - im.height + 8), im)
    for p in spec.get('props', []):
        if p.get('behind'): _prop(img, p, now, spec['dur'])
    for f in spec.get('furni', []):                    # FURNITUR BESAR
        im = _furni(f.get('furni', ''))
        if im is None: continue
        sc = float(f.get('scale', 1.3))
        big = im.resize((int(im.width*sc), int(im.height*sc)), Image.LANCZOS)
        big.putalpha(big.getchannel('A').point(lambda v: int(v*0.97)))
        fx = int(f.get('x', 960)); gy = GROUND - 6
        img.paste(big, (fx - big.width//2, gy - big.height), big)
    actors = spec.get('actors', [])
    for j, a in enumerate(actors):
        a.setdefault('speaker', j == 0)
    for j, a in enumerate(actors):
        env = spec.get('env') if a.get('speaker') else None
        _actor(img, a, now, spec['dur'], env=env,
               env_fps=spec.get('env_fps', 12),
               env_off=spec.get('env_off', 0.0) if env else 0.0)
    for p in spec.get('props', []):
        if not p.get('behind'): _prop(img, p, now, spec['dur'])
    _living(img, spec, now, rng)                      # burung, awan, uang, dsb.
    if spec.get('plus'):
        # v4.7: KAMERA STATIS — tanpa zoom/goyang/flash (masukan user: nyaman ditonton).
        # Hanya fade masuk/keluar lembut di ujung klip; latar & karakter tidak bergerak
        # kecuali animasi tokoh/prop sendiri.
        if now < 0.35:
            v = 0.5 + 0.5*(now/0.35)
        elif now > spec['dur']-0.3:
            v = 0.55 + 0.45*min(1.0, (spec['dur']-now)/0.3)
        else:
            v = 1.0
        if v < 0.999:
            from PIL import ImageEnhance
            img = ImageEnhance.Brightness(img).enhance(v)
    for a in spec.get('actors', []):          # FX KEJUT: seru + garis radial
        if a.get('action') == 'shockhit' and now > spec['dur']*0.5 and a.get('_head'):
            hx, hy, sc_ = a['_head']
            if a.get('x', 620) > W*0.55:      # aktor kanan: seru di kiri kepala
                bxoff = -150
            else:                             # aktor kiri: seru di kanan kepala
                bxoff = 150
            e = min(1.0, (now - spec['dur']*0.5) / 0.25)
            dd = ImageDraw.Draw(img, 'RGBA')
            for k in range(5):                # garis kejut merah sekitar kepala
                ang = math.radians(-160 + k*32)
                r0 = (86 + 14*(k % 2))*sc_*(0.7 + 0.3*e)
                r1 = r0 + 46*sc_*e
                dd.line([hx + r0*math.cos(ang), hy + r0*math.sin(ang),
                         hx + r1*math.cos(ang), hy + r1*math.sin(ang)],
                        fill=(224, 32, 32, int(210*e)), width=max(4, int(8*sc_)))
            bx = hx + bxoff*sc_*0.62                              # lebih dekat kepala
            by = hy - 95*sc_
            wbar = 16*sc_
            dd.rounded_rectangle([bx-wbar, by-70*sc_, bx+wbar, by+18*sc_],
                                 radius=int(10*sc_), fill=(255, 197, 61, int(255*e)),
                                 outline=(30, 34, 58, int(255*e)), width=max(2, int(4*sc_)))
            dd.ellipse([bx-wbar, by+34*sc_, bx+wbar, by+34*sc_+2*wbar],
                       fill=(255, 197, 61, int(255*e)), outline=(30, 34, 58, int(255*e)),
                       width=max(2, int(4*sc_)))
    for (c0, c1, text) in spec.get('captions', []):
        if c0 <= now < c1 and text:
            prog = (now - c0) / max(0.01, c1 - c0)
            style = kinetic.pick_style(text, int(c0*10) + spec.get('seed', 7))
            img = kinetic.draw_chunk(img, text, style, prog)
    return img

def render_scene(spec, fps=12, fdir='frames_s'):
    os.makedirs(fdir, exist_ok=True)
    n = max(2, int(round(spec['dur'] * fps)))
    out = []
    for i in range(n):
        p = os.path.join(fdir, f'f{i:03d}.png')
        render_spec_frame(spec, i/fps).save(p)
        out.append(p)
    return out

if __name__ == '__main__':
    tests = [
        ("Her phone rang. The caller said her bank account was compromised.", 8.0, 1),
        ("He asked her to buy gift cards and read the card numbers.", 8.0, 2),
        ("She reported the scam to the police and the FBI the next morning.", 8.0, 3),
        ("Hang up, call your bank, and protect your savings.", 8.0, 4),
    ]
    sheet = Image.new('RGB', (960, 540*len(tests)))
    for i, (t, dur, idx) in enumerate(tests):
        s = auto_scene(t, dur, idx)
        caps = smartsub.smart_captions(t, dur)
        s['captions'] = [[c[0], c[1], c[2]] for c in caps]
        fr = render_spec_frame(s, min(3.0, dur/2))
        print(idx, s['motif'], [c[2] for c in caps])
        sheet.paste(fr.resize((960, 540)), (0, i*540))
    sheet.save('stage_sheet.jpg', quality=88)
    print('-> stage_sheet.jpg')
