#!/usr/bin/env python3
# ============================================================
#  SMARTSUB — subtitle animasi HANYA dari kata-kata penting
#  Sesuai permintaan: kalimat panjang tidak ditampilkan utuh;
#  sistem mendeteksi frasa inti (angka/uang/kata kunci penipuan)
#  dan menampilkannya saat kata itu "diucapkan" (timing proporsional
#  panjang kalimat di segmen audio).
# ============================================================
import re

# kata berbobot tinggi (topik channel: penipuan telepon AS 55+)
KEY = (
    # ancaman/modus
    'scam|scammer|fraud|fake|steal|stole|stolen|lied|lie|trick|threat|arrest|'
    'warrant|suspended|illegal|criminal|charges|lawsuit|prison|deport|'
    # alat
    'gift card|gift cards|wire|transfer|bitcoin|crypto|cash|app|'
    'bank|account|password|pin|ssn|social security|card number|routing|'
    'verification code|otp|remote|access|download|software|'
    # aktor
    'police|officer|fbi|sheriff|irs|agent|detective|social security administration|'
    'banker|treasury|hacker|caller|robocall|call center|grandson|granddaughter|'
    # tindakan pertahanan
    'hang up|hangs up|call back|callback|verify|report|reported|reporting|freeze|'
    'block|delete|ignore|slow down|ask|family code|code word|protect|safe'
)
_KEY_RE = re.compile(r'\b(' + KEY + r')\b', re.I)
_NUM_RE = re.compile(r'(\$?\d[\d,.]*\s*(billion|million|thousand|hundred|dollars?|usd|percent|%)?)', re.I)
_STOP = set('''a an the and or but so if then of to in on at for with by from as is are was
were be been being do does did have has had will would can could should may might must
this that these those it its he she they them his her their you your i we our us me my
not no yes up down out over under about into than very just really only even also there
here when where while what which who whom how why all any both each few more most other
some such own same too s t don didn wasn't won't can't gonna gonna'''.split())

def _score(word):
    w = word.strip('.,!?;:"\'').lower()
    if not w: return 0
    s = 0
    if _KEY_RE.fullmatch(w) or _KEY_RE.fullmatch(word.strip('.,!?;:"\'')):
        s += 3
    if re.search(r'\d', w) or '$' in w: s += 3
    if w not in _STOP and len(w) >= 5: s += 1
    if w in ('never', 'always', 'stop', 'wait', 'slow'): s += 2
    return s

def clauses(text):
    """pecah kalimat jadi klausa (koma/titik/konjungsi)"""
    parts = re.split(r'(?<=[,.;:!?])\s+|\s+(?=\b(?:but|and then|because|so that|so|or)\b)\s+', text.strip())
    return [p.strip() for p in parts if p.strip()]

def anchors(text, max_len=46):
    """kembalikan list (idx_kata_global, frasa) yang penting dalam kalimat"""
    words = text.split()
    out, i = [], 0
    while i < len(words):
        w = words[i]
        # coba 3-kata: gift card(s)/social security/code word/dll
        for n in (3, 2, 1):
            seg = ' '.join(words[i:i+n]).strip('.,!?;:')
            if seg and (_KEY_RE.fullmatch(seg) or _NUM_RE.fullmatch(seg)):
                out.append((i, seg)); i += n; break   # match regex = pasti penting
        else:
            if _score(w) >= 3:      # kata tunggal krusial (never/stop/angka/dll)
                frag = w.strip('.,!?;:')
                if frag: out.append((i, frag))
            i += 1
    return out

def _score_n(frag):
    return sum(_score(x) for x in frag.split())

def smart_captions(text, dur, lead=0.25, tail=0.20):
    """
    text  : teks penuh segmen (yang diucapkan audio)
    dur   : durasi audio segmen (detik)
    return: list [t0, t1, chunk] — timing memperkirakan posisi
            pengucapan (proporsional panjang karakter), HANYA frasa penting.
    """
    if not text or dur <= 0: return []
    text = re.sub(r'\s*-{2,}\s*', ' ', text).strip()
    if not text: return []
    words = text.split()
    if not words: return []
    total_chars = sum(len(w) + 1 for w in words)
    speak = max(0.5, dur - lead - tail)
    anns = anchors(text)
    if not anns:
        # kalimatnya sendiri penting walau tanpa kata kunci? → ambil klausa pertama
        cl = clauses(text)[0]
        ws = cl.split()
        frag = ' '.join(ws[:4]).strip('.,!?;:')
        i = words.index(ws[0]) if ws else 0
        anns = [(i, frag)] if frag else [(0, words[0])]
    caps = []
    for (wi, frag) in anns:
        # posisi waktu awal kata ke-wi
        before = sum(len(w) + 1 for w in words[:wi])
        t0 = lead + speak * (before / total_chars)
        # durasi tampil: berdasar panjang frasa (kecepatan baca ~13 char/dtk) dibatasi
        t1 = t0 + min(2.6, max(1.0, len(frag) / 13 + 0.55))
        t1 = min(t1, dur - 0.05)
        if t1 - t0 < 0.5: t0 = max(0.05, t1 - 0.5)
        # gabung dgn kaption sebelumnya kalau waktu bertumpuk
        if caps and t0 < caps[-1][1] + 0.05:
            caps[-1][1] = max(caps[-1][1], t1)
            continue
        caps.append([round(t0, 2), round(t1, 2), frag])
    return caps

def full_captions(text, dur, max_words=4, lead=0.15, tail=0.10):
    """SUBTITLE PENUH: SEMUA kata tampil di pita atas, chunk <= max_words kata,
    tidak melintasi tanda baca kalimat, timing proporsional panjang teks,
    kontinu (tanpa lubang) — persis subtitle, sinkron dgn audio per klip."""
    if not text or dur <= 0: return []
    text = re.sub(r'\s*-{2,}\s*', ' ', text).strip()      # jangan pernah tampilkan ---
    if not text: return []
    words = text.split()
    if not words: return []
    chunks, cur = [], []
    for w in words:
        cur.append(w)
        if len(cur) >= max_words or re.search(r'[,.;:!?]$', w):
            chunks.append(' '.join(cur)); cur = []
    if cur: chunks.append(' '.join(cur))
    total = sum(len(c) + 1 for c in chunks)
    speak = max(0.6, dur - lead - tail)
    caps, t = [], lead
    for c in chunks:
        d = speak * (len(c) + 1) / total
        t1 = min(dur - 0.03, t + max(0.7, d))
        caps.append([round(t, 2), round(t1, 2), c])
        t = t1 + 0.03
    if caps: caps[-1][1] = round(max(caps[-1][1], dur - 0.03), 2)
    return caps

def word_captions(bounds, dur, max_words=4, lead=0.10, tail=0.09):
    """v4.1 SUBTITLE PRESISI: timing dari timestamp kata asli edge-tts.
    Subtitle muncul 0.1 dtk LEBIH AWAL (standar siaran: terlambat = terasa salah)."""
    if not bounds or dur <= 0: return None
    words = []
    for b in bounds:
        try:
            a, e, wd = float(b[0]), float(b[1]), str(b[2] or '').strip()
        except Exception:
            continue
        if wd:
            words.append((max(0.0, a - lead), min(dur, e + tail), wd))
    if not words: return None
    groups, cur = [], []
    for w0, w1, wd in words:
        cur.append((w0, w1, wd))
        if len(cur) >= max_words:
            groups.append(cur); cur = []
    if cur: groups.append(cur)
    out = []
    for g in groups:
        t0 = g[0][0]
        t1 = min(dur - 0.03, max(x[1] for x in g))
        if t1 <= t0: t1 = min(dur - 0.03, t0 + 0.7)
        out.append([round(t0, 2), round(t1, 2), ' '.join(x[2] for x in g)])
    for k in range(len(out) - 1):                 # jangan tumpang tindih
        if out[k][1] > out[k + 1][0]:
            mid = round((out[k][1] + out[k + 1][0]) / 2, 2)
            out[k][1] = mid; out[k + 1][0] = mid
    return out

# alias utk kompatibilitas pipeline lama
def chunk_text(text, max_words=5):
    return [c for c in clauses(text)]

if __name__ == '__main__':
    import sys
    t = ("Here is what we are up against. According to the FBI, Americans over "
         "sixty lost more than 7.7 billion dollars to fraud in a single year. "
         "Never send gift cards to someone you have not met.")
    for c in smart_captions(t, 22.0):
        print(f'{c[0]:5.1f} → {c[1]:5.1f}  {c[2]}')
