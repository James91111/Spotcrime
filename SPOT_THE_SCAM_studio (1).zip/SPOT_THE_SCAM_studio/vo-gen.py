#!/usr/bin/env python3
# ============================================================
#  VO-GEN untuk Termux — voiceover Edge-TTS otomatis
#  Input  : vo.txt  (paragraf dipisah baris "---")
#  Output : vo_01.mp3, vo_02.mp3, ...
#  Setup  : pip install edge-tts
#  Pakai  : python vo-gen.py vo.txt
# ============================================================
import subprocess, sys, os

VOICE  = "en-US-AndrewNeural"   # ganti: en-US-AriaNeural / en-US-GuyNeural, dll
RATE   = "-8%"                  # sedikit lambat -> jelas utk penonton 55+
PITCH  = "-8Hz"                 # sedikit berat -> kesan dokumenter

def main():
    src = sys.argv[1] if len(sys.argv) > 1 else "vo.txt"
    blocks, cur = [], []
    for raw in open(src, encoding="utf-8"):
        if raw.strip() == "---":
            if cur: blocks.append(" ".join(cur)); cur = []
        else:
            cur.append(raw.strip())
    if cur: blocks.append(" ".join(cur))

    print(f"=== VO-GEN: {len(blocks)} file | suara {VOICE} ===")
    for i, text in enumerate(blocks, 1):
        out = f"vo_{i:02d}.mp3"
        print(f"[{i}/{len(blocks)}] {out} ({len(text)} karakter)")
        r = subprocess.run(
            ["edge-tts", "--voice", VOICE, f"--rate={RATE}",
             f"--pitch={PITCH}", "--text", text, "--write-media", out],
            capture_output=True)
        if r.returncode != 0 or not os.path.exists(out):
            print("   GAGAL:", r.stderr.decode()[:150])
    print("=== Selesai. File ada di folder ini. ===")

if __name__ == "__main__":
    main()
