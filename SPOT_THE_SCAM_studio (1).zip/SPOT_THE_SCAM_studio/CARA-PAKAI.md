# 📱 CARA PAKAI — CUKUP 3 LANGKAH

Buat video = **satu perintah**:
```bash
python studio.py
```
Komponen kurang? **Terpasang otomatis** (sekali saja, butuh internet).
Lalu jendela aplikasi terbuka sendiri. Di jendela itu:

---

### LANGKAH 1 — GENERATE VOICEOVER
Klik **📄 Upload Narasi (.txt)** dan pilih file naskah dari storage tablet —
naskah langsung masuk kotak, lengkap dengan hitungan kata + estimasi durasi
(target 10–13 menit). Bisa juga tempel manual di kotak besar.
Aturannya: **1 paragraf = 1 adegan**, pisahkan antar adegan dengan baris `---`.
> Naskah ±1.500–1.700 kata = video jadi ±10–13 menit (±30 paragraf, 45–50 kata/paragraf).

Pilih suara (default **Andrew** — paling bagus untuk niche ini) → klik **Generate Voiceover**.
Tunggu sampai progress bar selesai (ada perkiraan waktu).

🧹 **Bersihkan File Lama** — klik tombol ini tiap mau bikin episode baru:
narasi, audio, SRT, transkrip, work, dan video hasil lama terhapus sekali jalan
(program & aset tidak ikut terhapus).

### LANGKAH 2 — SCAN (otomatis)
Setelah suara jadi, studio menyusun rencana adegan **sendiri** —
karakter, latar, durasi, subtitle. Anda tidak perlu apa-apa.

### LANGKAH 3 — RENDER
Klik **Merge + Render** → tunggu (progress + ETA tampil) →
video final ada di folder **`hasil/`** — `hasil/ep01/final.mp4`.
💡 Mau uji coba dulu tanpa nunggu lama? Klik **Render Review 60 dtk**.

---

## 🖼️ THUMBNAIL
**Paling gampang — di GUI:** kartu **4 Thumbnail YouTube**:
pilih motif → teks terisi otomatis (boleh diedit) →
**🎨 Generate Thumbnail** (langsung jadi PNG, tersimpan `hasil/thumb.png`) atau
**📋 Buat & Salin Prompt AI** (prompt bahasa Inggris siap tempel ke AI gambar lain:
Bing Image Creator, ImageFX, dll).

Via terminal (kalau mau):
```bash
python thumb_gen.py --motif phone           -> hasil/thumb.png
python thumb_gen.py --list                  -> lihat 8 preset
python thumb_gen.py --motif giftcard --l1 "SHE PAID" --l2 "$38,000"
```
Preset: phone, giftcard, bank, medicare, crypto, prize, check, custom.

## 🪟 IKON APLIKASI (opsional, sekali saja)
```bash
bash pasang-app.sh
```
Ikon **"Spot The Scam Studio"** muncul di desktop/menu — klik = studio terbuka.

## ❓ KALAU GAGAL
- Komponen gagal terpasang → pasang manual:
  `pip install flask pillow edge-tts numpy soundfile imageio-ffmpeg`
- Jendela tidak muncul (tidak ada layar X11) → alamat studio tercetak di terminal,
  buka di browser: `http://localhost:8808`

## 🎬 V18 — SUBTITLE BARIS PENDEK + LATAR BERTEMA (referensi: Hypothetically)
- Subtitle ala film POV: **2–4 kata per baris**, pita atas, kontinu —
  pembatas `---` di naskah TIDAK PERNAH ikut tampil (dibersihkan di 3 lapis).
- **Latar bercerita**: objek dekorasi dipilih otomatis dari isi kalimat —
  gift cards+surat (tema uang), pohon/bench/lampu (di luar), partisi+printer
  (kantor), fence+kerucut (polisi), dll. Setiap naskah menghasilkan komposisi
  adegan yang berbeda — bukan template.

## 📝 SUBTITLE & VARIASI ADEGAN (v15)
- **Subtitle penuh**: SEMUA kata tampil sebagai subtitle di pita atas, chunk ≤6 kata,
  kontinu mengikuti audio per klip (bukan lagi cuma kata penting).
- **Variasi otomatis**: mesin membaca isi kalimat → memilih adegan (telepon, gift cards,
  uang hilang, polisi, bank, call center, komputer, surat, rumah, mobil, cry/sedih+d-air
  mata, shock+tanda seru, dst). 3 motif terakhir dihindari; kalau adegan sama berulang,
  visualnya dipaksa beda (ekspresi/aksi/objek diganti).
- Prioritas: motif custom Anda (motifs.dat) → kata kunci narasi → variasi wajib.

## MODE LANJUTAN (tidak wajib — abaikan saja)
- `A2_NO_BROWSER=1 python a2studio.py` → server saja, tanpa popup
- `python episode.py narasi.txt --out ep01` → render penuh tanpa GUI
- File lain di folder ini = mesin di balik studio (tidak perlu disentuh)

## BARU DI v4.0 (cara pakai TIDAK berubah)
- **Latar 140** (rumah sakit, pengadilan, bandara, mal, kota senja, klinik, lobi),
  **objek 160** (paspor, palu hakim, borgol, koper, timer URGENT, kartu SSN, pop-up virus,
  kotak sumbangan, dsb), **furnitur 123** (ranjang RS + infus, meja hakim, papan keberangkatan,
  rak toko, balon hati...), **4 tokoh baru** (dokter, perawat, hakim, petugas).
- **Motif baru otomatis**: rumah sakit, pengadilan, bandara/"terjebak di luar negeri",
  romance scam, hadiah/lotre, SSN/pencurian identitas, transfer/Zelle, virus/komputer,
  donasi/amal, mal/toko, tekanan waktu (24 hours!).
- **Efek cerita**: narasi kerugian → koin terbang keluar + X merah; narasi uang kembali →
  koin masuk + centang hijau.
- **Sub-adegan**: klip panjang dipotong otomatis per kalimat (cut 2-3 dtk ala film).
- **Efek suara halus** (ketuk pintu, koin, whoosh, sedih, alert) — volume jauh di bawah
  narator; bisa dimatikan lewat kotak centang 🔊 di studio (atau `--no-sfx`).

## BARU DI v4.2
- **Sinkronisasi subtitle PRESISI**: subtitle mengikuti timestamp kata asli dari suara
  (WordBoundary) — terkompensasi hening pembawa, muncul 0,1 dtk lebih awal (standar siaran).
  Berlaku juga untuk klip gabungan (offset kumulatif otomatis).
- **Musik latar halus**: mood berganti mengikuti adegan (tegang / hangat / lega),
  selalu jauh di bawah suara narator — bisa dimatikan lewat kotak centang 🎵 (atau `--no-music`).
- **Efek suara baru**: dering telepon saat adegan HP, langkah kaki saat tokoh berjalan.

## BARU DI v4.3 (perbaikan dari review tablet)
- **Subtitle selalu besar**: font dicari di lokasi baru; kalau Montserrat tak ketemu,
  font darurat otomatis DIPAKAI ukuran penuh 118px — tidak mungkin kecil lagi.
- **Objek tidak bertumpuk lagi**: furnitur, prop, & dekor dihitung tabrak-ruang otomatis
  (karpet = alas, objek lain dipindah ke posisi kosong).
- **Lebih hidup**: kamera bergerak mengikuti adegan (drift), tokoh geser berat badan
  & gemetar saat cemas, kupu-kupu, awan kedua lawan arah, daun gugur saat senja,
  kilau di adegan hadiah, kilat putih ala film antar sub-adegan.

## BARU DI v4.4 — PERPUSTAKAAN GERAK (script makin kaya, ukuran tetap ringan)
- **8 rumus gerak tokoh baru**: mondar-mandir cemas, bicara sambil menunjuk-nunjuk luas,
  melihat kanan-kiri waspada, mengangguk, menggeleng, mundur terkejut, berlari,
  MENYERAHKAN barang (kartu/uang terbang melengkung antar tokoh).
- Bicara tidak lagi diem: mesin memilih otomatis gesture/melihat/mengangguk.
- **Mata tokoh berkedip melirik** kiri-kanan secara natural.
- **3 tokoh baru**: techgirl (penipu wanita), bankmanager, kurir — penipu dirotasi.
- **Animasi objek baru**: bergetar (HP berdering!), berayun, layar berkedip, meluncur masuk.
- **Latar hidup**: jendela kota menyala berganti, layar PC berkedip, monitor detak jantung
  (RS), hujan tipis saat adegan sedih, lampu mobil lewat, debu di cahaya pengadilan.
- **Tokoh dijamin tidak tertutup** objek apa pun (zona suci + fallback ke belakang).

## BARU DI v4.5 — DIRANCANG DARI NARASI ASLIMU (5 penipuan terburuk)
Setiap tambahan diturunkan dari analisis naskah episode asli (FTC $15,9 miliar,
toll text, grandchild clone, bank imposter, phantom hacker, gold bar courier):
- **10 adegan baru otomatis dari kata kunci naskah**: SMS tol palsu (HP bergetar +
  chat tol), jalan tol (gerbang + booth tol), suara dikloning AI (gelombang suara),
  angka statistik (peta AS / kartu polling + studio berita), caller-id palsu,
  kurir di pintu (amplop uang), kurir emas (kotak emas + peti emas), penangkapan
  (polisi + borgol), langkah 1-2-3 (kartu langkah), ajakan komentar (gelembung
  komentar), keluarga + safe word (bintang).
- **Aset baru**: 20 objek, 6 furnitur (booth tol, peti emas), 7 latar (studio
  berita layar besar + 3 jalan tol). Total: 180 objek, 129 furnitur, 147 latar.
- **Gaya angka countdown**: kalimat "Number five..." / "Step one..." tampil sebagai
  kartu angka besar (kunci jawaban poll 5/4/3/2/1 di CTA).
- **Efek suara baru per adegan**: ketukan pintu kurir, dentang koin emas, alarm
  pop-up, SMS masuk; musik otomatis menceburkan mood tiap motif baru.
- Perbaikan penting: loader objek kini membaca manifest objpack — SEMUA objek
  kini benar-benar tampil di video (sebelumnya sebagian gagal senyap).

## BARU DI v4.6 — VIDEO LEBIH NYAMAN DITONTON & SUARA BISA DIATUR
Perbaikan dari masukan langsung setelah menonton hasil render:
- **Kamera tidak lagi berguncang**: getaran acak antar-frame dihapus; kini hanya
  geser halus konstan (drift 12px, sebelumnya 26px + getar). Zoom fokus pembicara
  tetap ada, jadi adegan tetap hidup tapi mata tidak pegal.
- **Burung tidak muncul sembarangan**: burung/kupu-kupu kini HANYA muncul di latar
  alam (taman, jalan, senja) dan tidak di setiap klip; burung juga dihapus dari
  dekorasi dalam rumah, studio berita, dan adegan penangkapan.
- **Musik tidak lagi "mendorong" tiap kata**: denyut tensi diganti napas lembut,
  petikan akor diredam. Musik konsisten di bawah narator.
- **Efek suara benar-benar terdengar**: ada bug lama (sejak v4.2) yang membuat SFX
  gagal senyap — sudah diperbaiki; SFX juga diperkuat sedikit tapi tetap di bawah
  suara narator.
- **SLIDER VOLUME di jendela aplikasi (Kartu 3)**: atur sendiri Volume SFX,
  Volume Musik, dan Volume Narator (0–100%). Default: SFX 70%, Musik 100%,
  Narator 100%. Perubahan langsung dipakai saat klik Render — tidak perlu edit
  file apa pun.

## v4.7 — TANPA BURUNG, KAMERA MATI SEMPURNA (masukan penonton)
- Burung/kupu-kupu DIHAPUS TOTAL dari semua adegan (sebelumnya masih lolos di
  beberapa latar & menumpuk objek lain).
- Kamera kini MATI 100%: tanpa zoom, tanpa geser, tanpa guncangan, tanpa kilat
  putih. Hanya fade lembut di awal/akhir klip. Yang bergerak hanya tokoh &
  objek yang memang dianimasikan — nyaman ditonton lama.
